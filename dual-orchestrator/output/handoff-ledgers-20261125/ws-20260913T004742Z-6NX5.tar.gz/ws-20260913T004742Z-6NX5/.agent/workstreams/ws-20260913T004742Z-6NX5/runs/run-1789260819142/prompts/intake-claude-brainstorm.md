## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5
- This intake run uses restricted contract discovery. Use orchestrator-provided context and bounded discovery only.
- Do not output shell commands or Bash code fences as a substitute for the required structured artifact.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.



# Claude Intake Brainstorm

Workstream: ws-20260913T004742Z-6NX5
Node: intake.claude_brainstorm
Template: intake-claude-brainstorm
Ledger: .agent/workstreams/ws-20260913T004742Z-6NX5

You are Claude acting as the primary developer and product-design partner.

Use the orchestrator-provided seed, tracked-path inventory, memory, contract scope, and context recommendations to clarify the user request before implementation. This intake stage permits targeted Read/Grep/Glob discovery inside the effective workspace so the contract can be grounded in repository facts. Start from the projected repo map, inspect only the files needed to determine exact scope and acceptance semantics, and do not start an open-ended repository survey. Terminal, Bash, execute, write, edit, and file creation remain prohibited. When the tracked inventory is non-empty, `evidence_refs` must include at least one existing repository file that supports the proposed scope; additional durable evidence references remain allowed. Do not return `READY_FOR_PRODUCT_REVIEW` from filenames or requirement prose alone. If evidence remains insufficient, preserve the uncertainty in supported fields for reviewer/human judgment; do not end with a prose-only "I need to inspect the repo" message.

If the context package includes a previous Codex review, Must Fix list, or revision request, treat it as mandatory feedback for this intake revision. Explicitly address each Must Fix in the updated artifact instead of repeating the previous draft.

Revision convergence policy:

- Must Fix feedback is stronger than the previous draft. The revised proposal must change the contract enough that each Must Fix is satisfied by construction.
- Do not move an already-specified user constraint into `open_questions`. If the user request or Codex Must Fix already states the rule, encode the rule directly into `acceptance_criteria`, `constraints`, and `test_requirements`.
- Before returning `READY_FOR_PRODUCT_REVIEW`, account for every explicit user objective, allowed/excluded file, behavior constraint, acceptance criterion, and verification requirement in a binding proposal field: `objective`, `scope`, `acceptance_criteria`, `test_requirements`, `constraints`, or `non_goals`. A requirement mentioned only in `risk_areas`, `open_questions`, or `evidence_refs` is not preserved.
- For an initial proposal over a non-empty tracked inventory, include at least one `evidence_refs` entry from the projected repo map. Evidence references support scope reasoning but never authorize edits by themselves.
- Do not copy the current node's `AgentResultEnvelope`, JSON-only output, or workflow-routing protocol into the task proposal. Those are enforced independently by the orchestrator's Output Contract and are not product or implementation requirements.
- Preserve the user's semantic boundary exactly. Do not broaden or narrow behavior based on language-specific edge cases, inferred product preferences, or a conservative implementation choice that the user did not request.
- Treat the typed scope projected by the Output Contract as the exhaustive authorization set for permitted repository changes. It does not require every declared path to be changed. Do not use acceptance criteria, constraints, risks, or other prose to authorize undeclared paths, and never describe typed scope as illustrative or non-exhaustive. When a revision obligation identifies a scope gap, use only the exact typed scope-addition field rendered by the Output Contract and map the obligation to one or more genuinely relevant clause IDs.
- Use `open_questions` only for real product ambiguity that cannot be resolved from the user request, repository evidence, or prior Codex feedback.
- If an implementation tradeoff does not change user-visible semantics, choose the simplest compliant implementation and record material risk in `risk_areas`. If it would change the accepted input, output, scope, or observable behavior, preserve the literal user requirement and record the unresolved choice without turning it into a constraint or test.
- When revising after a Codex Must Fix, include at least one acceptance criterion or test requirement for each Must Fix. Do not claim readiness while leaving a Must Fix as a future human decision.

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.
- Even when repository evidence is insufficient, the final assistant message must be the required strict JSON result. A prose-only response is a contract failure.

## User Request

# OKX BTC 分钟级 K 线 Web 应用需求

## 目标

构建一个本地 Web 应用，通过 OKX 官方公开行情 REST API 获取 BTC-USDT 现货分钟级 K 线，将数据持久化到 SQLite，并展示可定时刷新的 K 线图。

本应用只读取公开行情，不得下单、访问账户、提供投资建议或抓取 OKX 网页。

## 强制技术栈

- Java 25。
- Spring Boot 4.1.0。
- Maven。
- MyBatis-Plus 3.5.17，必须使用 `mybatis-plus-spring-boot4-starter`。
- SQLite 是唯一应用数据库。
- 使用成熟的 K 线图表库，生产资源必须随应用本地打包，不得依赖运行时 CDN。

不得用 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施替代 MyBatis-Plus。

## OKX 行情契约

- 数据源只能是 OKX 官方公开 Market Data REST API，不得抓取 HTML 页面。
- 交易品种固定为 BTC-USDT 现货。
- K 线周期固定为 `1m`。
- 接口为 `GET /api/v5/market/candles`。
- 首次启动拉取并保存最近 300 根 K 线。
- 响应行格式为 `[ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]`。
- `ts` 是 K 线开盘时间的 Unix 毫秒时间戳。
- `confirm=0` 表示当前 K 线尚未闭合，后续允许更新。
- `confirm=1` 表示 K 线已经闭合。
- OKX 可能按时间倒序返回数据，后一次请求也可能命中较旧缓存。应用不得假设响应严格单调，也不得因旧响应删除本地较新的 K 线。
- OKX base URL、连接/读取超时、调度开关和刷新周期必须支持外部配置。
- 调用公开行情不得要求 API Key 或 OKX 账户。
- 生产应用和显式 live smoke 必须直接调用 OKX 官方 API，不得通过测试桩、代理业务服务或抓取服务替代。

## 数据持久化

- 通过 MyBatis-Plus 将 K 线保存到 SQLite。
- 数据库必须对 `(instrument, bar, open_time)` 建立唯一约束。
- 重复同步必须幂等。
- 未闭合 K 线应原位更新。
- 已闭合 K 线在应用重启后仍可查询。
- 价格和成交量不得以二进制浮点数作为权威值，Java 与 SQLite 均采用 decimal-safe 表示。
- 保存足够的同步状态，以展示最近一次尝试、最近一次成功和最近失败；错误文本不得反向成为生命周期状态 owner。
- 数据库初始化必须确定且版本化，不得在业务代码中临时拼接建表流程。

## 定时同步

- 启用同步时，应用启动后执行一次初始回填。
- 默认每 15 秒轮询一次 OKX，周期可配置。
- 每轮必须先完整解析并校验 OKX envelope，再写数据库。
- 同一响应中的合法 K 线在一个事务内完成 upsert。
- HTTP 超时、非 2xx、OKX 业务错误、限流、非法 JSON、非法行或数据库异常不得删除已有 K 线。
- 不得进行无界立即重试；失败后记录 degraded 状态，等待下一轮调度。
- 单应用实例内不得出现重叠调度执行。
- 日志只记录必要运行元数据，失败时不得打印完整 OKX 响应正文。

## 后端 API

提供稳定 JSON API：

1. 查询最近最多 300 根已保存 K 线，按开盘时间升序返回。
2. 查询同步健康状态，包括当前状态、最近尝试时间、最近成功时间和有界安全的失败摘要。

非法 limit 必须返回明确的客户端错误。浏览器只能调用本应用后端，不得直接请求 OKX。

## Web 体验

- 首屏直接展示可用的行情界面，而不是营销落地页。
- 展示真实蜡烛 K 线和成交量。
- 展示 `BTC / USDT`、`1m`、最新收盘价、最近闭合 K 线时间、同步状态和最近成功刷新时间。
- 浏览器默认每 10 秒从后端刷新数据，不整页重载。
- 同步 degraded 时保留最后可用图表，并显示克制但清晰的状态。
- 正确处理首次加载、无数据、数据降级和后端失败状态。
- 当前桌面和移动端视口均应可用，文字、图表和操作不得重叠。
- 不得把模拟价格冒充为 OKX 实时行情。

## 验证要求

- 生产实现只能直连 OKX 官方公开 API。
- `mvn test` 不得依赖公网 OKX 的可用性；自动化测试使用本地、契约一致的 HTTP stub 和冻结 fixture，专门验证正常响应及公网无法稳定制造的超时、429、乱序、陈旧缓存与畸形响应。
- 测试必须覆盖首次回填、倒序输入、重复同步、未闭合 K 线更新、闭合 K 线持久化、陈旧响应、非法 envelope、非法行、超时、非 2xx、OKX 业务错误和调度不重叠。
- 使用临时 SQLite 数据库验证唯一约束与重启后持久化。
- 覆盖后端 API 排序、limit 校验、健康状态，以及同步失败后保留已有数据。
- 提供浏览器级或 DOM 级验证，证明图表消费本应用后端数据、定时刷新且不从浏览器调用 OKX。
- Java 25 下执行 `mvn test` 必须通过，并且测试执行期间无需访问公开 OKX API。
- 提供显式 opt-in live smoke 命令，直接向 OKX 官方接口发起一次只读请求，并验证至少一根结构合法的 BTC-USDT 1m K 线；该命令不得进入默认 `mvn test`。
- README 必须记录架构、配置、SQLite 路径、启动、测试、live smoke、API、数据新鲜度语义和限制。

## 不在范围内

- 交易、账户访问、认证、API Key、余额或任何私有 OKX API。
- 投资建议、告警、策略、技术指标或预测。
- WebSocket 行情。
- 多交易品种或多周期切换。
- 分布式调度或多实例协调。
- 用户账户或管理后台。
- 通用交易所抽象或行情平台。
- 运行时 CDN 依赖。



## Context Package

### Direct Input Artifacts

- .agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260759505/outputs/intake-codex-product-review.stderr.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260759505/outputs/intake-codex-product-review.transcript.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260759505/outputs/intake-codex-product-review.json

```json
{
  "workstreamId" : "ws-20260913T004742Z-6NX5",
  "runId" : "run-1789260759505",
  "nodeId" : "intake.codex_product_review",
  "nodeInstanceId" : "node-intake-codex_product_review-004",
  "stageOutcome" : "NEEDS_REVISION",
  "lifecycleStatus" : "NEEDS_REVISION",
  "decision" : "NEEDS_REVISION",
  "summary" : "提案基本覆盖产品目标与架构边界，但行情字段语义、安全失败摘要和离线测试证明方式仍需补齐。",
  "sourceArtifactType" : "agent_output_contract",
  "sourceOutputRef" : ".agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260759505/outputs/intake-codex-product-review.json",
  "blocking" : true,
  "checks" : [ "先审阅 Review Evidence Brief，再逐项对照用户需求与完整提案中的约束、验收标准和测试要求。", "确认技术栈、公开行情直连、事务写入、唯一约束、非重叠同步、本地前端资源和主要用户状态均已有绑定条款。", "确认 scope.included 使用精确路径与操作，未要求扩大为非穷举授权。", "检查事实归属、下游消费、副作用前置校验、失败路径及不可绕过的验证要求；发现离线测试证据存在逻辑缺口。", "未将编排器输出协议缺失视为产品契约缺陷，未进行代码逐行审查或修改文件。" ],
  "evidence" : [ "用户明确规定响应行顺序为 [ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]；提案 TR-1 仅写合法 9 字段行，C-10 仅规定 open_time 为 Unix 毫秒整数，未完整绑定字段顺序与 ts 的开盘时间含义。", "用户要求有界安全的失败摘要；AC-3 与 C-9 只明确截断和长度边界，C-14 仅限制日志，未明确约束健康 API 返回的错误内容。", "TR-9 要求通过 stub 请求记录证明未访问公网 OKX；该记录只能证明请求到达 stub，无法观察或排除另一路公网请求。", "C-7 已要求完整校验 envelope 与全部行后才进入事务写入；AC-6 和 TR-3 已要求失败保留已有数据并进入 degraded。" ],
  "mustFix" : [ "在绑定字段中补全 OKX 九字段位置映射及 ts 为 K 线开盘时间的 Unix 毫秒时间戳，并补充映射验证。", "将失败摘要的内容安全要求写入绑定条款，并覆盖健康 API 与前端展示的验证。", "修正 TR-9 的证明方式，采用能阻止或观测测试进程非本地 OKX 出站请求的验证机制。" ],
  "contractObligations" : [ {
    "id" : "CO-1",
    "text" : "在 constraints 或 acceptance_criteria 中明确响应行顺序 [ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]、各成交量字段的对应关系，以及 ts 是开盘时间的 Unix 毫秒时间戳；在现有 CandleRowParserTest.java 中用不同字段值验证映射与时间单位，避免只验证字段数。"
  }, {
    "id" : "CO-2",
    "text" : "在 AC-3 或 C-9 中明确安全摘要采用受控错误类别和安全内容，不直接透传上游正文或内部异常细节，并有明确长度上限；在现有 KlineApiControllerTest.java 与 WebUiBrowserTest.java 中验证异常内容不会泄漏或被作为 HTML 执行，生命周期状态仍由结构化同步结果决定。"
  }, {
    "id" : "CO-3",
    "text" : "修改 TR-9：stub 请求记录仅用于证明预期交互，另通过测试进程网络隔离、统一出站拦截或等效机制证明默认 mvn test 不访问公网 OKX；覆盖启动回填和调度入口，并设置尝试非本地目标时必定被阻止或导致测试失败的验证。相关实现和测试可落在已授权的 pom.xml、StubOkxServer.java 与现有同步测试路径中。"
  } ],
  "missingEvidence" : [ ],
  "acceptanceNotes" : [ "上述修订可在既有精确路径授权内完成，无需增加产品功能或请求用户作新的产品决策。", "当前是契约审查；未执行构建、测试或 live smoke，也未验证依赖版本兼容性。", "未将陈旧响应不删除较新记录扩张为用户未明确要求的全面禁止历史字段回写。" ],
  "openRisks" : [ ],
  "changedFiles" : [ ],
  "verificationSummary" : "已完成需求与提案的静态交叉审查；三个契约缺口修复后可再次评审。",
  "completedWork" : [ ],
  "importantDecisions" : [ ],
  "recommendedNextStage" : "",
  "suggestedNextPrompt" : "",
  "control" : {
    "summary" : "提案基本覆盖产品目标与架构边界，但行情字段语义、安全失败摘要和离线测试证明方式仍需补齐。",
    "decision" : "NEEDS_REVISION"
  },
  "failure" : {
    "categoryHint" : "契约完整性与验证有效性",
    "verificationRemediation" : "NONE",
    "contractGaps" : [ "CO-1：缺少完整绑定的行情字段位置与开盘时间语义。", "CO-2：有界截断未完整覆盖失败摘要的内容安全要求。", "CO-3：stub 请求记录无法证明不存在公网 OKX 请求。" ],
    "outOfScopeFiles" : [ ],
    "missingTests" : [ ],
    "contextGaps" : [ ],
    "reason" : "当前契约仍允许字段语义实现偏差、不安全错误内容透传，以及不能成立的离线性证明，需先修订再推进。"
  },
  "rereadReasons" : [ ],
  "reviewSubject" : {
    "schema_version" : 1,
    "proposal_id" : "node-intake-claude_brainstorm-002:bffbcf7f8524ea57",
    "workstream_id" : "ws-20260913T004742Z-6NX5",
    "producer_node_id" : "intake.claude_brainstorm",
    "producer_node_instance_id" : "node-intake-claude_brainstorm-002",
    "artifact_ref" : ".agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260534648/outputs/intake-claude-brainstorm.contract.json",
    "sha256" : "bffbcf7f8524ea57fc3f9b01ee97fb2ebc45b76b8c0face925a42c3c02f33021"
  },
  "taskContractProposal" : null,
  "repositoryFactBinding" : null,
  "proposalDerivation" : null,
  "planArtifact" : null,
  "design" : null,
  "authoredRevisionResponses" : null,
  "authoredContext" : null
}
```

### Verified Previous Task Contract Proposal

- Proposal ID: node-intake-claude_brainstorm-002:bffbcf7f8524ea57
- Proposal SHA-256: bffbcf7f8524ea57fc3f9b01ee97fb2ebc45b76b8c0face925a42c3c02f33021

<!-- dual:typed-payload:start -->
```json
{
  "artifact_type" : "task_contract_proposal",
  "schema_version" : 3,
  "objective" : "构建 Java 25 + Spring Boot 4.1.0 + MyBatis-Plus 3.5.17 + SQLite 的本地 Web 应用：直连 OKX 官方公开行情 REST API 拉取 BTC-USDT 现货 1m K 线并幂等持久化，提供稳定 JSON API 与可定时刷新、无运行时 CDN 依赖的蜡烛图界面。",
  "scope" : {
    "included" : [ {
      "path" : "pom.xml",
      "operation" : "CREATE"
    }, {
      "path" : "README.md",
      "operation" : "MODIFY"
    }, {
      "path" : "scripts/live-smoke.sh",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/application.yml",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/schema.sql",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/index.html",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/css/app.css",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/js/app.js",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/vendor/lightweight-charts.standalone.production.js",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/OkxKlineApplication.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/config/OkxProperties.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/config/SchedulingConfig.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/CandleEntity.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/CandleMapper.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/SyncStateEntity.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/SyncStateMapper.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/DecimalTextTypeHandler.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxMarketClient.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxApiResponse.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/CandleRowParser.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/CandleSyncService.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/SyncScheduler.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/SyncStateService.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/KlineApiController.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/GlobalExceptionHandler.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/KlinePointResponse.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/SyncStatusResponse.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/ApiErrorResponse.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/CandleRowParserTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/CandleSyncServiceTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/SyncSchedulerOverlapTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/KlineApiControllerTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/persistence/SqlitePersistenceTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/WebUiBrowserTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/support/StubOkxServer.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/livesmoke/LiveSmokeTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/application-test.yml",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx-candles-normal.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx-candles-reversed.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx-candles-stale.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx-business-error.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx-malformed.json",
      "operation" : "CREATE"
    } ],
    "excluded" : [ "任何 OKX 私有 API、交易、下单、账户访问、认证或 API Key 集成", "抓取 OKX HTML 页面或经由代理业务服务获取行情", "WebSocket 行情接入", "多交易品种或多 K 线周期切换", "分布式调度或多实例协调", "用户账户体系或管理后台", "通用交易所抽象或行情平台化", "运行时 CDN 依赖", "scope.included 之外的任何仓库路径变更（含 .git/ 与 .agent/）" ]
  },
  "acceptance_criteria" : [ {
    "id" : "AC-1",
    "text" : "同步启用时，应用启动后自动执行一次初始回填：通过 OKX 官方公开接口 GET /api/v5/market/candles（instId=BTC-USDT、bar=1m、limit=300）拉取并保存最近 300 根 K 线；全程不需要 API Key 或 OKX 账户。"
  }, {
    "id" : "AC-2",
    "text" : "GET /api/klines 返回最近最多 300 根已保存 K 线并按开盘时间严格升序排列；limit 缺省取合法默认值，limit 为非整数、≤0 或 >300 时返回带明确错误信息的 4xx 客户端错误。"
  }, {
    "id" : "AC-3",
    "text" : "GET /api/sync/status 返回当前生命周期状态（如 running/degraded）、最近一次尝试时间、最近一次成功时间和有界截断的失败摘要；状态由同步结果驱动，错误文本仅作为被截断的展示字段而非状态判定依据。"
  }, {
    "id" : "AC-4",
    "text" : "SQLite 对 (instrument, bar, open_time) 建立唯一约束；重复同步幂等；confirm=0 的未闭合 K 线在同一键上原位更新；应用重启后已闭合（confirm=1）K 线仍可通过 API 查询。"
  }, {
    "id" : "AC-5",
    "text" : "对按时间倒序返回或命中较旧缓存的响应，同步仅按开盘时间键执行 upsert，任何情况下不删除本地较新的 K 线；单次响应中的全部合法 K 线在同一事务内完成写入。"
  }, {
    "id" : "AC-6",
    "text" : "HTTP 超时、非 2xx、429 限流、OKX 业务错误（code!=0）、非法 JSON、非法行或数据库异常发生时：既有 K 线全部保留，同步状态进入 degraded，不进行无界立即重试，等待下一轮调度。"
  }, {
    "id" : "AC-7",
    "text" : "单应用实例内同步调度永不重叠（含单轮执行时间超过轮询周期的情况）；默认每 15 秒轮询且周期可配置；OKX base URL、连接超时、读取超时和同步开关均支持外部配置。"
  }, {
    "id" : "AC-8",
    "text" : "首屏直接呈现行情界面而非营销页：真实蜡烛 K 线与成交量图、BTC / USDT、1m、最新收盘价、最近闭合 K 线时间、同步状态和最近成功刷新时间；浏览器默认每 10 秒从本应用后端拉取数据且不整页重载。"
  }, {
    "id" : "AC-9",
    "text" : "同步 degraded 时前端保留最后可用图表并显示克制清晰的状态提示；首次加载、无数据、数据降级和后端失败状态均被正确处理；桌面与移动视口下文字、图表和操作不重叠；不把模拟价格冒充为 OKX 实时行情。"
  }, {
    "id" : "AC-10",
    "text" : "价格与成交量在 Java 侧以 BigDecimal、SQLite 侧以 TEXT 列存储（经自定义 TypeHandler 映射），不以二进制浮点数作为权威值。"
  }, {
    "id" : "AC-11",
    "text" : "K 线图表库为成熟方案且其生产资源随应用本地打包；运行时不发起任何 CDN 请求；浏览器只调用本应用同源后端 API，不直接请求 OKX。"
  }, {
    "id" : "AC-12",
    "text" : "Java 25 环境下执行 mvn test 全部通过，且测试执行期间不访问公网 OKX；所有 OKX 交互由本地契约一致的 HTTP stub 与冻结 fixture 模拟。"
  }, {
    "id" : "AC-13",
    "text" : "提供显式 opt-in 的 live smoke 命令（scripts/live-smoke.sh，经 Maven profile 运行 @Tag(\"live-smoke\") 测试），直连 OKX 官方接口发起一次只读请求并验证至少一根结构合法（9 字段且 confirm 合法）的 BTC-USDT 1m K 线；该命令不在默认 mvn test 中执行。"
  }, {
    "id" : "AC-14",
    "text" : "数据库 schema 由仓库内版本化且幂等的初始化文件（schema.sql）确定地创建，业务代码中不存在临时拼接的建表流程。"
  }, {
    "id" : "AC-15",
    "text" : "README 完整记录架构、配置项、SQLite 路径、启动方式、测试、live smoke、后端 API、数据新鲜度语义和已知限制。"
  }, {
    "id" : "AC-16",
    "text" : "日志仅记录必要运行元数据（如轮次序号、状态、耗时、错误类别），失败时不得打印完整 OKX 响应正文。"
  } ],
  "test_requirements" : [ {
    "id" : "TR-1",
    "text" : "CandleRowParserTest 覆盖：合法 9 字段行、confirm=0/1 语义、字段数错误、价格/成交量数值非法、confirm 取值非法、行结构非数组等畸形输入均被整体拒绝且不产生部分写入。"
  }, {
    "id" : "TR-2",
    "text" : "CandleSyncServiceTest 使用本地 HTTP stub 与临时 SQLite 覆盖：首次回填 300 根、倒序输入、重复同步幂等、未闭合 K 线原位更新、闭合 K 线持久化、陈旧响应不删除较新数据。"
  }, {
    "id" : "TR-3",
    "text" : "失败路径测试用 stub 精确制造公网无法稳定制造的场景：连接/读取超时、429、非 2xx、OKX 业务错误、非法 JSON envelope、合法 envelope 内的非法行、数据库异常；断言既有数据保留、状态转为 degraded、无立即无界重试。"
  }, {
    "id" : "TR-4",
    "text" : "SyncSchedulerOverlapTest 以远小于执行时长的轮询周期驱动慢速同步，断言单实例内不存在重叠并发执行（跳过本轮或顺延均可，但绝不并发）。"
  }, {
    "id" : "TR-5",
    "text" : "KlineApiControllerTest 覆盖：按 open_time 升序、limit 边界（缺省、1、300、0、负数、非整数、301）、健康状态字段完整性、同步失败后已有 K 线仍可查询。"
  }, {
    "id" : "TR-6",
    "text" : "SqlitePersistenceTest 使用临时 SQLite 文件验证：(instrument, bar, open_time) 唯一约束生效，且应用重启（新建 Spring 上下文/新连接）后已闭合 K 线仍可查询。"
  }, {
    "id" : "TR-7",
    "text" : "WebUiBrowserTest 提供浏览器级或 DOM 级验证：图表消费本应用后端（stub 行情）数据、观测到定时刷新（测试内缩短轮询周期验证多次拉取）、页面发起的全部网络请求均为同源后端请求（无任何 OKX 或 CDN 调用）、降级状态提示正确展示。"
  }, {
    "id" : "TR-8",
    "text" : "live smoke 验证：执行 scripts/live-smoke.sh 直连 OKX 官方接口，断言至少一根 9 字段结构合法且 confirm 合法的 BTC-USDT 1m K 线；默认 surefire 配置排除 live-smoke tag，证明其不进入默认 mvn test。"
  }, {
    "id" : "TR-9",
    "text" : "在 Java 25 下执行 mvn test 通过，并通过 stub 请求记录断言测试期间未向公网 OKX 发起任何请求。"
  } ],
  "constraints" : [ {
    "id" : "C-1",
    "text" : "技术栈锁定：Java 25、Spring Boot 4.1.0、Maven 构建。"
  }, {
    "id" : "C-2",
    "text" : "持久层仅使用 MyBatis-Plus 3.5.17 且必须引入 mybatis-plus-spring-boot4-starter；禁止 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施。"
  }, {
    "id" : "C-3",
    "text" : "SQLite 是唯一应用数据库；K 线数据与同步状态均持久化在 SQLite。"
  }, {
    "id" : "C-4",
    "text" : "数据源仅限 OKX 官方公开 Market Data REST API（GET /api/v5/market/candles），品种固定 BTC-USDT 现货、周期固定 1m；禁止抓取 OKX HTML 页面；禁止任何 API Key 或账户凭证。"
  }, {
    "id" : "C-5",
    "text" : "生产应用与显式 live smoke 必须直连 OKX 官方 API，不得经由测试桩、代理业务服务或抓取服务替代；自动化测试必须使用本地契约一致的 HTTP stub 与冻结 fixture，不得依赖公网 OKX。"
  }, {
    "id" : "C-6",
    "text" : "OKX base URL、连接超时、读取超时、同步开关和同步周期（默认 15 秒）均通过外部配置注入，不得硬编码于业务逻辑。"
  }, {
    "id" : "C-7",
    "text" : "每轮同步必须先完整解析并校验 OKX envelope 与全部数据行，随后才在同一事务内 upsert；失败轮不写入部分数据、不删除既有数据。"
  }, {
    "id" : "C-8",
    "text" : "禁止无界立即重试；失败后记录 degraded 状态并等待下一轮调度；调度采用 fixedDelay 语义 + 单线程调度器 + 防重入守卫，保证单实例内不重叠。"
  }, {
    "id" : "C-9",
    "text" : "同步状态持久化到 SQLite，包含最近一次尝试、最近一次成功和最近失败的有界摘要；生命周期状态由同步结果驱动，错误文本不得参与状态判定。"
  }, {
    "id" : "C-10",
    "text" : "decimal-safe 表示：价格与成交量 Java 侧为 BigDecimal、SQLite 侧为 TEXT（自定义 TypeHandler 映射）；open_time 为 Unix 毫秒整数列，排序与去重仅基于该整数列。"
  }, {
    "id" : "C-11",
    "text" : "schema 初始化确定且版本化：仓库内 schema.sql（幂等 CREATE TABLE/INDEX IF NOT EXISTS）+ SQL init 配置执行，业务代码不得拼接 DDL。"
  }, {
    "id" : "C-12",
    "text" : "前端使用成熟 K 线图表库（TradingView Lightweight Charts standalone production 构建），其生产资源置于应用静态资源目录随应用本地打包；禁止运行时 CDN。"
  }, {
    "id" : "C-13",
    "text" : "浏览器仅调用本应用同源后端 API（默认每 10 秒拉取、无整页刷新）；后端 API 路径与响应结构保持稳定并记录于 README。"
  }, {
    "id" : "C-14",
    "text" : "日志仅输出必要运行元数据；失败日志不得包含完整 OKX 响应正文。"
  }, {
    "id" : "C-15",
    "text" : "live smoke 为显式 opt-in 命令（脚本包装 Maven profile），不得纳入默认 mvn test。"
  } ],
  "non_goals" : [ {
    "id" : "NG-1",
    "text" : "交易、下单、账户访问、认证、API Key、余额查询或任何 OKX 私有 API。"
  }, {
    "id" : "NG-2",
    "text" : "投资建议、告警、策略、技术指标或价格预测。"
  }, {
    "id" : "NG-3",
    "text" : "WebSocket 行情接入。"
  }, {
    "id" : "NG-4",
    "text" : "多交易品种或多 K 线周期切换。"
  }, {
    "id" : "NG-5",
    "text" : "分布式调度或多实例协调。"
  }, {
    "id" : "NG-6",
    "text" : "用户账户体系或管理后台。"
  }, {
    "id" : "NG-7",
    "text" : "通用交易所抽象或行情平台化。"
  }, {
    "id" : "NG-8",
    "text" : "运行时 CDN 依赖或任何对第三方前端站点的运行时请求。"
  } ],
  "risk_areas" : [ {
    "id" : "R-1",
    "text" : "Spring Boot 4.1.0 与 MyBatis-Plus 3.5.17（mybatis-plus-spring-boot4-starter）组合较新，自动装配细节可能需要适配；如遇兼容问题在 pom.xml 与配置内解决，不改变行为契约。"
  }, {
    "id" : "R-2",
    "text" : "SQLite 无原生 DECIMAL 类型；TEXT + BigDecimal TypeHandler 是 decimal-safe 方案，需确保排序、limit 与去重仅依赖 open_time 整数列而非价格文本。"
  }, {
    "id" : "R-3",
    "text" : "浏览器级验证选用 Playwright for Java，首次运行需下载浏览器二进制（非 OKX 网络依赖）；若环境受限可在同一测试文件 WebUiBrowserTest.java 内降级为 DOM 级 HtmlUnit 方案，验证语义不变。"
  }, {
    "id" : "R-4",
    "text" : "OKX 陈旧缓存可能使未闭合 K 线短暂回写较旧字段值；按 (instrument, bar, open_time) 键 last-write-wins upsert 符合契约（禁止删除），README 将说明该新鲜度语义。"
  }, {
    "id" : "R-5",
    "text" : "前端 10 秒与后端 15 秒刷新节奏不同步属预期，README 需说明数据新鲜度语义（最近闭合 K 线时间 + 最近成功刷新时间）避免误解。"
  } ],
  "evidence_refs" : [ "REQUIREMENT.md", "README.md", "scripts/verify-workspace.sh", ".gitignore" ],
  "open_questions" : [ ],
  "revision_responses" : [ ]
}
```
<!-- dual:typed-payload:end -->

- .agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-codex_product_review-004-run-1789260759505/binding.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260759505/outputs/intake-codex-product-review.contract.json
  (validated typed evidence already projected)

- .agent/workstreams/ws-20260913T004742Z-6NX5/context/agent-governance-node-intake-claude_brainstorm-006-run-1789260819142.md

```text
# Agent Run Governance Context

- Workstream: ws-20260913T004742Z-6NX5
- Target Node: intake.claude_brainstorm
- Agent Node Instance: node-intake-claude_brainstorm-006
- Run Id: run-1789260819142
- Generated At: 2026-09-13T00:53:39.167653Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789260819142/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789260819142/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789260819142/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789260819142/binding.json

- Tracked inventory: count=4; head=c84807946493a603c789ee40c6a4c615aa846c3b; sha256=df80ed33104a28c6285358790cf77533328b089bd62e5a10379e37ec6e9f9298

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - REQUIREMENT.md
  - scripts/verify-workspace.sh
- Expected edit files: (none planned)
```

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_PRODUCT_REVIEW]



Return only `task_contract_revision_patch`; do not return or copy a full proposal. The patch is bound to base proposal id `node-intake-claude_brainstorm-002:bffbcf7f8524ea57` and sha256 `bffbcf7f8524ea57fc3f9b01ee97fb2ebc45b76b8c0face925a42c3c02f33021`. Cover each authoritative routed obligation exactly once. Preserve its id and implement its text: [{"id":"CO-1","text":"在 constraints 或 acceptance_criteria 中明确响应行顺序 [ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]、各成交量字段的对应关系，以及 ts 是开盘时间的 Unix 毫秒时间戳；在现有 CandleRowParserTest.java 中用不同字段值验证映射与时间单位，避免只验证字段数。"},{"id":"CO-2","text":"在 AC-3 或 C-9 中明确安全摘要采用受控错误类别和安全内容，不直接透传上游正文或内部异常细节，并有明确长度上限；在现有 KlineApiControllerTest.java 与 WebUiBrowserTest.java 中验证异常内容不会泄漏或被作为 HTML 执行，生命周期状态仍由结构化同步结果决定。"},{"id":"CO-3","text":"修改 TR-9：stub 请求记录仅用于证明预期交互，另通过测试进程网络隔离、统一出站拦截或等效机制证明默认 mvn test 不访问公网 OKX；覆盖启动回填和调度入口，并设置尝试非本地目标时必定被阻止或导致测试失败的验证。相关实现和测试可落在已授权的 pom.xml、StubOkxServer.java 与现有同步测试路径中。"}]. Only clause ADD/REPLACE, exact scope ADD, and evidence-ref ADD are supported. No DELETE, section move, scope removal, objective/open-question change, JSON Pointer, or arbitrary field patch is allowed. `scope_additions` uses exact repository-relative paths. Each scope path must name one exact file, not a directory; it must be repository-relative, must not end with `/`, and must already be canonical (no `./`, `..`, repeated separators, backslashes, leading/trailing whitespace, `.git`, or `.agent` segments). Dual derives CREATE/MODIFY from the effective worktree. `section` is authoritative; clause IDs are opaque and their prefixes do not determine section. Across the entire `result.obligation_patches` array, each `clause_changes[].id`, `scope_additions[].path`, and `evidence_ref_additions[]` target must appear at most once. When one evidence ref supports multiple obligations, add it in one most relevant patch only; use each obligation's `resolved_by_clause_ids` to express coverage instead of adding the ref again. Each `result.obligation_patches` item is a closed object with exactly these fields: [review_obligation_id, resolved_by_clause_ids, clause_changes, scope_additions, evidence_ref_additions]. No other keys are permitted.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20260913T004742Z-6NX5",
  "run_id" : "run-1789260819142",
  "node_id" : "intake.claude_brainstorm",
  "result" : {
    "artifact_type" : "task_contract_revision_patch",
    "decision" : "READY_FOR_PRODUCT_REVIEW",
    "summary" : "one short sentence",
    "base_proposal_id" : "node-intake-claude_brainstorm-002:bffbcf7f8524ea57",
    "base_proposal_sha256" : "bffbcf7f8524ea57fc3f9b01ee97fb2ebc45b76b8c0face925a42c3c02f33021",
    "obligation_patches" : [ {
      "review_obligation_id" : "CO-1",
      "resolved_by_clause_ids" : [ "AC-1" ],
      "clause_changes" : [ {
        "operation" : "REPLACE",
        "section" : "ACCEPTANCE_CRITERIA",
        "id" : "AC-1",
        "text" : "replacement text"
      } ],
      "scope_additions" : [ {
        "path" : "repo/relative/new.ext"
      } ],
      "evidence_ref_additions" : [ "repo/relative/evidence.ext" ]
    } ]
  }
}
