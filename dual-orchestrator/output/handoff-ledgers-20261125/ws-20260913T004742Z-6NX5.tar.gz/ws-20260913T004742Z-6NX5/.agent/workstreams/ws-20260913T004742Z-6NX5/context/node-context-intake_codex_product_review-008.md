# Context Package

- Workstream: ws-20260913T004742Z-6NX5
- Builder Node: context.intake_codex_product_review
- Target Node: intake.codex_product_review
- Generated At: 2026-09-13T00:55:33.264361Z
- Profile: product_review
- Total: 4.5k / 4.0k tokens

## Context Governance

| Section | Level | Degraded | Original | Current |
|---|---|---|---|---|
| input_artifacts | full | no | 422 | 422 |
| review_evidence | full | no | 179 | 179 |
| recent_agent_outputs | full | no | 201 | 201 |
| ledger_pointers | pointer_only | yes | 170 | 161 |
| required_review_subject | full | no | 3.5k | 3.5k |

Degraded sections have full data at their original paths listed below.

## State & Evidence Boundary

This package separates deterministic harness facts from agent proposals.

### Trusted Harness Facts

- TaskContract qualification: not available
- Git Evidence: not generated yet

### Human Decisions

- Requirement Resolution: not available

### Agent Proposed States

- intake.claude_brainstorm: decision=READY_FOR_PRODUCT_REVIEW, stageOutcome=READY, evidenceState={blocking=false, evidence_count=1, missing_evidence_count=0, must_fix_count=0, acceptance_note_count=0, open_risk_count=0} (/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260819142/outputs/intake-claude-brainstorm.contract.json)

### Pending Contract/Evidence Gaps

- No contract failure diagnostics recorded

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-context-intake_codex_product_review-008/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-context-intake_codex_product_review-008/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-context-intake_codex_product_review-008/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-context-intake_codex_product_review-008/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
## Input Artifacts

### .agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260819142/outputs/intake-claude-brainstorm.stderr.log

(execution diagnostic omitted from context)

### .agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260819142/outputs/intake-claude-brainstorm.transcript.log

(execution transcript omitted from context; inspect raw file at /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260819142/outputs/intake-claude-brainstorm.transcript.log)

### .agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260819142/outputs/intake-claude-brainstorm.json

- Contract: intake.claude_brainstorm
- Decision: READY_FOR_PRODUCT_REVIEW
- Summary: 已按三项 Must Fix 修订契约：绑定 OKX 九字段位置映射与毫秒开盘时间语义、明确失败摘要内容安全与长度上限、并以测试进程统一出站拦截重构默认 mvn test 的离线性证明。
- Verification: task contract proposal validated
- Contract Sidecar: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260819142/outputs/intake-claude-brainstorm.contract.json
- Raw Output: .agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260819142/outputs/intake-claude-brainstorm.json

### .agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789260819142/binding.json

(routed artifact has no typed context projection; content omitted)

### .agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/task-contract-proposals/node-intake-claude_brainstorm-006-88a588820e99bfef.ref.json

(routed artifact has no typed context projection; content omitted)

## Review Evidence Brief

TaskContract projection: unavailable

No cumulative review verdict recorded. Review the complete current subject against the contract baseline.

- Relevant memory (reuse, do not re-read): .gitignore; README.md; REQUIREMENT.md; scripts/verify-workspace.sh

Derive the complete current blocker set from the review subject and acceptance criteria; re-read a file only with a reason (edit/verify/sha-changed/stage-gap).
Evidence: memory .agent/workstreams/ws-20260913T004742Z-6NX5/memory/workstream-memory.json; diff .agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/git-evidence/diff.patch; changed .agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/git-evidence/changed-files.txt.

## Recent Agent Outputs

### /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260819142/outputs/intake-claude-brainstorm.contract.json

- Contract: intake.claude_brainstorm
- Decision: READY_FOR_PRODUCT_REVIEW
- Summary: 已按三项 Must Fix 修订契约：绑定 OKX 九字段位置映射与毫秒开盘时间语义、明确失败摘要内容安全与长度上限、并以测试进程统一出站拦截重构默认 mvn test 的离线性证明。
- Verification: task contract proposal validated
- Contract Sidecar: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260819142/outputs/intake-claude-brainstorm.contract.json
- Raw Output: .agent/workstreams/ws-20260913T004742Z-6NX5/runs/run-1789260819142/outputs/intake-claude-brainstorm.json

## Ledger Pointers

- Events: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5/events.jsonl
- Workflow current: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5/workflow/current.json
- Node state directory: /Users/kriswang/work/proj

[adaptively compressed; section degraded to stay within ~125 tokens; full source remains in ledger under /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5]

## Required Review Subject

- Proposal ID: node-intake-claude_brainstorm-006:88a588820e99bfef
- Proposal Reference: .agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/task-contract-proposals/node-intake-claude_brainstorm-006-88a588820e99bfef.ref.json
- Proposal SHA-256: 88a588820e99bfefc1107e7cc262e29474fec89ba984c762af908c370dc110ea

<!-- dual:typed-payload:start -->
```json
{
  "artifact_type" : "task_contract_proposal",
  "schema_version" : 3,
  "objective" : "构建 Java 25 + Spring Boot 4.1.0 + MyBatis-Plus 3.5.17 + SQLite 的本地 Web 应用：直连 OKX 官方公开行情 REST API 拉取 BTC-USDT 现货 1m K 线并幂等持久化，提供稳定 JSON API 与可定时刷新、无运行时 CDN 依赖的蜡烛图界面。",
  "scope" : {
    "included" : [ {
      "path" : "pom.xml",
      "operation" : "CREATE"
    }, {
      "path" : "README.md",
      "operation" : "MODIFY"
    }, {
      "path" : "scripts/live-smoke.sh",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/application.yml",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/schema.sql",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/index.html",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/css/app.css",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/js/app.js",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/vendor/lightweight-charts.standalone.production.js",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/OkxKlineApplication.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/config/OkxProperties.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/config/SchedulingConfig.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/CandleEntity.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/CandleMapper.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/SyncStateEntity.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/SyncStateMapper.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/DecimalTextTypeHandler.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxMarketClient.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxApiResponse.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/CandleRowParser.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/CandleSyncService.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/SyncScheduler.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/SyncStateService.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/KlineApiController.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/GlobalExceptionHandler.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/KlinePointResponse.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/SyncStatusResponse.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/ApiErrorResponse.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/CandleRowParserTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/CandleSyncServiceTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/SyncSchedulerOverlapTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/KlineApiControllerTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/persistence/SqlitePersistenceTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/WebUiBrowserTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/support/StubOkxServer.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/livesmoke/LiveSmokeTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/application-test.yml",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx-candles-normal.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx-candles-reversed.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx-candles-stale.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx-business-error.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx-malformed.json",
      "operation" : "CREATE"
    } ],
    "excluded" : [ "任何 OKX 私有 API、交易、下单、账户访问、认证或 API Key 集成", "抓取 OKX HTML 页面或经由代理业务服务获取行情", "WebSocket 行情接入", "多交易品种或多 K 线周期切换", "分布式调度或多实例协调", "用户账户体系或管理后台", "通用交易所抽象或行情平台化", "运行时 CDN 依赖", "scope.included 之外的任何仓库路径变更（含 .git/ 与 .agent/）" ]
  },
  "acceptance_criteria" : [ {
    "id" : "AC-1",
    "text" : "同步启用时，应用启动后自动执行一次初始回填：通过 OKX 官方公开接口 GET /api/v5/market/candles（instId=BTC-USDT、bar=1m、limit=300）拉取并保存最近 300 根 K 线；全程不需要 API Key 或 OKX 账户。"
  }, {
    "id" : "AC-2",
    "text" : "GET /api/klines 返回最近最多 300 根已保存 K 线并按开盘时间严格升序排列；limit 缺省取合法默认值，limit 为非整数、≤0 或 >300 时返回带明确错误信息的 4xx 客户端错误。"
  }, {
    "id" : "AC-3",
    "text" : "GET /api/sync/status 返回当前生命周期状态（如 running/degraded）、最近一次尝试时间、最近一次成功时间和最近失败的失败摘要；失败摘要由受控错误类别（仅限 HTTP_TIMEOUT、HTTP_STATUS、RATE_LIMITED、OKX_BUSINESS_ERROR、INVALID_PAYLOAD、DATABASE_ERROR 等预定义枚举之一）与安全摘要文本组成，文本长度上限 256 字符（超长截断），内容不得包含 OKX 响应正文原文、异常类名/消息/堆栈、JDBC URL 或其他内部细节；生命周期状态仅由结构化同步结果事件驱动，错误文本仅作为展示字段，不参与状态判定。"
  }, {
    "id" : "AC-4",
    "text" : "SQLite 对 (instrument, bar, open_time) 建立唯一约束；重复同步幂等；confirm=0 的未闭合 K 线在同一键上原位更新；应用重启后已闭合（confirm=1）K 线仍可通过 API 查询。"
  }, {
    "id" : "AC-5",
    "text" : "对按时间倒序返回或命中较旧缓存的响应，同步仅按开盘时间键执行 upsert，任何情况下不删除本地较新的 K 线；单次响应中的全部合法 K 线在同一事务内完成写入。"
  }, {
    "id" : "AC-6",
    "text" : "HTTP 超时、非 2xx、429 限流、OKX 业务错误（code!=0）、非法 JSON、非法行或数据库异常发生时：既有 K 线全部保留，同步状态进入 degraded，不进行无界立即重试，等待下一轮调度。"
  }, {
    "id" : "AC-7",
    "text" : "单应用实例内同步调度永不重叠（含单轮执行时间超过轮询周期的情况）；默认每 15 秒轮询且周期可配置；OKX base URL、连接超时、读取超时和同步开关均支持外部配置。"
  }, {
    "id" : "AC-8",
    "text" : "首屏直接呈现行情界面而非营销页：真实蜡烛 K 线与成交量图、BTC / USDT、1m、最新收盘价、最近闭合 K 线时间、同步状态和最近成功刷新时间；浏览器默认每 10 秒从本应用后端拉取数据且不整页重载。"
  }, {
    "id" : "AC-9",
    "text" : "同步 degraded 时前端保留最后可用图表并显示克制清晰的状态提示；首次加载、无数据、数据降级和后端失败状态均被正确处理；桌面与移动视口下文字、图表和操作不重叠；不把模拟价格冒充为 OKX 实时行情。"
  }, {
    "id" : "AC-10",
    "text" : "价格与成交量在 Java 侧以 BigDecimal、SQLite 侧以 TEXT 列存储（经自定义 TypeHandler 映射），不以二进制浮点数作为权威值。"
  }, {
    "id" : "AC-11",
    "text" : "K 线图表库为成熟方案且其生产资源随应用本地打包；运行时不发起任何 CDN 请求；浏览器只调用本应用同源后端 API，不直接请求 OKX。"
  }, {
    "id" : "AC-12",
    "text" : "Java 25 环境下执行 mvn test 全部通过，且测试执行期间不访问公网 OKX；所有 OKX 交互由本地契约一致的 HTTP stub 与冻结 fixture 模拟。"
  }, {
    "id" : "AC-13",
    "text" : "提供显式 opt-in 的 live smoke 命令（scripts/live-smoke.sh，经 Maven profile 运行 @Tag(\"live-smoke\") 测试），直连 OKX 官方接口发起一次只读请求并验证至少一根结构合法（9 字段且 confirm 合法）的 BTC-USDT 1m K 线；该命令不在默认 mvn test 中执行。"
  }, {
    "id" : "AC-14",
    "text" : "数据库 schema 由仓库内版本化且幂等的初始化文件（schema.sql）确定地创建，业务代码中不存在临时拼接的建表流程。"
  }, {
    "id" : "AC-15",
    "text" : "README 完整记录架构、配置项、SQLite 路径、启动方式、测试、live smoke、后端 API、数据新鲜度语义和已知限制。"
  }, {
    "id" : "AC-16",
    "text" : "日志仅记录必要运行元数据（如轮次序号、状态、耗时、错误类别），失败时不得打印完整 OKX 响应正文。"
  } ],
  "test_requirements" : [ {
    "id" : "TR-1",
    "text" : "CandleRowParserTest 覆盖：(a) 位置映射与时间单位验证——构造九个字段值互不相同的合法行（o/h/l/c 各取不同价格，vol/volCcy/volCcyQuote 各取不同数量，ts 取已知毫秒值），断言解析结果的 open/high/low/close、三个成交量字段、confirm 与 open_time 逐一等于对应位置输入，且 open_time 保持毫秒精度（若按秒解释会得到不同时间，以此证明单位正确），而非仅校验字段个数；(b) confirm=0/1 语义；(c) 字段数错误（多于或少于 9）、价格/成交量数值非法、confirm 取值非法、行结构非数组等畸形输入均被整体拒绝且不产生部分写入。"
  }, {
    "id" : "TR-2",
    "text" : "CandleSyncServiceTest 使用本地 HTTP stub 与临时 SQLite 覆盖：首次回填 300 根、倒序输入、重复同步幂等、未闭合 K 线原位更新、闭合 K 线持久化、陈旧响应不删除较新数据。"
  }, {
    "id" : "TR-3",
    "text" : "失败路径测试用 stub 精确制造公网无法稳定制造的场景：连接/读取超时、429、非 2xx、OKX 业务错误、非法 JSON envelope、合法 envelope 内的非法行、数据库异常；断言既有数据保留、状态转为 degraded、无立即无界重试。"
  }, {
    "id" : "TR-4",
    "text" : "SyncSchedulerOverlapTest 以远小于执行时长的轮询周期驱动慢速同步，断言单实例内不存在重叠并发执行（跳过本轮或顺延均可，但绝不并发）。"
  }, {
    "id" : "TR-5",
    "text" : "KlineApiControllerTest 覆盖：按 open_time 升序、limit 边界（缺省、1、300、0、负数、非整数、301）、健康状态字段完整性、同步失败后已有 K 线仍可查询；另验证失败摘要内容安全——stub 注入带可识别标记串的响应正文与异常细节后，断言 /api/sync/status 的失败摘要只含受控错误类别与截断后的安全文本（长度不超过 256 字符上限），不包含标记串、堆栈或内部细节，且状态字段仍由结构化同步结果决定而非错误文本。"
  }, {
    "id" : "TR-6",
    "text" : "SqlitePersistenceTest 使用临时 SQLite 文件验证：(instrument, bar, open_time) 唯一约束生效，且应用重启（新建 Spring 上下文/新连接）后已闭合 K 线仍可查询。"
  }, {
    "id" : "TR-7",
    "text" : "WebUiBrowserTest 提供浏览器级或 DOM 级验证：图表消费本应用后端（stub 行情）数据、观测到定时刷新（测试内缩短轮询周期验证多次拉取）、页面发起的全部网络请求均为同源后端请求（无任何 OKX 或 CDN 调用）、降级状态提示正确展示；降级提示中的失败信息以纯文本渲染——在 stub 响应中注入 script 标签与 onerror 属性等可执行标记串，断言其不被作为 HTML 执行（无新增脚本元素、无副作用）且不出现上游正文的原样泄漏。"
  }, {
    "id" : "TR-8",
    "text" : "live smoke 验证：执行 scripts/live-smoke.sh 直连 OKX 官方接口，断言至少一根 9 字段结构合法且 confirm 合法的 BTC-USDT 1m K 线；默认 surefire 配置排除 live-smoke tag，证明其不进入默认 mvn test。"
  }, {
    "id" : "TR-9",
    "text" : "在 Java 25 下执行 mvn test 全部通过；离线性证明分层实施且互不混淆：(a) stub 请求记录仅用于证明预期交互——启动回填与每一轮调度轮次确实命中本地 stub 的 /api/v5/market/candles 契约端点，不得据此声称不存在其他出站请求；(b) 测试 JVM 内启用统一出站拦截（由 StubOkxServer.java 提供并在测试基线注册的全局守卫，例如仅放行 loopback stub 地址的 ProxySelector 或等效 Socket 级拦截，必要时经 pom.xml 的 surefire 配置统一注入），使任何指向非本地 OKX 目标的出站尝试必定被阻止并令当轮同步以失败告终；(c) 提供守卫自检用例——显式尝试非本地目标时请求被阻止或测试失败，证明拦截机制本身生效；(d) 启动回填与调度同步两个入口路径均须在该拦截开启状态下运行并被验证。"
  } ],
  "constraints" : [ {
    "id" : "C-1",
    "text" : "技术栈锁定：Java 25、Spring Boot 4.1.0、Maven 构建。"
  }, {
    "id" : "C-2",
    "text" : "持久层仅使用 MyBatis-Plus 3.5.17 且必须引入 mybatis-plus-spring-boot4-starter；禁止 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施。"
  }, {
    "id" : "C-3",
    "text" : "SQLite 是唯一应用数据库；K 线数据与同步状态均持久化在 SQLite。"
  }, {
    "id" : "C-4",
    "text" : "数据源仅限 OKX 官方公开 Market Data REST API（GET /api/v5/market/candles），品种固定 BTC-USDT 现货、周期固定 1m；禁止抓取 OKX HTML 页面；禁止任何 API Key 或账户凭证。"
  }, {
    "id" : "C-5",
    "text" : "生产应用与显式 live smoke 必须直连 OKX 官方 API，不得经由测试桩、代理业务服务或抓取服务替代；自动化测试必须使用本地契约一致的 HTTP stub 与冻结 fixture，不得依赖公网 OKX。"
  }, {
    "id" : "C-6",
    "text" : "OKX base URL、连接超时、读取超时、同步开关和同步周期（默认 15 秒）均通过外部配置注入，不得硬编码于业务逻辑。"
  }, {
    "id" : "C-7",
    "text" : "每轮同步必须先完整解析并校验 OKX envelope 与全部数据行，随后才在同一事务内 upsert；失败轮不写入部分数据、不删除既有数据。"
  }, {
    "id" : "C-8",
    "text" : "禁止无界立即重试；失败后记录 degraded 状态并等待下一轮调度；调度采用 fixedDelay 语义 + 单线程调度器 + 防重入守卫，保证单实例内不重叠。"
  }, {
    "id" : "C-9",
    "text" : "同步状态持久化到 SQLite，包含最近一次尝试、最近一次成功和最近失败；最近失败仅保存受控错误类别（预定义枚举）与安全摘要文本（长度上限 256 字符，超长截断），不保存或透传上游响应正文、异常堆栈或内部细节；生命周期状态由同步结果事件驱动，错误文本不得反向成为生命周期状态 owner。"
  }, {
    "id" : "C-10",
    "text" : "字段位置契约与 decimal-safe 表示：OKX 响应行严格按位置解析为 [ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm] 九个字段——row[0]=ts 为该 K 线开盘时间的 Unix 毫秒时间戳，row[1]=o 开盘价，row[2]=h 最高价，row[3]=l 最低价，row[4]=c 收盘价，row[5]=vol、row[6]=volCcy、row[7]=volCcyQuote 三个成交量字段按位置一一映射到各自独立列，不得互换、重排或合并，row[8]=confirm（0=未闭合、1=已闭合）；价格与成交量 Java 侧为 BigDecimal、SQLite 侧为 TEXT（自定义 TypeHandler 映射），不以二进制浮点数作为权威值；open_time 为 Unix 毫秒整数列，排序与去重仅基于该整数列。"
  }, {
    "id" : "C-11",
    "text" : "schema 初始化确定且版本化：仓库内 schema.sql（幂等 CREATE TABLE/INDEX IF NOT EXISTS）+ SQL init 配置执行，业务代码不得拼接 DDL。"
  }, {
    "id" : "C-12",
    "text" : "前端使用成熟 K 线图表库（TradingView Lightweight Charts standalone production 构建），其生产资源置于应用静态资源目录随应用本地打包；禁止运行时 CDN。"
  }, {
    "id" : "C-13",
    "text" : "浏览器仅调用本应用同源后端 API（默认每 10 秒拉取、无整页刷新）；后端 API 路径与响应结构保持稳定并记录于 README。"
  }, {
    "id" : "C-14",
    "text" : "日志仅输出必要运行元数据；失败日志不得包含完整 OKX 响应正文。"
  }, {
    "id" : "C-15",
    "text" : "live smoke 为显式 opt-in 命令（脚本包装 Maven profile），不得纳入默认 mvn test。"
  } ],
  "non_goals" : [ {
    "id" : "NG-1",
    "text" : "交易、下单、账户访问、认证、API Key、余额查询或任何 OKX 私有 API。"
  }, {
    "id" : "NG-2",
    "text" : "投资建议、告警、策略、技术指标或价格预测。"
  }, {
    "id" : "NG-3",
    "text" : "WebSocket 行情接入。"
  }, {
    "id" : "NG-4",
    "text" : "多交易品种或多 K 线周期切换。"
  }, {
    "id" : "NG-5",
    "text" : "分布式调度或多实例协调。"
  }, {
    "id" : "NG-6",
    "text" : "用户账户体系或管理后台。"
  }, {
    "id" : "NG-7",
    "text" : "通用交易所抽象或行情平台化。"
  }, {
    "id" : "NG-8",
    "text" : "运行时 CDN 依赖或任何对第三方前端站点的运行时请求。"
  } ],
  "risk_areas" : [ {
    "id" : "R-1",
    "text" : "Spring Boot 4.1.0 与 MyBatis-Plus 3.5.17（mybatis-plus-spring-boot4-starter）组合较新，自动装配细节可能需要适配；如遇兼容问题在 pom.xml 与配置内解决，不改变行为契约。"
  }, {
    "id" : "R-2",
    "text" : "SQLite 无原生 DECIMAL 类型；TEXT + BigDecimal TypeHandler 是 decimal-safe 方案，需确保排序、limit 与去重仅依赖 open_time 整数列而非价格文本。"
  }, {
    "id" : "R-3",
    "text" : "浏览器级验证选用 Playwright for Java，首次运行需下载浏览器二进制（非 OKX 网络依赖）；若环境受限可在同一测试文件 WebUiBrowserTest.java 内降级为 DOM 级 HtmlUnit 方案，验证语义不变。"
  }, {
    "id" : "R-4",
    "text" : "OKX 陈旧缓存可能使未闭合 K 线短暂回写较旧字段值；按 (instrument, bar, open_time) 键 last-write-wins upsert 符合契约（禁止删除），README 将说明该新鲜度语义。"
  }, {
    "id" : "R-5",
    "text" : "前端 10 秒与后端 15 秒刷新节奏不同步属预期，README 需说明数据新鲜度语义（最近闭合 K 线时间 + 最近成功刷新时间）避免误解。"
  } ],
  "evidence_refs" : [ "REQUIREMENT.md", "README.md", "scripts/verify-workspace.sh", ".gitignore" ],
  "open_questions" : [ ],
  "revision_responses" : [ {
    "review_obligation_id" : "CO-1",
    "resolved_by_clause_ids" : [ "C-10", "TR-1" ]
  }, {
    "review_obligation_id" : "CO-2",
    "resolved_by_clause_ids" : [ "AC-3", "C-9", "TR-5", "TR-7" ]
  }, {
    "review_obligation_id" : "CO-3",
    "resolved_by_clause_ids" : [ "TR-9" ]
  } ]
}
```
<!-- dual:typed-payload:end -->

