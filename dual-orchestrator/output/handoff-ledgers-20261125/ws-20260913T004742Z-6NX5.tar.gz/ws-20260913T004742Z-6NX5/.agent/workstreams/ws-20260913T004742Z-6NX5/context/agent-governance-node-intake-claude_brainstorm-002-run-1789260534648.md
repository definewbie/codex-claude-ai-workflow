# Agent Run Governance Context

- Workstream: ws-20260913T004742Z-6NX5
- Target Node: intake.claude_brainstorm
- Agent Node Instance: node-intake-claude_brainstorm-002
- Run Id: run-1789260534648
- Generated At: 2026-09-13T00:48:54.691459Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1789260534648/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1789260534648/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1789260534648/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1789260534648/binding.json

- Tracked inventory: count=4; head=c84807946493a603c789ee40c6a4c615aa846c3b; sha256=df80ed33104a28c6285358790cf77533328b089bd62e5a10379e37ec6e9f9298

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - REQUIREMENT.md
  - scripts/verify-workspace.sh
- Expected edit files: (none planned)
