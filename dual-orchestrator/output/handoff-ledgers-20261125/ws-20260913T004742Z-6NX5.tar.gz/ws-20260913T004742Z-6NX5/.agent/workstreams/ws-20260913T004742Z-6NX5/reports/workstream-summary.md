# Workstream Summary

- Workstream: ws-20260913T004742Z-6NX5
- Workspace: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5
- Ledger: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5
- Generated At: 2026-09-13T01:00:22.325452Z

## Workflow

- Definition: agent-lifecycle-small-plan-human-review-experiment@1
- Status: WAITING_FOR_RECOVERY
- Status Source: workflow_current
- Active Nodes: node-intake-claude_brainstorm-012
- Open Gates: recovery-node-intake-claude_brainstorm-012
- Updated At: 2026-09-13T01:00:22.307504Z

## Metrics

- Nodes: 11
- Agent Runs: 5
- Gates: 1
- Decisions: 2
- Iterations: 3
- Revisions: 2
- Total Node Duration(ms): 431115
- Token Runs: 4 / 4
- Total Tokens: 159295 (input 67065, output 28614)
- Metrics: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5/metrics/workstream-metrics.md

## Recommended Next Action

Agent output incomplete

The final ACP assistant message did not contain a valid AgentResultEnvelope.

Inspect the agent output contract, then retry the same active node.

```bash
dualctl recovery show --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5' ws-20260913T004742Z-6NX5
dualctl retry --workdir /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5 ws-20260913T004742Z-6NX5
```

## Recent Timeline

| Node | Kind | Status | Iteration | Duration |
| --- | --- | --- | --- | --- |
| context.intake_claude_brainstorm | TASK | COMPLETED | iter-001 | 33 |
| intake.claude_brainstorm | TASK | COMPLETED | iter-001 | 224757 |
| context.intake_codex_product_review | TASK | COMPLETED | iter-001 | 47 |
| intake.codex_product_review | TASK | COMPLETED | iter-001 | 59582 |
| intake.decision | DECISION | COMPLETED | iter-001 | 11 |
| intake.claude_brainstorm | TASK | COMPLETED | iter-002 | 114085 |
| context.intake_codex_product_review | TASK | COMPLETED | iter-002 | 23 |
| intake.codex_product_review | TASK | COMPLETED | iter-002 | 32529 |
| intake.decision | DECISION | COMPLETED | iter-002 | 10 |
| gate.human_requirement_review | GATE | COMPLETED | iter-002 |  |
| intake.claude_brainstorm | TASK | FAILED | iter-003 | 38 |

## Artifacts

- Final Report: missing
- Current Failure Summary: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5/.agent/workstreams/ws-20260913T004742Z-6NX5/recovery/current-failure.md
- Delivery: BLOCKED, changedFiles=0, target=/Users/kriswang/work/projects/ai/okx-btc-k-line-demo, reason=WORKFLOW_NOT_DELIVERABLE:workstream is not completed: WAITING_FOR_RECOVERY
- Calibration Candidates: 0
- Calibration Apply Plans: 0

## Useful Commands

```bash
dualctl status --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5' ws-20260913T004742Z-6NX5
dualctl timeline --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5' ws-20260913T004742Z-6NX5
dualctl review show --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5' ws-20260913T004742Z-6NX5
dualctl recovery show --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260913T004742Z-6NX5' ws-20260913T004742Z-6NX5
```
