# Agent Run Governance Context

- Workstream: ws-20260913T004742Z-6NX5
- Target Node: intake.codex_product_review
- Agent Node Instance: node-intake-codex_product_review-009
- Run Id: run-1789260933290
- Generated At: 2026-09-13T00:55:33.293322Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-codex_product_review-009-run-1789260933290/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-codex_product_review-009-run-1789260933290/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-codex_product_review-009-run-1789260933290/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260913T004742Z-6NX5/artifacts/context-governance/occurrences/node-intake-codex_product_review-009-run-1789260933290/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
