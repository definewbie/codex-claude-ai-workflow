# Workstream Metrics

- Workstream: ws-20260913T004742Z-6NX5
- Workflow: agent-lifecycle-small-plan-human-review-experiment@1
- Status: WAITING_FOR_RECOVERY
- Generated At: 2026-09-13T01:00:22.314258Z

## Counts

- Nodes: 11
- Agent Runs: 5
- Gates: 1
- Decisions: 2
- Iterations: 3
- Revisions: 2
- Total Node Duration(ms): 431115

## Longest Nodes

| Node | Status | Iteration | Duration(ms) |
| --- | --- | --- | --- |
| intake.claude_brainstorm | COMPLETED | iter-001 | 224757 |
| intake.claude_brainstorm | COMPLETED | iter-002 | 114085 |
| intake.codex_product_review | COMPLETED | iter-001 | 59582 |
| intake.codex_product_review | COMPLETED | iter-002 | 32529 |
| context.intake_codex_product_review | COMPLETED | iter-001 | 47 |

## Provider Metrics

| Provider | Runs | Completed | Failed | Recoverable | Total Duration(ms) | Average Duration(ms) |
| --- | --- | --- | --- | --- | --- | --- |
| claude | 2 | 2 | 0 | 0 | 332210 | 166105 |
| codex | 2 | 2 | 0 | 0 | 87104 | 43552 |
| outcomeStatusCounts | null | null | null | null | null | null |
| executionConsistencyCounts | null | null | null | null | null | null |

## Token Metrics

- Measured Runs: 4 / 4
- Session Snapshots: 0
- Estimated Runs: 0
- Input Tokens: 67065
- Output Tokens: 28614
- Cached Read Tokens: 63616
- Cached Write Tokens: 0
- Total Tokens: 159295
- Estimated Tokens (fallback, not in total): 0

### Token Usage By Step

| Node | Agent | Status | Outcome | Source | Input | Output | Transcript | Context | Prompt Overhead | Adapter Overhead | Total |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| intake.claude_brainstorm | claude | completed | SUCCESS | acpx_stream | 8657 | 18350 | 5393 | 991 | 4225 | 3441 | 33023 |
| intake.codex_product_review | codex | completed | SUCCESS | acpx_stream | 19874 | 1452 | 1256 | 5133 | 4607 | 10134 | 34254 |
| intake.claude_brainstorm | claude | completed | SUCCESS | acpx_stream | 19976 | 7961 | 3316 | 991 | 9378 | 9607 | 39969 |
| intake.codex_product_review | codex | completed | SUCCESS | acpx_stream | 18558 | 851 | 725 | 5133 | 5379 | 8046 | 52049 |

### Top Context Sections

| Target Node | Profile | Section | Rendered | Original | Degraded | Dropped |
| --- | --- | --- | --- | --- | --- | --- |
| intake.codex_product_review | product_review | input_artifacts | 422 | 422 | false | false |
| intake.codex_product_review | product_review | recent_agent_outputs | 201 | 201 | false | false |
| intake.codex_product_review | product_review | review_evidence | 179 | 179 | false | false |
| intake.claude_brainstorm | intake | ledger_pointers | 161 | 170 | true | false |
| intake.codex_product_review | product_review | ledger_pointers | 161 | 170 | true | false |
| intake.claude_brainstorm | intake | task_contract | 0 | 0 | false | false |

## Tool Metrics

- Tool Calls: 8
- Reads: 8
- Writes: 0
- Bash Commands: 0
- Evidence Files: 0

### Repeated Read Files

| File | Reads | Agents | Nodes | Evidence Known | Reread Reason |
| --- | --- | --- | --- | --- | --- |
| .gitignore | 2 | claude | intake.claude_brainstorm | false | not_required |
| README.md | 2 | claude | intake.claude_brainstorm | false | not_required |
| REQUIREMENT.md | 2 | claude | intake.claude_brainstorm | false | not_required |
| scripts/verify-workspace.sh | 2 | claude | intake.claude_brainstorm | false | not_required |
