# Contract Failure Diagnostic

- Category: contract_violation
- Reason: DESIGN_SCOPE_INVALID
- Node: design.claude_design
- Node Instance: node-design-claude_design-014
- Source Output: .agent/workstreams/ws-20260912T081920Z-KPPZ/runs/run-1789202097910/outputs/design-claude.json
- Recommended Owner: harness_or_prompt

## Message

Design is not within the approved contract

## Recovery Hint

Inspect the diagnostic details, prompt contract, and source output before retrying the node.

## Contract Shape

- Required Keys: [summary, decision]
- Allowed Decisions: [READY_FOR_ARCH_REVIEW]
