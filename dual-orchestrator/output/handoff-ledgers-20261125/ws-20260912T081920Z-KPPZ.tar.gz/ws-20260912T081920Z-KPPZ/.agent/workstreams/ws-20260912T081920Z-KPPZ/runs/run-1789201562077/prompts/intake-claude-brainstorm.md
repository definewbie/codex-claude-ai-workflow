## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ
- This intake run uses restricted contract discovery. Use orchestrator-provided context and bounded discovery only.
- Do not output shell commands or Bash code fences as a substitute for the required structured artifact.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.



# Claude Intake Brainstorm

Workstream: ws-20260912T081920Z-KPPZ
Node: intake.claude_brainstorm
Template: intake-claude-brainstorm
Ledger: .agent/workstreams/ws-20260912T081920Z-KPPZ

You are Claude acting as the primary developer and product-design partner.

Use the orchestrator-provided seed, tracked-path inventory, memory, contract scope, and context recommendations to clarify the user request before implementation. This intake stage permits targeted Read/Grep/Glob discovery inside the effective workspace so the contract can be grounded in repository facts. Start from the projected repo map, inspect only the files needed to determine exact scope and acceptance semantics, and do not start an open-ended repository survey. Terminal, Bash, execute, write, edit, and file creation remain prohibited. When the tracked inventory is non-empty, `evidence_refs` must include at least one existing repository file that supports the proposed scope; additional durable evidence references remain allowed. Do not return `READY_FOR_PRODUCT_REVIEW` from filenames or requirement prose alone. If evidence remains insufficient, preserve the uncertainty in supported fields for reviewer/human judgment; do not end with a prose-only "I need to inspect the repo" message.

If the context package includes a previous Codex review, Must Fix list, or revision request, treat it as mandatory feedback for this intake revision. Explicitly address each Must Fix in the updated artifact instead of repeating the previous draft.

Revision convergence policy:

- Must Fix feedback is stronger than the previous draft. The revised proposal must change the contract enough that each Must Fix is satisfied by construction.
- Do not move an already-specified user constraint into `open_questions`. If the user request or Codex Must Fix already states the rule, encode the rule directly into `acceptance_criteria`, `constraints`, and `test_requirements`.
- Before returning `READY_FOR_PRODUCT_REVIEW`, account for every explicit user objective, allowed/excluded file, behavior constraint, acceptance criterion, and verification requirement in a binding proposal field: `objective`, `scope`, `acceptance_criteria`, `test_requirements`, `constraints`, or `non_goals`. A requirement mentioned only in `risk_areas`, `open_questions`, or `evidence_refs` is not preserved.
- For an initial proposal over a non-empty tracked inventory, include at least one `evidence_refs` entry from the projected repo map. Evidence references support scope reasoning but never authorize edits by themselves.
- Do not copy the current node's `AgentResultEnvelope`, JSON-only output, or workflow-routing protocol into the task proposal. Those are enforced independently by the orchestrator's Output Contract and are not product or implementation requirements.
- Preserve the user's semantic boundary exactly. Do not broaden or narrow behavior based on language-specific edge cases, inferred product preferences, or a conservative implementation choice that the user did not request.
- Treat the typed scope projected by the Output Contract as the exhaustive authorization set for permitted repository changes. It does not require every declared path to be changed. Do not use acceptance criteria, constraints, risks, or other prose to authorize undeclared paths, and never describe typed scope as illustrative or non-exhaustive. When a revision obligation identifies a scope gap, use only the exact typed scope-addition field rendered by the Output Contract and map the obligation to one or more genuinely relevant clause IDs.
- Use `open_questions` only for real product ambiguity that cannot be resolved from the user request, repository evidence, or prior Codex feedback.
- If an implementation tradeoff does not change user-visible semantics, choose the simplest compliant implementation and record material risk in `risk_areas`. If it would change the accepted input, output, scope, or observable behavior, preserve the literal user requirement and record the unresolved choice without turning it into a constraint or test.
- When revising after a Codex Must Fix, include at least one acceptance criterion or test requirement for each Must Fix. Do not claim readiness while leaving a Must Fix as a future human decision.

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.
- Even when repository evidence is insufficient, the final assistant message must be the required strict JSON result. A prose-only response is a contract failure.

## User Request

# OKX BTC 分钟级 K 线 Web 应用需求

## 目标

构建一个本地 Web 应用，通过 OKX 官方公开行情 REST API 获取 BTC-USDT 现货分钟级 K 线，将数据持久化到 SQLite，并展示可定时刷新的 K 线图。

本应用只读取公开行情，不得下单、访问账户、提供投资建议或抓取 OKX 网页。

## 强制技术栈

- Java 25。
- Spring Boot 4.1.0。
- Maven。
- MyBatis-Plus 3.5.17，必须使用 `mybatis-plus-spring-boot4-starter`。
- SQLite 是唯一应用数据库。
- 使用成熟的 K 线图表库，生产资源必须随应用本地打包，不得依赖运行时 CDN。

不得用 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施替代 MyBatis-Plus。

## OKX 行情契约

- 数据源只能是 OKX 官方公开 Market Data REST API，不得抓取 HTML 页面。
- 交易品种固定为 BTC-USDT 现货。
- K 线周期固定为 `1m`。
- 接口为 `GET /api/v5/market/candles`。
- 首次启动拉取并保存最近 300 根 K 线。
- 响应行格式为 `[ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]`。
- `ts` 是 K 线开盘时间的 Unix 毫秒时间戳。
- `confirm=0` 表示当前 K 线尚未闭合，后续允许更新。
- `confirm=1` 表示 K 线已经闭合。
- OKX 可能按时间倒序返回数据，后一次请求也可能命中较旧缓存。应用不得假设响应严格单调，也不得因旧响应删除本地较新的 K 线。
- OKX base URL、连接/读取超时、调度开关和刷新周期必须支持外部配置。
- 调用公开行情不得要求 API Key 或 OKX 账户。
- 生产应用和显式 live smoke 必须直接调用 OKX 官方 API，不得通过测试桩、代理业务服务或抓取服务替代。

## 数据持久化

- 通过 MyBatis-Plus 将 K 线保存到 SQLite。
- 数据库必须对 `(instrument, bar, open_time)` 建立唯一约束。
- 重复同步必须幂等。
- 未闭合 K 线应原位更新。
- 已闭合 K 线在应用重启后仍可查询。
- 价格和成交量不得以二进制浮点数作为权威值，Java 与 SQLite 均采用 decimal-safe 表示。
- 保存足够的同步状态，以展示最近一次尝试、最近一次成功和最近失败；错误文本不得反向成为生命周期状态 owner。
- 数据库初始化必须确定且版本化，不得在业务代码中临时拼接建表流程。

## 定时同步

- 启用同步时，应用启动后执行一次初始回填。
- 默认每 15 秒轮询一次 OKX，周期可配置。
- 每轮必须先完整解析并校验 OKX envelope，再写数据库。
- 同一响应中的合法 K 线在一个事务内完成 upsert。
- HTTP 超时、非 2xx、OKX 业务错误、限流、非法 JSON、非法行或数据库异常不得删除已有 K 线。
- 不得进行无界立即重试；失败后记录 degraded 状态，等待下一轮调度。
- 单应用实例内不得出现重叠调度执行。
- 日志只记录必要运行元数据，失败时不得打印完整 OKX 响应正文。

## 后端 API

提供稳定 JSON API：

1. 查询最近最多 300 根已保存 K 线，按开盘时间升序返回。
2. 查询同步健康状态，包括当前状态、最近尝试时间、最近成功时间和有界安全的失败摘要。

非法 limit 必须返回明确的客户端错误。浏览器只能调用本应用后端，不得直接请求 OKX。

## Web 体验

- 首屏直接展示可用的行情界面，而不是营销落地页。
- 展示真实蜡烛 K 线和成交量。
- 展示 `BTC / USDT`、`1m`、最新收盘价、最近闭合 K 线时间、同步状态和最近成功刷新时间。
- 浏览器默认每 10 秒从后端刷新数据，不整页重载。
- 同步 degraded 时保留最后可用图表，并显示克制但清晰的状态。
- 正确处理首次加载、无数据、数据降级和后端失败状态。
- 当前桌面和移动端视口均应可用，文字、图表和操作不得重叠。
- 不得把模拟价格冒充为 OKX 实时行情。

## 验证要求

- 生产实现只能直连 OKX 官方公开 API。
- `mvn test` 不得依赖公网 OKX 的可用性；自动化测试使用本地、契约一致的 HTTP stub 和冻结 fixture，专门验证正常响应及公网无法稳定制造的超时、429、乱序、陈旧缓存与畸形响应。
- 测试必须覆盖首次回填、倒序输入、重复同步、未闭合 K 线更新、闭合 K 线持久化、陈旧响应、非法 envelope、非法行、超时、非 2xx、OKX 业务错误和调度不重叠。
- 使用临时 SQLite 数据库验证唯一约束与重启后持久化。
- 覆盖后端 API 排序、limit 校验、健康状态，以及同步失败后保留已有数据。
- 提供浏览器级或 DOM 级验证，证明图表消费本应用后端数据、定时刷新且不从浏览器调用 OKX。
- Java 25 下执行 `mvn test` 必须通过，并且测试执行期间无需访问公开 OKX API。
- 提供显式 opt-in live smoke 命令，直接向 OKX 官方接口发起一次只读请求，并验证至少一根结构合法的 BTC-USDT 1m K 线；该命令不得进入默认 `mvn test`。
- README 必须记录架构、配置、SQLite 路径、启动、测试、live smoke、API、数据新鲜度语义和限制。

## 不在范围内

- 交易、账户访问、认证、API Key、余额或任何私有 OKX API。
- 投资建议、告警、策略、技术指标或预测。
- WebSocket 行情。
- 多交易品种或多周期切换。
- 分布式调度或多实例协调。
- 用户账户或管理后台。
- 通用交易所抽象或行情平台。
- 运行时 CDN 依赖。



## Context Package

### Direct Input Artifacts

- .agent/workstreams/ws-20260912T081920Z-KPPZ/runs/run-1789201481364/outputs/intake-codex-product-review.stderr.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260912T081920Z-KPPZ/runs/run-1789201481364/outputs/intake-codex-product-review.transcript.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260912T081920Z-KPPZ/runs/run-1789201481364/outputs/intake-codex-product-review.json

```json
{
  "workstreamId" : "ws-20260912T081920Z-KPPZ",
  "runId" : "run-1789201481364",
  "nodeId" : "intake.codex_product_review",
  "nodeInstanceId" : "node-intake-codex_product_review-004",
  "stageOutcome" : "NEEDS_REVISION",
  "lifecycleStatus" : "NEEDS_REVISION",
  "decision" : "NEEDS_REVISION",
  "summary" : "提案整体符合产品目标，但行情行契约和两项关键验证要求尚未完整保留，需要补齐后推进。",
  "sourceArtifactType" : "agent_output_contract",
  "sourceOutputRef" : ".agent/workstreams/ws-20260912T081920Z-KPPZ/runs/run-1789201481364/outputs/intake-codex-product-review.json",
  "blocking" : true,
  "checks" : [ "已先审阅 Review Evidence Brief，再逐项比对完整提案与原始需求。", "产品视角：技术栈、公开只读行情、SQLite 持久化、定时同步、降级体验及非目标总体覆盖。", "架构视角：Boundary Review 为 WARN；配置属于定义，同步尝试属于执行，SQLite 保存行情和同步状态事实，API 与页面负责只读展示；完整校验和事务约束方向正确，但尚无实现证据证明边界强制生效。", "最终用户视角：行情首屏、成交量、移动端、加载与失败状态均有验收约束，但图表实际消费后端数据的验证要求不完整。", "范围视角：scope.included 使用精确路径与操作；本次修订可在已声明文件范围内完成，无需扩大授权。", "协议视角：未要求提案重复编排器的输出封装或路由协议。" ],
  "evidence" : [ "原始需求明确响应顺序为 [ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]，且 ts 是开盘时间；AC-4 只列出字段数量、时间戳类型、价格及 confirm 校验，未完整绑定字段位置和含义。", "原始需求要求验证重启后持久化；TR-3 将新数据库连接视为模拟重启，不能验证应用重新初始化后仍能查询已有闭合 K 线。", "原始需求要求浏览器级或 DOM 级验证证明图表消费本应用后端数据；TR-5 仅明确页面请求、刷新和网络拦截，R-4 提到的页面数据属性也不能单独证明数据进入图表。" ],
  "mustFix" : [ "补齐绑定的九字段行情行映射及开盘时间语义，明确价格和全部成交量字段的 decimal-safe 解析与非法行处理。", "将 TR-3 的新连接验证加强为应用关闭并重新初始化后的持久化验证。", "加强 TR-5，直接验证蜡烛图和成交量消费后端返回值，并在定时刷新后更新图表数据。" ],
  "contractObligations" : [ {
    "id" : "CO-1",
    "text" : "在 acceptance_criteria 或 constraints 中完整保留 [ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm] 的位置映射，明确 ts 对应 open_time 且为开盘时间 Unix 毫秒时间戳；价格与全部成交量字段采用 decimal-safe 解析，非法字段按整轮失败处理。"
  }, {
    "id" : "CO-2",
    "text" : "修订 TR-3：使用临时 SQLite 文件，首次应用初始化后保存闭合 K 线，关闭应用上下文及数据库资源，再针对同一文件重新初始化应用并验证仍可查询；仅新建数据库连接不足以完成重启验证。"
  }, {
    "id" : "CO-3",
    "text" : "修订 TR-5：浏览器级或 DOM 级测试必须证明后端返回的时间、OHLC 和成交量进入图表数据输入，并证明后端数据改变后由定时刷新更新图表；同时保留不整页重载及浏览器不直连 OKX 的断言。无需强制像素级验证。"
  } ],
  "missingEvidence" : [ ],
  "acceptanceNotes" : [ "这是契约完整性评审，未执行构建、测试或 live smoke，也未验证依赖兼容性。", "上述问题属于需求保留和验证充分性，可由提案修订解决，不需要新增人工产品决策。", "当前只评估声明的边界设计，不将其描述为已实现或已证明闭环。" ],
  "openRisks" : [ ],
  "changedFiles" : [ ],
  "verificationSummary" : "依据用户原始需求和完整候选提案完成只读评审，确认三项待修订契约义务；未修改仓库或账本。",
  "completedWork" : [ ],
  "importantDecisions" : [ ],
  "recommendedNextStage" : "",
  "suggestedNextPrompt" : "",
  "control" : {
    "decision" : "NEEDS_REVISION",
    "summary" : "提案整体符合产品目标，但行情行契约和两项关键验证要求尚未完整保留，需要补齐后推进。"
  },
  "failure" : {
    "categoryHint" : "CONTRACT_GAP",
    "verificationRemediation" : "NONE",
    "contractGaps" : [ "CO-1：行情响应字段映射及开盘时间语义未完整进入绑定字段。", "CO-2：新连接测试不能充分证明应用重启后的持久化。", "CO-3：页面取数测试不能充分证明图表消费并刷新后端行情数据。" ],
    "outOfScopeFiles" : [ ],
    "missingTests" : [ ],
    "contextGaps" : [ ],
    "reason" : "候选契约尚未完整保留明确的行情契约与验证要求，应修订后再推进。"
  },
  "rereadReasons" : [ ],
  "reviewSubject" : {
    "schema_version" : 1,
    "proposal_id" : "node-intake-claude_brainstorm-002:ecd45dad77f5918e",
    "workstream_id" : "ws-20260912T081920Z-KPPZ",
    "producer_node_id" : "intake.claude_brainstorm",
    "producer_node_instance_id" : "node-intake-claude_brainstorm-002",
    "artifact_ref" : ".agent/workstreams/ws-20260912T081920Z-KPPZ/runs/run-1789201271061/outputs/intake-claude-brainstorm.contract.json",
    "sha256" : "ecd45dad77f5918e769f51c4c24d965b6e2ea8f365748a21b302dd84eb1505be"
  },
  "taskContractProposal" : null,
  "repositoryFactBinding" : null,
  "proposalDerivation" : null,
  "planArtifact" : null,
  "design" : null,
  "authoredRevisionResponses" : null,
  "authoredContext" : null
}
```

### Verified Previous Task Contract Proposal

- Proposal ID: node-intake-claude_brainstorm-002:ecd45dad77f5918e
- Proposal SHA-256: ecd45dad77f5918e769f51c4c24d965b6e2ea8f365748a21b302dd84eb1505be

<!-- dual:typed-payload:start -->
```json
{
  "artifact_type" : "task_contract_proposal",
  "schema_version" : 3,
  "objective" : "构建一个本地运行的 Spring Boot Web 应用：直连 OKX 官方公开行情 REST API（GET /api/v5/market/candles，instId=BTC-USDT，bar=1m）获取分钟级 K 线，通过 MyBatis-Plus 幂等持久化到 SQLite，提供稳定的 JSON 后端 API 与本地打包的蜡烛图+成交量页面，支持可配置定时同步、degraded 降级保留、Java 25 下无公网依赖的 mvn test，以及显式 opt-in 的 live smoke 验证。",
  "scope" : {
    "included" : [ {
      "path" : "pom.xml",
      "operation" : "CREATE"
    }, {
      "path" : "README.md",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/com/example/okxkline/OkxKlineApplication.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/config/OkxClientConfig.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/config/OkxSyncProperties.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxCandleResponse.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxCandleRow.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxMarketClient.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/entity/Candle.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/entity/SyncState.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/mapper/CandleMapper.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/mapper/SyncStateMapper.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/persistence/typehandler/DecimalTextTypeHandler.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/CandleSyncService.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/SyncScheduler.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/SyncStatusService.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/ApiExceptionHandler.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/CandleApiController.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/SyncStatusApiController.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/application.yml",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/schema.sql",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/app.js",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/index.html",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/styles.css",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/vendor/echarts.min.js",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/livesmoke/OkxLiveSmokeTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/OkxMarketClientTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/persistence/CandlePersistenceTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/CandleSyncServiceTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/SyncSchedulerTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/CandleApiTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/ChartPageDomTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/candles-edge-cases.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/candles-normal.json",
      "operation" : "CREATE"
    } ],
    "excluded" : [ "交易、下单、账户访问、认证、API Key、余额或任何 OKX 私有 API", "投资建议、告警、策略、技术指标或预测", "WebSocket 行情", "多交易品种或多 K 线周期切换", "分布式调度或多实例协调", "用户账户或管理后台", "通用交易所抽象或行情平台", "运行时 CDN 依赖", "修改冻结基线资产（REQUIREMENT.md、scripts/verify-workspace.sh、.gitignore）" ]
  },
  "acceptance_criteria" : [ {
    "id" : "AC-1",
    "text" : "同步启用时，应用启动后执行一次初始回填：通过 GET {可配置 base URL}/api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300 直连 OKX 官方公开行情 API 拉取最近 300 根 K 线并保存；全程不要求 API Key 或 OKX 账户。"
  }, {
    "id" : "AC-2",
    "text" : "SQLite K 线表对 (instrument, bar, open_time) 建立唯一约束；同一响应中通过校验的 K 线在单个事务内完成 upsert；重复同步幂等；confirm=0 的未闭合 K 线按键原位更新；confirm=1 的闭合 K 线在应用重启后仍可查询。"
  }, {
    "id" : "AC-3",
    "text" : "针对 OKX 倒序返回与陈旧缓存响应，同步仅做 upsert 合并，绝不因响应缺失、乱序或早于本地数据而删除或回滚本地较新的已保存 K 线。"
  }, {
    "id" : "AC-4",
    "text" : "每轮同步先完整解析并校验 OKX envelope（code=\"0\"、data 为数组、每行恰有 9 个字段、ts 为 Unix 毫秒时间戳、价格为可解析 decimal、confirm∈{0,1}），全部校验通过后才写数据库；任一行非法则该轮整体失败且不写入部分数据。"
  }, {
    "id" : "AC-5",
    "text" : "HTTP 超时、非 2xx、429 限流、OKX 业务错误、非法 JSON、非法行或数据库异常均不删除已有 K 线；失败记录 degraded 状态，不执行无界立即重试，等待下一轮调度恢复。"
  }, {
    "id" : "AC-6",
    "text" : "同步默认每 15 秒执行一次且周期可配置，单应用实例内不存在重叠调度执行；OKX base URL、连接超时、读取超时、调度开关与刷新周期均支持外部配置。"
  }, {
    "id" : "AC-7",
    "text" : "同步健康状态包含受控状态值、最近尝试时间、最近成功时间与有界脱敏的失败摘要；错误文本仅作展示数据，不反向成为生命周期状态的判定来源。"
  }, {
    "id" : "AC-8",
    "text" : "GET /api/candles 返回最近最多 300 根已保存 K 线并按 open_time 升序排列，非法 limit 返回明确的 4xx 客户端错误；GET /api/sync/status 返回 AC-7 定义的健康信息。"
  }, {
    "id" : "AC-9",
    "text" : "价格与成交量在 Java 侧以 BigDecimal 表示、在 SQLite 侧以 TEXT 存储，端到端不以二进制浮点数作为权威值。"
  }, {
    "id" : "AC-10",
    "text" : "数据库结构由版本化 SQL 脚本确定性初始化（幂等 IF NOT EXISTS 加 PRAGMA user_version 版本号），业务代码不临时拼接建表流程。"
  }, {
    "id" : "AC-11",
    "text" : "首屏直接呈现行情界面：真实蜡烛 K 线与成交量、BTC / USDT、1m、最新收盘价、最近闭合 K 线时间、同步状态与最近成功刷新时间；浏览器默认每 10 秒从本应用后端刷新且不整页重载；degraded 时保留最后可用图表并显示克制清晰的状态；正确处理首次加载、无数据、降级与后端失败；桌面与移动视口下文字、图表与操作不重叠；不以模拟价格冒充 OKX 实时行情。"
  }, {
    "id" : "AC-12",
    "text" : "生产静态资源（含成熟 K 线图表库）随应用本地打包，页面无任何运行时 CDN 请求；浏览器只调用本应用同源后端，不直接请求 OKX。"
  }, {
    "id" : "AC-13",
    "text" : "Java 25 下执行 mvn test 必须通过，且测试执行期间不访问公网 OKX API。"
  }, {
    "id" : "AC-14",
    "text" : "提供显式 opt-in live smoke 命令（不进入默认 mvn test），直连 OKX 官方接口发起一次只读请求并验证至少一根结构合法的 BTC-USDT 1m K 线。"
  }, {
    "id" : "AC-15",
    "text" : "日志仅记录必要运行元数据（状态、轮次、耗时、错误类别），失败时不打印完整 OKX 响应正文。"
  }, {
    "id" : "AC-16",
    "text" : "README 记录架构、配置项、SQLite 路径、启动方式、测试、live smoke、后端 API、数据新鲜度语义与限制。"
  } ],
  "test_requirements" : [ {
    "id" : "TR-1",
    "text" : "使用本地契约一致的 HTTP stub 与冻结 fixture 覆盖：正常响应、倒序输入、重复同步、未闭合 K 线更新、闭合 K 线持久化、陈旧缓存响应、非法 envelope、非法行、连接/读取超时、非 2xx、429 限流与 OKX 业务错误，并断言各失败路径均保留已有 K 线。"
  }, {
    "id" : "TR-2",
    "text" : "调度测试验证：启动初始回填、固定周期触发、单实例不重叠执行（含慢响应时序）、失败后进入 degraded 且无无界立即重试、下一轮调度可恢复。"
  }, {
    "id" : "TR-3",
    "text" : "使用临时 SQLite 数据库验证 (instrument, bar, open_time) 唯一约束生效，并以新连接（模拟重启）验证闭合 K 线仍可查询。"
  }, {
    "id" : "TR-4",
    "text" : "后端 API 测试覆盖 /api/candles 升序排序、limit 合法上限与非法值（非数字、越界）的 4xx 校验、/api/sync/status 健康字段完整性，以及同步失败后已保存数据仍可查询。"
  }, {
    "id" : "TR-5",
    "text" : "提供 DOM 级（或浏览器级）验证：页面加载即从本应用后端获取数据、按可注入的周期间隔定时刷新且不整页重载，并拦截全部页面网络请求证明无任何对 OKX 的浏览器直连。"
  }, {
    "id" : "TR-6",
    "text" : "断言 Java 25 环境下 mvn test 在无公网 OKX 访问时可重复通过（自动化测试全部走本地 stub 与 fixture）。"
  }, {
    "id" : "TR-7",
    "text" : "live smoke 以独立 opt-in 入口运行（如 mvn -Plive-smoke test），断言 OKX 响应 code=\"0\" 且至少一行结构合法的 BTC-USDT 1m K 线；默认 mvn test 不执行该用例。"
  } ],
  "constraints" : [ {
    "id" : "C-1",
    "text" : "技术栈固定：Java 25、Spring Boot 4.1.0、Maven 构建，pom.xml 为唯一构建定义。"
  }, {
    "id" : "C-2",
    "text" : "数据访问层唯一使用 MyBatis-Plus 3.5.17（mybatis-plus-spring-boot4-starter）；禁止 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施。"
  }, {
    "id" : "C-3",
    "text" : "SQLite 为唯一应用数据库；默认数据库文件路径可配置并在 README 记录；启用 WAL 与 busy_timeout 以支持调度写与 Web 读并发。"
  }, {
    "id" : "C-4",
    "text" : "行情数据只来自 OKX 官方公开 Market Data REST API（GET /api/v5/market/candles），固定 instId=BTC-USDT、bar=1m、不抓取或解析 HTML 页面；生产应用与 live smoke 直连官方 API，不得经由测试桩、代理业务服务或抓取服务替代。"
  }, {
    "id" : "C-5",
    "text" : "前端图表库选用成熟库（ECharts，固定版本 vendored 至 static/vendor/echarts.min.js），随应用本地打包，禁止运行时 CDN；生产应用与显式 live smoke 以外的自动化测试使用本地契约一致 stub。"
  }, {
    "id" : "C-6",
    "text" : "外部配置至少覆盖：OKX base URL、连接超时、读取超时、调度开关、同步刷新周期；前端默认 10 秒刷新周期可在测试中注入更短值。"
  }, {
    "id" : "C-7",
    "text" : "调度采用 fixedDelay 语义（上一轮执行完成后才开始计时）并以单实例互斥保护兜底，确保单实例不重叠。"
  }, {
    "id" : "C-8",
    "text" : "同步遵循确定性错误语义：先完整校验后写库、同一响应单事务 upsert、失败不删除已有数据、无无界立即重试；任一非法行使整轮失败而非部分写入。"
  }, {
    "id" : "C-9",
    "text" : "健康状态由受控状态机（如 OK/DEGRADED/RUNNING）管理并持久化于同步状态表，错误文本仅截断、脱敏后作为有界摘要展示。"
  }, {
    "id" : "C-10",
    "text" : "冻结基线资产保持不变：不修改 REQUIREMENT.md、scripts/verify-workspace.sh 与 .gitignore。"
  } ],
  "non_goals" : [ {
    "id" : "NG-1",
    "text" : "交易、下单、账户访问、认证、API Key、余额或任何私有 OKX API。"
  }, {
    "id" : "NG-2",
    "text" : "投资建议、告警、策略、技术指标或预测。"
  }, {
    "id" : "NG-3",
    "text" : "WebSocket 行情订阅。"
  }, {
    "id" : "NG-4",
    "text" : "多交易品种或多 K 线周期切换。"
  }, {
    "id" : "NG-5",
    "text" : "分布式调度、多实例协调或集群部署。"
  }, {
    "id" : "NG-6",
    "text" : "用户账户系统或管理后台。"
  }, {
    "id" : "NG-7",
    "text" : "通用交易所抽象或多交易所行情平台。"
  }, {
    "id" : "NG-8",
    "text" : "运行时 CDN 或第三方外部资源依赖。"
  }, {
    "id" : "NG-9",
    "text" : "抓取或解析 OKX 网页 HTML 作为数据来源。"
  }, {
    "id" : "NG-10",
    "text" : "修改冻结基线资产（REQUIREMENT.md、scripts/verify-workspace.sh、.gitignore）。"
  } ],
  "risk_areas" : [ {
    "id" : "R-1",
    "text" : "vendored echarts.min.js 体积较大，需在实现期按固定版本从官方渠道获取并记录校验值；若实现环境网络受限，需人工提供该文件。"
  }, {
    "id" : "R-2",
    "text" : "Spring Boot 4.1.0（Framework 7）与 mybatis-plus-spring-boot4-starter 3.5.17 及 RestClient 测试栈（MockRestServiceServer/HtmlUnit）的兼容性需在实现早期做最小工程验证，避免后期换栈。"
  }, {
    "id" : "R-3",
    "text" : "SQLite 单写者模型下调度写入与 Web 查询并发存在 SQLITE_BUSY 时序风险，以 WAL + busy_timeout 缓解，但极端时序仍需观测。"
  }, {
    "id" : "R-4",
    "text" : "HtmlUnit 不支持 canvas 渲染，DOM 级验证需通过页面数据状态属性与请求拦截断言而非像素级图表断言，app.js 需保证图表初始化失败时页面数据逻辑仍可运行。"
  }, {
    "id" : "R-5",
    "text" : "scripts/verify-workspace.sh 是空基线预检（断言无 pom.xml 与 src/），实现落地后必然不再通过；本提案将其定位为一次性基线预检而非持续验证，需评审确认此理解。"
  }, {
    "id" : "R-6",
    "text" : "live smoke 依赖公网 OKX 可达性与限流状态，属 opt-in 用例，其失败不应阻塞默认交付判定。"
  } ],
  "evidence_refs" : [ "REQUIREMENT.md", "README.md", "scripts/verify-workspace.sh", ".gitignore" ],
  "open_questions" : [ ],
  "revision_responses" : [ ]
}
```
<!-- dual:typed-payload:end -->

- .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-codex_product_review-004-run-1789201481364/binding.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260912T081920Z-KPPZ/runs/run-1789201481364/outputs/intake-codex-product-review.contract.json
  (validated typed evidence already projected)

- .agent/workstreams/ws-20260912T081920Z-KPPZ/context/agent-governance-node-intake-claude_brainstorm-006-run-1789201562077.md

```text
# Agent Run Governance Context

- Workstream: ws-20260912T081920Z-KPPZ
- Target Node: intake.claude_brainstorm
- Agent Node Instance: node-intake-claude_brainstorm-006
- Run Id: run-1789201562077
- Generated At: 2026-09-12T08:26:02.108711Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789201562077/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789201562077/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789201562077/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789201562077/binding.json

- Tracked inventory: count=4; head=c84807946493a603c789ee40c6a4c615aa846c3b; sha256=df80ed33104a28c6285358790cf77533328b089bd62e5a10379e37ec6e9f9298

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - REQUIREMENT.md
  - scripts/verify-workspace.sh
- Expected edit files: (none planned)
```

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_PRODUCT_REVIEW]



Return only `task_contract_revision_patch`; do not return or copy a full proposal. The patch is bound to base proposal id `node-intake-claude_brainstorm-002:ecd45dad77f5918e` and sha256 `ecd45dad77f5918e769f51c4c24d965b6e2ea8f365748a21b302dd84eb1505be`. Cover each authoritative routed obligation exactly once. Preserve its id and implement its text: [{"id":"CO-1","text":"在 acceptance_criteria 或 constraints 中完整保留 [ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm] 的位置映射，明确 ts 对应 open_time 且为开盘时间 Unix 毫秒时间戳；价格与全部成交量字段采用 decimal-safe 解析，非法字段按整轮失败处理。"},{"id":"CO-2","text":"修订 TR-3：使用临时 SQLite 文件，首次应用初始化后保存闭合 K 线，关闭应用上下文及数据库资源，再针对同一文件重新初始化应用并验证仍可查询；仅新建数据库连接不足以完成重启验证。"},{"id":"CO-3","text":"修订 TR-5：浏览器级或 DOM 级测试必须证明后端返回的时间、OHLC 和成交量进入图表数据输入，并证明后端数据改变后由定时刷新更新图表；同时保留不整页重载及浏览器不直连 OKX 的断言。无需强制像素级验证。"}]. Only clause ADD/REPLACE, exact scope ADD, and evidence-ref ADD are supported. No DELETE, section move, scope removal, objective/open-question change, JSON Pointer, or arbitrary field patch is allowed. `scope_additions` uses exact repository-relative paths. Each scope path must name one exact file, not a directory; it must be repository-relative, must not end with `/`, and must already be canonical (no `./`, `..`, repeated separators, backslashes, leading/trailing whitespace, `.git`, or `.agent` segments). Dual derives CREATE/MODIFY from the effective worktree. `section` is authoritative; clause IDs are opaque and their prefixes do not determine section. Across the entire `result.obligation_patches` array, each `clause_changes[].id`, `scope_additions[].path`, and `evidence_ref_additions[]` target must appear at most once. When one evidence ref supports multiple obligations, add it in one most relevant patch only; use each obligation's `resolved_by_clause_ids` to express coverage instead of adding the ref again. Each `result.obligation_patches` item is a closed object with exactly these fields: [review_obligation_id, resolved_by_clause_ids, clause_changes, scope_additions, evidence_ref_additions]. No other keys are permitted.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20260912T081920Z-KPPZ",
  "run_id" : "run-1789201562077",
  "node_id" : "intake.claude_brainstorm",
  "result" : {
    "artifact_type" : "task_contract_revision_patch",
    "decision" : "READY_FOR_PRODUCT_REVIEW",
    "summary" : "one short sentence",
    "base_proposal_id" : "node-intake-claude_brainstorm-002:ecd45dad77f5918e",
    "base_proposal_sha256" : "ecd45dad77f5918e769f51c4c24d965b6e2ea8f365748a21b302dd84eb1505be",
    "obligation_patches" : [ {
      "review_obligation_id" : "CO-1",
      "resolved_by_clause_ids" : [ "AC-1" ],
      "clause_changes" : [ {
        "operation" : "REPLACE",
        "section" : "ACCEPTANCE_CRITERIA",
        "id" : "AC-1",
        "text" : "replacement text"
      } ],
      "scope_additions" : [ {
        "path" : "repo/relative/new.ext"
      } ],
      "evidence_ref_additions" : [ "repo/relative/evidence.ext" ]
    } ]
  }
}
