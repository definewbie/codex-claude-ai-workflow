# Human Review Packet

- Workstream: ws-20260912T081920Z-KPPZ
- Gate: gate.contract_review
- Gate Instance: node-gate-contract_review-013
- Stage: stage-gate
- Iteration: iter-002
- Source Outcome: completed
- Allowed Actions: approve, clarify, reject

## Operator Guidance

- Recommended Action: approve
- Reason: No decisive recommendation is available. Read the packet and choose an allowed action.
- Suggested Checks:
  - Confirm the TaskContract objective, scope, non-goals, and acceptance criteria still match the task.

## Review Focus

- Read the complete referenced design and review sidecars before approving; the packet summary is not a substitute.
- Use `approve` only when the current gate is good enough to continue.
- Use `revise` when the agent should address concrete feedback first.

## Review Summary

- Objective: 构建一个本地运行的 Spring Boot Web 应用：直连 OKX 官方公开行情 REST API（GET /api/v5/market/candles，instId=BTC-USDT，bar=1m）获取分钟级 K 线，通过 MyBatis-Plus 幂等持久化到 SQLite，提供稳定的 JSON 后端 API 与本地打包的蜡烛图+成交量页面，支持可配置定时同步、degraded 降级保留、Java 25 下无公网依赖的 mvn test，以及显式 opt-in 的 live smoke 验证。
- Blocking: false

## Task Contract

- Objective: 构建一个本地运行的 Spring Boot Web 应用：直连 OKX 官方公开行情 REST API（GET /api/v5/market/candles，instId=BTC-USDT，bar=1m）获取分钟级 K 线，通过 MyBatis-Plus 幂等持久化到 SQLite，提供稳定的 JSON 后端 API 与本地打包的蜡烛图+成交量页面，支持可配置定时同步、degraded 降级保留、Java 25 下无公网依赖的 mvn test，以及显式 opt-in 的 live smoke 验证。
- Status: READY_FOR_REVIEW
- Included Scope:
  - {path=pom.xml, operation=CREATE}
  - {path=README.md, operation=MODIFY}
  - {path=src/main/java/com/example/okxkline/OkxKlineApplication.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/config/OkxClientConfig.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/config/OkxSyncProperties.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/okx/OkxCandleResponse.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/okx/OkxCandleRow.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/okx/OkxMarketClient.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/persistence/entity/Candle.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/persistence/entity/SyncState.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/persistence/mapper/CandleMapper.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/persistence/mapper/SyncStateMapper.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/persistence/typehandler/DecimalTextTypeHandler.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/sync/CandleSyncService.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/sync/SyncScheduler.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/sync/SyncStatusService.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/web/ApiExceptionHandler.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/web/CandleApiController.java, operation=CREATE}
  - {path=src/main/java/com/example/okxkline/web/SyncStatusApiController.java, operation=CREATE}
  - {path=src/main/resources/application.yml, operation=CREATE}
  - {path=src/main/resources/schema.sql, operation=CREATE}
  - {path=src/main/resources/static/app.js, operation=CREATE}
  - {path=src/main/resources/static/index.html, operation=CREATE}
  - {path=src/main/resources/static/styles.css, operation=CREATE}
  - {path=src/main/resources/static/vendor/echarts.min.js, operation=CREATE}
  - {path=src/test/java/com/example/okxkline/livesmoke/OkxLiveSmokeTest.java, operation=CREATE}
  - {path=src/test/java/com/example/okxkline/okx/OkxMarketClientTest.java, operation=CREATE}
  - {path=src/test/java/com/example/okxkline/persistence/CandlePersistenceTest.java, operation=CREATE}
  - {path=src/test/java/com/example/okxkline/sync/CandleSyncServiceTest.java, operation=CREATE}
  - {path=src/test/java/com/example/okxkline/sync/SyncSchedulerTest.java, operation=CREATE}
  - {path=src/test/java/com/example/okxkline/web/CandleApiTest.java, operation=CREATE}
  - {path=src/test/java/com/example/okxkline/web/ChartPageDomTest.java, operation=CREATE}
  - {path=src/test/resources/fixtures/candles-edge-cases.json, operation=CREATE}
  - {path=src/test/resources/fixtures/candles-normal.json, operation=CREATE}
- Excluded Scope:
  - 交易、下单、账户访问、认证、API Key、余额或任何 OKX 私有 API
  - 投资建议、告警、策略、技术指标或预测
  - WebSocket 行情
  - 多交易品种或多 K 线周期切换
  - 分布式调度或多实例协调
  - 用户账户或管理后台
  - 通用交易所抽象或行情平台
  - 运行时 CDN 依赖
  - 修改冻结基线资产（REQUIREMENT.md、scripts/verify-workspace.sh、.gitignore）
- Acceptance Criteria:
  - 同步启用时，应用启动后执行一次初始回填：通过 GET {可配置 base URL}/api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300 直连 OKX 官方公开行情 API 拉取最近 300 根 K 线并保存；全程不要求 API Key 或 OKX 账户。
  - SQLite K 线表对 (instrument, bar, open_time) 建立唯一约束；同一响应中通过校验的 K 线在单个事务内完成 upsert；重复同步幂等；confirm=0 的未闭合 K 线按键原位更新；confirm=1 的闭合 K 线在应用重启后仍可查询。
  - 针对 OKX 倒序返回与陈旧缓存响应，同步仅做 upsert 合并，绝不因响应缺失、乱序或早于本地数据而删除或回滚本地较新的已保存 K 线。
  - 每轮同步先完整解析并校验 OKX envelope（code="0"、data 为数组）及每一行情行的九字段位置映射：下标 0=ts（映射到 open_time，即该 K 线开盘时间的 Unix 毫秒时间戳）、下标 1=o（开盘价）、下标 2=h（最高价）、下标 3=l（最低价）、下标 4=c（收盘价）、下标 5=vol（成交量，币本位）、下标 6=volCcy（成交额）、下标 7=volCcyQuote（计价成交额）、下标 8=confirm（取值 ∈{0,1}）。每行必须恰有 9 个字段；全部价格字段（o、h、l、c）与全部成交量字段（vol、volCcy、volCcyQuote）均采用 decimal-safe 解析（Java 侧 BigDecimal）；任一字段缺失、错位、类型非法或不可解析即判定该行非法并使整轮同步失败，不写入任何部分数据；全部校验通过后才写数据库。
  - HTTP 超时、非 2xx、429 限流、OKX 业务错误、非法 JSON、非法行或数据库异常均不删除已有 K 线；失败记录 degraded 状态，不执行无界立即重试，等待下一轮调度恢复。
  - 同步默认每 15 秒执行一次且周期可配置，单应用实例内不存在重叠调度执行；OKX base URL、连接超时、读取超时、调度开关与刷新周期均支持外部配置。
  - 同步健康状态包含受控状态值、最近尝试时间、最近成功时间与有界脱敏的失败摘要；错误文本仅作展示数据，不反向成为生命周期状态的判定来源。
  - GET /api/candles 返回最近最多 300 根已保存 K 线并按 open_time 升序排列，非法 limit 返回明确的 4xx 客户端错误；GET /api/sync/status 返回 AC-7 定义的健康信息。
  - 价格与成交量在 Java 侧以 BigDecimal 表示、在 SQLite 侧以 TEXT 存储，端到端不以二进制浮点数作为权威值。
  - 数据库结构由版本化 SQL 脚本确定性初始化（幂等 IF NOT EXISTS 加 PRAGMA user_version 版本号），业务代码不临时拼接建表流程。
  - 首屏直接呈现行情界面：真实蜡烛 K 线与成交量、BTC / USDT、1m、最新收盘价、最近闭合 K 线时间、同步状态与最近成功刷新时间；浏览器默认每 10 秒从本应用后端刷新且不整页重载；degraded 时保留最后可用图表并显示克制清晰的状态；正确处理首次加载、无数据、降级与后端失败；桌面与移动视口下文字、图表与操作不重叠；不以模拟价格冒充 OKX 实时行情。
  - 生产静态资源（含成熟 K 线图表库）随应用本地打包，页面无任何运行时 CDN 请求；浏览器只调用本应用同源后端，不直接请求 OKX。
  - Java 25 下执行 mvn test 必须通过，且测试执行期间不访问公网 OKX API。
  - 提供显式 opt-in live smoke 命令（不进入默认 mvn test），直连 OKX 官方接口发起一次只读请求并验证至少一根结构合法的 BTC-USDT 1m K 线。
  - 日志仅记录必要运行元数据（状态、轮次、耗时、错误类别），失败时不打印完整 OKX 响应正文。
  - README 记录架构、配置项、SQLite 路径、启动方式、测试、live smoke、后端 API、数据新鲜度语义与限制。
- Test Requirements:
  - 使用本地契约一致的 HTTP stub 与冻结 fixture 覆盖：正常响应、倒序输入、重复同步、未闭合 K 线更新、闭合 K 线持久化、陈旧缓存响应、非法 envelope、非法行、连接/读取超时、非 2xx、429 限流与 OKX 业务错误，并断言各失败路径均保留已有 K 线。
  - 调度测试验证：启动初始回填、固定周期触发、单实例不重叠执行（含慢响应时序）、失败后进入 degraded 且无无界立即重试、下一轮调度可恢复。
  - 使用临时 SQLite 数据库文件验证 (instrument, bar, open_time) 唯一约束生效；持久化验证必须采用应用级重启语义：首次完整初始化应用上下文并写入闭合（confirm=1）K 线后，显式关闭应用上下文并释放数据库连接等底层资源，再针对同一 SQLite 文件重新初始化完整应用上下文，验证已保存的闭合 K 线仍可按 (instrument, bar, open_time) 查询且价格、成交量数值与关闭前一致；仅在同一进程内新建数据库连接不构成充分的重启验证。
  - 后端 API 测试覆盖 /api/candles 升序排序、limit 合法上限与非法值（非数字、越界）的 4xx 校验、/api/sync/status 健康字段完整性，以及同步失败后已保存数据仍可查询。
  - 提供 DOM 级（或浏览器级）验证：断言页面从本应用后端 /api/candles 获取的时间戳、OHLC 与成交量数据进入图表数据输入（通过页面可观测的图表数据状态或对图表库 setOption/更新输入的捕获断言），并证明后端数据变更后由定时刷新（可注入更短周期）将新的时间戳、OHLC 与成交量写入图表数据；同时保留刷新过程不整页重载的断言，并拦截页面全部网络请求证明浏览器不直接请求 OKX；不要求像素级图表渲染验证。
  - 断言 Java 25 环境下 mvn test 在无公网 OKX 访问时可重复通过（自动化测试全部走本地 stub 与 fixture）。
  - live smoke 以独立 opt-in 入口运行（如 mvn -Plive-smoke test），断言 OKX 响应 code="0" 且至少一行结构合法的 BTC-USDT 1m K 线；默认 mvn test 不执行该用例。
- Constraints:
  - 技术栈固定：Java 25、Spring Boot 4.1.0、Maven 构建，pom.xml 为唯一构建定义。
  - 数据访问层唯一使用 MyBatis-Plus 3.5.17（mybatis-plus-spring-boot4-starter）；禁止 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施。
  - SQLite 为唯一应用数据库；默认数据库文件路径可配置并在 README 记录；启用 WAL 与 busy_timeout 以支持调度写与 Web 读并发。
  - 行情数据只来自 OKX 官方公开 Market Data REST API（GET /api/v5/market/candles），固定 instId=BTC-USDT、bar=1m、不抓取或解析 HTML 页面；生产应用与 live smoke 直连官方 API，不得经由测试桩、代理业务服务或抓取服务替代。
  - 前端图表库选用成熟库（ECharts，固定版本 vendored 至 static/vendor/echarts.min.js），随应用本地打包，禁止运行时 CDN；生产应用与显式 live smoke 以外的自动化测试使用本地契约一致 stub。
  - 外部配置至少覆盖：OKX base URL、连接超时、读取超时、调度开关、同步刷新周期；前端默认 10 秒刷新周期可在测试中注入更短值。
  - 调度采用 fixedDelay 语义（上一轮执行完成后才开始计时）并以单实例互斥保护兜底，确保单实例不重叠。
  - 同步遵循确定性错误语义：先完整校验后写库、同一响应单事务 upsert、失败不删除已有数据、无无界立即重试；任一非法行使整轮失败而非部分写入。
  - 健康状态由受控状态机（如 OK/DEGRADED/RUNNING）管理并持久化于同步状态表，错误文本仅截断、脱敏后作为有界摘要展示。
  - 冻结基线资产保持不变：不修改 REQUIREMENT.md、scripts/verify-workspace.sh 与 .gitignore。

## Requirement Resolution

- Decision: APPROVE
- Approved By: human_gate
- Gate Ref: .agent/workstreams/ws-20260912T081920Z-KPPZ/gates/gate-node-gate-human_requirement_review-011.json
- Assumptions:
  - Human approved the requirement review gate before canonical contract generation.

## Input Artifacts

Raw agent logs are not embedded here by default. Use the paths below when deeper debugging is needed.

### .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/task-contract.json

- Status: available
- Kind: json
- Raw Artifact: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/task-contract.json

### .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/task-contract.md

- Status: available
- Kind: markdown_output
- Raw Artifact: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/task-contract.md

### .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/contract-resolution.json

- Status: available
- Kind: json
- Raw Artifact: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/contract-resolution.json

### .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/contract-resolution.md

- Status: available
- Kind: markdown_output
- Raw Artifact: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/contract-resolution.md

