## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ
- Run all shell commands from the effective workspace above.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.

## Structured Artifact Field Semantics

- `must_fix` and `missing_evidence` mean unresolved blockers; keep them empty for a ready design.
- Put resolved review comments in `checks` or `evidence`, not `must_fix`.
- `design.planned_files` declares intended changes only; exact paths and operations must be authorized by the approved TaskContract.

# Claude Design

Workstream: ws-20260912T081920Z-KPPZ
Node: design.claude_design
Template: design-claude
Ledger: .agent/workstreams/ws-20260912T081920Z-KPPZ

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.

You are Claude acting as the primary architect and implementer. Use the user request, prior intake artifacts, Codex review, and human gate decision in the ledger.

Do not implement code in this stage. Produce an implementation-ready design that is narrow, testable, and avoids unrelated refactors.

Declare the complete planned file set in `result.design.planned_files`, for initial and replacement designs alike.
Copy exact canonical paths and operations from the approved TaskContract scope; prose cannot authorize other paths.
Each entry assigns a responsibility, not an actual file change. CREATE files need not exist yet.
The declared set may be a subset of approved scope, but must cover every change this design proposes.

Revision discipline:

- When the context contains a prior `NEEDS_REVISION`, return a complete replacement design, not a delta or addendum.
- Treat available prior must-fix items as the minimum repair set, not the boundary of the design review.
- Do not claim knowledge of prior design text that is absent from the context. Reconstruct a coherent complete design from the TaskContract, current review evidence, and available iteration reasons.
- When adding or changing state, an index, lock, transaction, queue, cache, external side effect, or compensation, cover every applicable lifecycle boundary in `checks` or `evidence`: normal completion, concurrency, timeout/provider failure, interruption/crash, restart/recovery, rollback/conflict, and a cannot-bypass test. State why a boundary is not applicable instead of inventing requirements.
- Prefer deleting unnecessary mechanisms or simplifying the state model. Do not add platform capability merely to close one finding.

## User Request

# OKX BTC 分钟级 K 线 Web 应用需求

## 目标

构建一个本地 Web 应用，通过 OKX 官方公开行情 REST API 获取 BTC-USDT 现货分钟级 K 线，将数据持久化到 SQLite，并展示可定时刷新的 K 线图。

本应用只读取公开行情，不得下单、访问账户、提供投资建议或抓取 OKX 网页。

## 强制技术栈

- Java 25。
- Spring Boot 4.1.0。
- Maven。
- MyBatis-Plus 3.5.17，必须使用 `mybatis-plus-spring-boot4-starter`。
- SQLite 是唯一应用数据库。
- 使用成熟的 K 线图表库，生产资源必须随应用本地打包，不得依赖运行时 CDN。

不得用 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施替代 MyBatis-Plus。

## OKX 行情契约

- 数据源只能是 OKX 官方公开 Market Data REST API，不得抓取 HTML 页面。
- 交易品种固定为 BTC-USDT 现货。
- K 线周期固定为 `1m`。
- 接口为 `GET /api/v5/market/candles`。
- 首次启动拉取并保存最近 300 根 K 线。
- 响应行格式为 `[ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]`。
- `ts` 是 K 线开盘时间的 Unix 毫秒时间戳。
- `confirm=0` 表示当前 K 线尚未闭合，后续允许更新。
- `confirm=1` 表示 K 线已经闭合。
- OKX 可能按时间倒序返回数据，后一次请求也可能命中较旧缓存。应用不得假设响应严格单调，也不得因旧响应删除本地较新的 K 线。
- OKX base URL、连接/读取超时、调度开关和刷新周期必须支持外部配置。
- 调用公开行情不得要求 API Key 或 OKX 账户。
- 生产应用和显式 live smoke 必须直接调用 OKX 官方 API，不得通过测试桩、代理业务服务或抓取服务替代。

## 数据持久化

- 通过 MyBatis-Plus 将 K 线保存到 SQLite。
- 数据库必须对 `(instrument, bar, open_time)` 建立唯一约束。
- 重复同步必须幂等。
- 未闭合 K 线应原位更新。
- 已闭合 K 线在应用重启后仍可查询。
- 价格和成交量不得以二进制浮点数作为权威值，Java 与 SQLite 均采用 decimal-safe 表示。
- 保存足够的同步状态，以展示最近一次尝试、最近一次成功和最近失败；错误文本不得反向成为生命周期状态 owner。
- 数据库初始化必须确定且版本化，不得在业务代码中临时拼接建表流程。

## 定时同步

- 启用同步时，应用启动后执行一次初始回填。
- 默认每 15 秒轮询一次 OKX，周期可配置。
- 每轮必须先完整解析并校验 OKX envelope，再写数据库。
- 同一响应中的合法 K 线在一个事务内完成 upsert。
- HTTP 超时、非 2xx、OKX 业务错误、限流、非法 JSON、非法行或数据库异常不得删除已有 K 线。
- 不得进行无界立即重试；失败后记录 degraded 状态，等待下一轮调度。
- 单应用实例内不得出现重叠调度执行。
- 日志只记录必要运行元数据，失败时不得打印完整 OKX 响应正文。

## 后端 API

提供稳定 JSON API：

1. 查询最近最多 300 根已保存 K 线，按开盘时间升序返回。
2. 查询同步健康状态，包括当前状态、最近尝试时间、最近成功时间和有界安全的失败摘要。

非法 limit 必须返回明确的客户端错误。浏览器只能调用本应用后端，不得直接请求 OKX。

## Web 体验

- 首屏直接展示可用的行情界面，而不是营销落地页。
- 展示真实蜡烛 K 线和成交量。
- 展示 `BTC / USDT`、`1m`、最新收盘价、最近闭合 K 线时间、同步状态和最近成功刷新时间。
- 浏览器默认每 10 秒从后端刷新数据，不整页重载。
- 同步 degraded 时保留最后可用图表，并显示克制但清晰的状态。
- 正确处理首次加载、无数据、数据降级和后端失败状态。
- 当前桌面和移动端视口均应可用，文字、图表和操作不得重叠。
- 不得把模拟价格冒充为 OKX 实时行情。

## 验证要求

- 生产实现只能直连 OKX 官方公开 API。
- `mvn test` 不得依赖公网 OKX 的可用性；自动化测试使用本地、契约一致的 HTTP stub 和冻结 fixture，专门验证正常响应及公网无法稳定制造的超时、429、乱序、陈旧缓存与畸形响应。
- 测试必须覆盖首次回填、倒序输入、重复同步、未闭合 K 线更新、闭合 K 线持久化、陈旧响应、非法 envelope、非法行、超时、非 2xx、OKX 业务错误和调度不重叠。
- 使用临时 SQLite 数据库验证唯一约束与重启后持久化。
- 覆盖后端 API 排序、limit 校验、健康状态，以及同步失败后保留已有数据。
- 提供浏览器级或 DOM 级验证，证明图表消费本应用后端数据、定时刷新且不从浏览器调用 OKX。
- Java 25 下执行 `mvn test` 必须通过，并且测试执行期间无需访问公开 OKX API。
- 提供显式 opt-in live smoke 命令，直接向 OKX 官方接口发起一次只读请求，并验证至少一根结构合法的 BTC-USDT 1m K 线；该命令不得进入默认 `mvn test`。
- README 必须记录架构、配置、SQLite 路径、启动、测试、live smoke、API、数据新鲜度语义和限制。

## 不在范围内

- 交易、账户访问、认证、API Key、余额或任何私有 OKX API。
- 投资建议、告警、策略、技术指标或预测。
- WebSocket 行情。
- 多交易品种或多周期切换。
- 分布式调度或多实例协调。
- 用户账户或管理后台。
- 通用交易所抽象或行情平台。
- 运行时 CDN 依赖。



## Context Package

### Direct Input Artifacts

- .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/task-contract.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/task-contract.md
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/contract-resolution.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/contract-resolution.md
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260912T081920Z-KPPZ/context/agent-governance-node-design-claude_design-014-run-1789202097910.md

```text
# Agent Run Governance Context

- Workstream: ws-20260912T081920Z-KPPZ
- Target Node: design.claude_design
- Agent Node Instance: node-design-claude_design-014
- Run Id: run-1789202097910
- Generated At: 2026-09-12T08:34:57.982655Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-design-claude_design-014-run-1789202097910/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-design-claude_design-014-run-1789202097910/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-design-claude_design-014-run-1789202097910/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-design-claude_design-014-run-1789202097910/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - pom.xml
  - README.md
  - src/main/java/com/example/okxkline/OkxKlineApplication.java
  - src/main/java/com/example/okxkline/config/OkxClientConfig.java
- Expected edit files: (none planned)
```

Context use rule:

- If the package contains `Working Memory`, use it before reading repository files.
- Re-read files only when the memory is missing, stale, or insufficient for this design decision.
- If the Context Package contains a Read Reuse Contract, follow that contract exactly. Do not invent read-reuse fields when the contract does not declare them.

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_ARCH_REVIEW]




`result.revision_responses` is required: return [] when there are no active authored obligations. Otherwise cover every active obligation_id from Required Authored Context exactly once; do not add unknown IDs or omit unresolved obligations. Each entry has exactly obligation_id, disposition (ADDRESSED or NOT_ADDRESSED), and non-empty evidence. Use NOT_ADDRESSED when unresolved; ADDRESSED is a claim for review, not an approval or closure. Preserve all previously required behavior and the approved contract while making this revision.Each `result.revision_responses` item is a closed object with exactly these fields: [obligation_id, disposition, evidence]. No other keys are permitted.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20260912T081920Z-KPPZ",
  "run_id" : "run-1789202097910",
  "node_id" : "design.claude_design",
  "result" : {
    "artifact_type" : "design_result",
    "decision" : "READY_FOR_ARCH_REVIEW",
    "summary" : "one short sentence",
    "lifecycle_status" : "READY",
    "checks" : [ "read the approved contract" ],
    "evidence" : [ "design evidence" ],
    "missing_evidence" : [ ],
    "must_fix" : [ ],
    "open_risks" : [ ],
    "verification_summary" : "Design only; no implementation performed.",
    "design" : {
      "planned_files" : [ {
        "path" : "repo/relative/new.ext",
        "operation" : "CREATE",
        "responsibility" : "responsibility assigned within the approved scope"
      } ]
    },
    "revision_responses" : [ ]
  }
}


# Required Authored Context

The following verified inputs are mandatory. Respond to every active obligation; ADDRESSED does not close it. Use NOT_ADDRESSED honestly. Initial authors return [].

## Active obligations

[ ]
