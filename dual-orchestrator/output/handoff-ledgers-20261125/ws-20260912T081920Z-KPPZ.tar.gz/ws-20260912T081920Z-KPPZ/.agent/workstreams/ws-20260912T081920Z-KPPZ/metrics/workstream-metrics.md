# Workstream Metrics

- Workstream: ws-20260912T081920Z-KPPZ
- Workflow: agent-lifecycle-small-plan-human-review-experiment@1
- Status: WAITING_FOR_RECOVERY
- Generated At: 2026-09-12T08:40:09.702981Z

## Counts

- Nodes: 13
- Agent Runs: 5
- Gates: 2
- Decisions: 2
- Iterations: 2
- Revisions: 1
- Total Node Duration(ms): 716539

## Longest Nodes

| Node | Status | Iteration | Duration(ms) |
| --- | --- | --- | --- |
| design.claude_design | FAILED | iter-002 | 311797 |
| intake.claude_brainstorm | COMPLETED | iter-001 | 210212 |
| intake.codex_product_review | COMPLETED | iter-001 | 80645 |
| intake.claude_brainstorm | COMPLETED | iter-002 | 78230 |
| intake.codex_product_review | COMPLETED | iter-002 | 35438 |

## Provider Metrics

| Provider | Runs | Completed | Failed | Recoverable | Total Duration(ms) | Average Duration(ms) |
| --- | --- | --- | --- | --- | --- | --- |
| claude | 3 | 2 | 1 | 1 | 588627 | 196209 |
| codex | 2 | 2 | 0 | 0 | 109963 | 54981 |
| outcomeStatusCounts | null | null | null | null | null | null |
| executionConsistencyCounts | null | null | null | null | null | null |

## Token Metrics

- Measured Runs: 5 / 5
- Session Snapshots: 0
- Estimated Runs: 0
- Input Tokens: 107113
- Output Tokens: 42269
- Cached Read Tokens: 321600
- Cached Write Tokens: 0
- Total Tokens: 470982
- Estimated Tokens (fallback, not in total): 0

### Token Usage By Step

| Node | Agent | Status | Outcome | Source | Input | Output | Transcript | Context | Prompt Overhead | Adapter Overhead | Total |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| intake.claude_brainstorm | claude | completed | SUCCESS | acpx_stream | 8651 | 15748 | 5026 | 991 | 4225 | 3435 | 30351 |
| intake.codex_product_review | codex | completed | SUCCESS | acpx_stream | 2820 | 1628 | 1889 | 4554 | 4674 | 0 | 36448 |
| intake.claude_brainstorm | claude | completed | SUCCESS | acpx_stream | 17975 | 5812 | 2122 | 991 | 8792 | 8192 | 35115 |
| intake.codex_product_review | codex | completed | SUCCESS | acpx_stream | 17669 | 988 | 776 | 4554 | 5050 | 8065 | 53345 |
| design.claude_design | claude | failed | CONTRACT_FAILED | acpx_stream | 59998 | 18093 | 8961 | 0 | 3467 | 56531 | 315723 |

### Top Context Sections

| Target Node | Profile | Section | Rendered | Original | Degraded | Dropped |
| --- | --- | --- | --- | --- | --- | --- |
| intake.codex_product_review | product_review | input_artifacts | 425 | 425 | false | false |
| intake.codex_product_review | product_review | recent_agent_outputs | 204 | 204 | false | false |
| intake.codex_product_review | product_review | review_evidence | 179 | 179 | false | false |
| intake.claude_brainstorm | intake | ledger_pointers | 161 | 170 | true | false |
| intake.codex_product_review | product_review | ledger_pointers | 161 | 170 | true | false |
| intake.claude_brainstorm | intake | task_contract | 0 | 0 | false | false |

## Tool Metrics

- Tool Calls: 18
- Reads: 18
- Writes: 0
- Bash Commands: 0
- Evidence Files: 0

### Repeated Read Files

| File | Reads | Agents | Nodes | Evidence Known | Reread Reason |
| --- | --- | --- | --- | --- | --- |
| README.md | 3 | claude | intake.claude_brainstorm, design.claude_design | false | not_required |
| REQUIREMENT.md | 3 | claude | intake.claude_brainstorm, design.claude_design | false | not_required |
| .gitignore | 2 | claude | intake.claude_brainstorm, design.claude_design | false | not_required |
| scripts/verify-workspace.sh | 2 | claude | intake.claude_brainstorm, design.claude_design | false | not_required |
