# Agent Run Governance Context

- Workstream: ws-20260912T081920Z-KPPZ
- Target Node: intake.codex_product_review
- Agent Node Instance: node-intake-codex_product_review-009
- Run Id: run-1789201640385
- Generated At: 2026-09-12T08:27:20.388501Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-codex_product_review-009-run-1789201640385/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-codex_product_review-009-run-1789201640385/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-codex_product_review-009-run-1789201640385/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-codex_product_review-009-run-1789201640385/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
