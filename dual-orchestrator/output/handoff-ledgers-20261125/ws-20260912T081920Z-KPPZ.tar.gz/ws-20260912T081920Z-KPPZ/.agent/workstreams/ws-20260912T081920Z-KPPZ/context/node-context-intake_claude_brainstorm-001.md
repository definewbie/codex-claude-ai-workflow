# Context Package

- Workstream: ws-20260912T081920Z-KPPZ
- Builder Node: context.intake_claude_brainstorm
- Target Node: intake.claude_brainstorm
- Generated At: 2026-09-12T08:21:10.822526Z
- Profile: intake
- Total: 161 / 3.0k tokens

## Context Governance

| Section | Level | Degraded | Original | Current |
|---|---|---|---|---|
| task_contract | full | - | 0 | 0 |
| ledger_pointers | pointer_only | yes | 170 | 161 |

Degraded sections have full data at their original paths listed below.

## State & Evidence Boundary

This package separates deterministic harness facts from agent proposals.

### Trusted Harness Facts

- TaskContract qualification: not available
- Git Evidence: not generated yet

### Human Decisions

- Requirement Resolution: not available

### Agent Proposed States

- No routed validated agent sidecars yet

### Pending Contract/Evidence Gaps

- No contract failure diagnostics recorded

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Repo map: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/repo-map.json
- Repository fact binding: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/binding.json
- Tracked inventory: count=0; head=; sha256=

- File relevance plan: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/file-relevance-plan.json
- Stage scope policy: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/stage-scope-policy.json
- Workstream memory: .agent/workstreams/ws-20260912T081920Z-KPPZ/memory/workstream-memory.json
- Working set: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/working-set.json
- File summaries: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/file-summaries.json
- Read reuse contract: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/read-reuse-contract.json
- Agent capability catalog: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/agent-capability-catalog.json
- Governance report: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/planned-report.json

- Recommended read files: (none planned)
- Contract scope candidates: (none planned)
- Allowed write files: (none planned)
- Forbidden scope:
  - .git/**
  - .agent/workstreams/**/workflow/**
  - .agent/workstreams/**/nodes/**
  - business source writes
- Already inspected files: (none planned)
- Read reuse rule: use the recommended read files first; no repeated-read risk is known yet.
Read recommendations are context only. Declared edits must match TaskContract.scope and are verified from Git evidence.

## TaskContract

(not available)

## Ledger Pointers

- Events: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ/.agent/workstreams/ws-20260912T081920Z-KPPZ/events.jsonl
- Workflow current: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ/.agent/workstreams/ws-20260912T081920Z-KPPZ/workflow/current.json
- Node state directory: /Users/kriswang/work/proj

[adaptively compressed; section degraded to stay within ~125 tokens; full source remains in ledger under /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ/.agent/workstreams/ws-20260912T081920Z-KPPZ]

