# Current Failure

## Summary

- Workflow Status: WAITING_FOR_RECOVERY
- Node: design.claude_design
- Node Instance: node-design-claude_design-014
- Node Status: FAILED
- Handler: acpx.agent_run
- Reason: AGENT_OUTPUT_CONTRACT_VIOLATION
- Recoverable: N/A
- Exit Code: 0
- Run ID: run-1789202097910
- Agent: claude
- Session: claude-main-ws-20260912T081920Z-KPPZ-run-1789202097910
- Attention Category: ARTIFACT_CONTRACT_FAILURE
- Retry Safe: false

## Contract Failure Diagnostic

- Diagnostic JSON: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/contract-failures/node-design-claude_design-014.json
- Diagnostic Markdown: .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/contract-failures/node-design-claude_design-014.md
- Error Code: DESIGN_SCOPE_INVALID
- Error Message: Design is not within the approved contract
- Details:
  - errors: [DESIGN_SCOPE_NOT_AUTHORIZED: src/main/java/com/example/okxkline/okx/okx 占位]

## Evidence

- .agent/workstreams/ws-20260912T081920Z-KPPZ/runs/run-1789202097910/outputs/design-claude.stderr.log
- .agent/workstreams/ws-20260912T081920Z-KPPZ/runs/run-1789202097910/outputs/design-claude.transcript.log
- .agent/workstreams/ws-20260912T081920Z-KPPZ/runs/run-1789202097910/outputs/design-claude.json
- .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-design-claude_design-014-run-1789202097910/binding.json
- .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/contract-failures/node-design-claude_design-014.json
- .agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/contract-failures/node-design-claude_design-014.md

## Suggested Action

- Inspect the diagnostic details, prompt contract, and source output before retrying the node.
- Inspect the contract diagnostic and fix the output contract before retrying.
- Command: `dualctl retry --workdir /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ ws-20260912T081920Z-KPPZ`.
