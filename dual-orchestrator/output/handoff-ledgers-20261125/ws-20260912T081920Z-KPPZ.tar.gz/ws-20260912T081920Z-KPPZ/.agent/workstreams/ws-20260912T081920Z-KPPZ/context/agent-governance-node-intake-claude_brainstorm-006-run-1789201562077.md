# Agent Run Governance Context

- Workstream: ws-20260912T081920Z-KPPZ
- Target Node: intake.claude_brainstorm
- Agent Node Instance: node-intake-claude_brainstorm-006
- Run Id: run-1789201562077
- Generated At: 2026-09-12T08:26:02.108711Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789201562077/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789201562077/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789201562077/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789201562077/binding.json

- Tracked inventory: count=4; head=c84807946493a603c789ee40c6a4c615aa846c3b; sha256=df80ed33104a28c6285358790cf77533328b089bd62e5a10379e37ec6e9f9298

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - REQUIREMENT.md
  - scripts/verify-workspace.sh
- Expected edit files: (none planned)
