# Agent Run Governance Context

- Workstream: ws-20260912T081920Z-KPPZ
- Target Node: design.claude_design
- Agent Node Instance: node-design-claude_design-014
- Run Id: run-1789202097910
- Generated At: 2026-09-12T08:34:57.982655Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-design-claude_design-014-run-1789202097910/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-design-claude_design-014-run-1789202097910/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-design-claude_design-014-run-1789202097910/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260912T081920Z-KPPZ/artifacts/context-governance/occurrences/node-design-claude_design-014-run-1789202097910/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - pom.xml
  - README.md
  - src/main/java/com/example/okxkline/OkxKlineApplication.java
  - src/main/java/com/example/okxkline/config/OkxClientConfig.java
- Expected edit files: (none planned)
