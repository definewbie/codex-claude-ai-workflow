# Workstream Summary

- Workstream: ws-20260912T081920Z-KPPZ
- Workspace: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ
- Ledger: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ/.agent/workstreams/ws-20260912T081920Z-KPPZ
- Generated At: 2026-09-12T08:40:09.712255Z

## Workflow

- Definition: agent-lifecycle-small-plan-human-review-experiment@1
- Status: WAITING_FOR_RECOVERY
- Status Source: workflow_current
- Active Nodes: node-design-claude_design-014
- Open Gates: recovery-node-design-claude_design-014
- Updated At: 2026-09-12T08:40:09.696538Z

## Metrics

- Nodes: 13
- Agent Runs: 5
- Gates: 2
- Decisions: 2
- Iterations: 2
- Revisions: 1
- Total Node Duration(ms): 716539
- Token Runs: 5 / 5
- Total Tokens: 470982 (input 107113, output 42269)
- Metrics: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ/.agent/workstreams/ws-20260912T081920Z-KPPZ/metrics/workstream-metrics.md

## Recommended Next Action

Artifact contract failed

Inspect the diagnostic details, prompt contract, and source output before retrying the node.

Inspect the contract diagnostic and fix the output contract before retrying.

```bash
dualctl recovery show --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ' ws-20260912T081920Z-KPPZ
dualctl retry --workdir /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ ws-20260912T081920Z-KPPZ
```

## Recent Timeline

| Node | Kind | Status | Iteration | Duration |
| --- | --- | --- | --- | --- |
| intake.claude_brainstorm | TASK | COMPLETED | iter-001 | 210212 |
| context.intake_codex_product_review | TASK | COMPLETED | iter-001 | 41 |
| intake.codex_product_review | TASK | COMPLETED | iter-001 | 80645 |
| intake.decision | DECISION | COMPLETED | iter-001 | 13 |
| intake.claude_brainstorm | TASK | COMPLETED | iter-002 | 78230 |
| context.intake_codex_product_review | TASK | COMPLETED | iter-002 | 26 |
| intake.codex_product_review | TASK | COMPLETED | iter-002 | 35438 |
| intake.decision | DECISION | COMPLETED | iter-002 | 14 |
| gate.human_requirement_review | GATE | COMPLETED | iter-002 |  |
| contract.compile | TASK | COMPLETED | iter-002 | 75 |
| gate.contract_review | GATE | COMPLETED | iter-002 |  |
| design.claude_design | TASK | FAILED | iter-002 | 311797 |

## Artifacts

- Final Report: missing
- Current Failure Summary: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ/.agent/workstreams/ws-20260912T081920Z-KPPZ/recovery/current-failure.md
- Delivery: BLOCKED, changedFiles=0, target=/Users/kriswang/work/projects/ai/okx-btc-k-line-demo, reason=WORKFLOW_NOT_DELIVERABLE:workstream is not completed: WAITING_FOR_RECOVERY
- Calibration Candidates: 0
- Calibration Apply Plans: 0

## Useful Commands

```bash
dualctl status --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ' ws-20260912T081920Z-KPPZ
dualctl timeline --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ' ws-20260912T081920Z-KPPZ
dualctl review show --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ' ws-20260912T081920Z-KPPZ
dualctl recovery show --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260912T081920Z-KPPZ' ws-20260912T081920Z-KPPZ
```
