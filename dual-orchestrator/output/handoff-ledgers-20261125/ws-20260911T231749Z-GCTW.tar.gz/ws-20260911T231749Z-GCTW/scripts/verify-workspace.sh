#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel)"
test "$(pwd -P)" = "$(cd "$ROOT" && pwd -P)"
test -f REQUIREMENT.md
test -f README.md
test ! -e pom.xml
test ! -d src

JAVA_VERSION="$(java -version 2>&1 | head -n 1)"
case "$JAVA_VERSION" in
  *'"25.'*) ;;
  *) echo "Java 25 is required: $JAVA_VERSION" >&2; exit 1 ;;
esac

test -z "$(git status --porcelain --untracked-files=no)"

BODY="$(mktemp)"
trap 'rm -f "$BODY"' EXIT
curl --fail --silent --show-error \
  --connect-timeout 5 \
  --max-time 15 \
  'https://www.okx.com/api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=2' \
  > "$BODY"

python3 - "$BODY" <<'PY'
import json
import pathlib
import sys

document = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
if document.get("code") != "0":
    raise SystemExit("OKX returned a non-success business code")
rows = document.get("data")
if not isinstance(rows, list) or not rows:
    raise SystemExit("OKX returned no candle rows")
for row in rows:
    if not isinstance(row, list) or len(row) != 9:
        raise SystemExit("OKX candle row does not have 9 fields")
    if row[8] not in ("0", "1"):
        raise SystemExit("OKX candle confirm field is invalid")
PY

echo "workspace preflight passed"
