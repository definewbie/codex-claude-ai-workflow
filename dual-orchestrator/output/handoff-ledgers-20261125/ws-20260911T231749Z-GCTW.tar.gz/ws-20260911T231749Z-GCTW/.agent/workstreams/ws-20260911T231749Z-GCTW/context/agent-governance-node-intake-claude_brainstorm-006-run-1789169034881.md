# Agent Run Governance Context

- Workstream: ws-20260911T231749Z-GCTW
- Target Node: intake.claude_brainstorm
- Agent Node Instance: node-intake-claude_brainstorm-006
- Run Id: run-1789169034881
- Generated At: 2026-09-11T23:23:54.909869Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789169034881/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789169034881/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789169034881/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789169034881/binding.json

- Tracked inventory: count=4; head=c84807946493a603c789ee40c6a4c615aa846c3b; sha256=df80ed33104a28c6285358790cf77533328b089bd62e5a10379e37ec6e9f9298

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - REQUIREMENT.md
  - scripts/verify-workspace.sh
- Expected edit files: (none planned)
