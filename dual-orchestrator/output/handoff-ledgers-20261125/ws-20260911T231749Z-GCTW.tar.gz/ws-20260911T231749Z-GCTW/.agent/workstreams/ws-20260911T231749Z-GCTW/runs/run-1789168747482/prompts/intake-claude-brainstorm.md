## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW
- This intake run uses restricted contract discovery. Use orchestrator-provided context and bounded discovery only.
- Do not output shell commands or Bash code fences as a substitute for the required structured artifact.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.



# Claude Intake Brainstorm

Workstream: ws-20260911T231749Z-GCTW
Node: intake.claude_brainstorm
Template: intake-claude-brainstorm
Ledger: .agent/workstreams/ws-20260911T231749Z-GCTW

You are Claude acting as the primary developer and product-design partner.

Use the orchestrator-provided seed, tracked-path inventory, memory, contract scope, and context recommendations to clarify the user request before implementation. This intake stage permits targeted Read/Grep/Glob discovery inside the effective workspace so the contract can be grounded in repository facts. Start from the projected repo map, inspect only the files needed to determine exact scope and acceptance semantics, and do not start an open-ended repository survey. Terminal, Bash, execute, write, edit, and file creation remain prohibited. When the tracked inventory is non-empty, `evidence_refs` must include at least one existing repository file that supports the proposed scope; additional durable evidence references remain allowed. Do not return `READY_FOR_PRODUCT_REVIEW` from filenames or requirement prose alone. If evidence remains insufficient, preserve the uncertainty in supported fields for reviewer/human judgment; do not end with a prose-only "I need to inspect the repo" message.

If the context package includes a previous Codex review, Must Fix list, or revision request, treat it as mandatory feedback for this intake revision. Explicitly address each Must Fix in the updated artifact instead of repeating the previous draft.

Revision convergence policy:

- Must Fix feedback is stronger than the previous draft. The revised proposal must change the contract enough that each Must Fix is satisfied by construction.
- Do not move an already-specified user constraint into `open_questions`. If the user request or Codex Must Fix already states the rule, encode the rule directly into `acceptance_criteria`, `constraints`, and `test_requirements`.
- Before returning `READY_FOR_PRODUCT_REVIEW`, account for every explicit user objective, allowed/excluded file, behavior constraint, acceptance criterion, and verification requirement in a binding proposal field: `objective`, `scope`, `acceptance_criteria`, `test_requirements`, `constraints`, or `non_goals`. A requirement mentioned only in `risk_areas`, `open_questions`, or `evidence_refs` is not preserved.
- For an initial proposal over a non-empty tracked inventory, include at least one `evidence_refs` entry from the projected repo map. Evidence references support scope reasoning but never authorize edits by themselves.
- Do not copy the current node's `AgentResultEnvelope`, JSON-only output, or workflow-routing protocol into the task proposal. Those are enforced independently by the orchestrator's Output Contract and are not product or implementation requirements.
- Preserve the user's semantic boundary exactly. Do not broaden or narrow behavior based on language-specific edge cases, inferred product preferences, or a conservative implementation choice that the user did not request.
- Treat the typed scope projected by the Output Contract as the exhaustive authorization set for permitted repository changes. It does not require every declared path to be changed. Do not use acceptance criteria, constraints, risks, or other prose to authorize undeclared paths, and never describe typed scope as illustrative or non-exhaustive. When a revision obligation identifies a scope gap, use only the exact typed scope-addition field rendered by the Output Contract and map the obligation to one or more genuinely relevant clause IDs.
- Use `open_questions` only for real product ambiguity that cannot be resolved from the user request, repository evidence, or prior Codex feedback.
- If an implementation tradeoff does not change user-visible semantics, choose the simplest compliant implementation and record material risk in `risk_areas`. If it would change the accepted input, output, scope, or observable behavior, preserve the literal user requirement and record the unresolved choice without turning it into a constraint or test.
- When revising after a Codex Must Fix, include at least one acceptance criterion or test requirement for each Must Fix. Do not claim readiness while leaving a Must Fix as a future human decision.

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.
- Even when repository evidence is insufficient, the final assistant message must be the required strict JSON result. A prose-only response is a contract failure.

## User Request

# OKX BTC 分钟级 K 线 Web 应用需求

## 目标

构建一个本地 Web 应用，通过 OKX 官方公开行情 REST API 获取 BTC-USDT 现货分钟级 K 线，将数据持久化到 SQLite，并展示可定时刷新的 K 线图。

本应用只读取公开行情，不得下单、访问账户、提供投资建议或抓取 OKX 网页。

## 强制技术栈

- Java 25。
- Spring Boot 4.1.0。
- Maven。
- MyBatis-Plus 3.5.17，必须使用 `mybatis-plus-spring-boot4-starter`。
- SQLite 是唯一应用数据库。
- 使用成熟的 K 线图表库，生产资源必须随应用本地打包，不得依赖运行时 CDN。

不得用 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施替代 MyBatis-Plus。

## OKX 行情契约

- 数据源只能是 OKX 官方公开 Market Data REST API，不得抓取 HTML 页面。
- 交易品种固定为 BTC-USDT 现货。
- K 线周期固定为 `1m`。
- 接口为 `GET /api/v5/market/candles`。
- 首次启动拉取并保存最近 300 根 K 线。
- 响应行格式为 `[ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]`。
- `ts` 是 K 线开盘时间的 Unix 毫秒时间戳。
- `confirm=0` 表示当前 K 线尚未闭合，后续允许更新。
- `confirm=1` 表示 K 线已经闭合。
- OKX 可能按时间倒序返回数据，后一次请求也可能命中较旧缓存。应用不得假设响应严格单调，也不得因旧响应删除本地较新的 K 线。
- OKX base URL、连接/读取超时、调度开关和刷新周期必须支持外部配置。
- 调用公开行情不得要求 API Key 或 OKX 账户。
- 生产应用和显式 live smoke 必须直接调用 OKX 官方 API，不得通过测试桩、代理业务服务或抓取服务替代。

## 数据持久化

- 通过 MyBatis-Plus 将 K 线保存到 SQLite。
- 数据库必须对 `(instrument, bar, open_time)` 建立唯一约束。
- 重复同步必须幂等。
- 未闭合 K 线应原位更新。
- 已闭合 K 线在应用重启后仍可查询。
- 价格和成交量不得以二进制浮点数作为权威值，Java 与 SQLite 均采用 decimal-safe 表示。
- 保存足够的同步状态，以展示最近一次尝试、最近一次成功和最近失败；错误文本不得反向成为生命周期状态 owner。
- 数据库初始化必须确定且版本化，不得在业务代码中临时拼接建表流程。

## 定时同步

- 启用同步时，应用启动后执行一次初始回填。
- 默认每 15 秒轮询一次 OKX，周期可配置。
- 每轮必须先完整解析并校验 OKX envelope，再写数据库。
- 同一响应中的合法 K 线在一个事务内完成 upsert。
- HTTP 超时、非 2xx、OKX 业务错误、限流、非法 JSON、非法行或数据库异常不得删除已有 K 线。
- 不得进行无界立即重试；失败后记录 degraded 状态，等待下一轮调度。
- 单应用实例内不得出现重叠调度执行。
- 日志只记录必要运行元数据，失败时不得打印完整 OKX 响应正文。

## 后端 API

提供稳定 JSON API：

1. 查询最近最多 300 根已保存 K 线，按开盘时间升序返回。
2. 查询同步健康状态，包括当前状态、最近尝试时间、最近成功时间和有界安全的失败摘要。

非法 limit 必须返回明确的客户端错误。浏览器只能调用本应用后端，不得直接请求 OKX。

## Web 体验

- 首屏直接展示可用的行情界面，而不是营销落地页。
- 展示真实蜡烛 K 线和成交量。
- 展示 `BTC / USDT`、`1m`、最新收盘价、最近闭合 K 线时间、同步状态和最近成功刷新时间。
- 浏览器默认每 10 秒从后端刷新数据，不整页重载。
- 同步 degraded 时保留最后可用图表，并显示克制但清晰的状态。
- 正确处理首次加载、无数据、数据降级和后端失败状态。
- 当前桌面和移动端视口均应可用，文字、图表和操作不得重叠。
- 不得把模拟价格冒充为 OKX 实时行情。

## 验证要求

- 生产实现只能直连 OKX 官方公开 API。
- `mvn test` 不得依赖公网 OKX 的可用性；自动化测试使用本地、契约一致的 HTTP stub 和冻结 fixture，专门验证正常响应及公网无法稳定制造的超时、429、乱序、陈旧缓存与畸形响应。
- 测试必须覆盖首次回填、倒序输入、重复同步、未闭合 K 线更新、闭合 K 线持久化、陈旧响应、非法 envelope、非法行、超时、非 2xx、OKX 业务错误和调度不重叠。
- 使用临时 SQLite 数据库验证唯一约束与重启后持久化。
- 覆盖后端 API 排序、limit 校验、健康状态，以及同步失败后保留已有数据。
- 提供浏览器级或 DOM 级验证，证明图表消费本应用后端数据、定时刷新且不从浏览器调用 OKX。
- Java 25 下执行 `mvn test` 必须通过，并且测试执行期间无需访问公开 OKX API。
- 提供显式 opt-in live smoke 命令，直接向 OKX 官方接口发起一次只读请求，并验证至少一根结构合法的 BTC-USDT 1m K 线；该命令不得进入默认 `mvn test`。
- README 必须记录架构、配置、SQLite 路径、启动、测试、live smoke、API、数据新鲜度语义和限制。

## 不在范围内

- 交易、账户访问、认证、API Key、余额或任何私有 OKX API。
- 投资建议、告警、策略、技术指标或预测。
- WebSocket 行情。
- 多交易品种或多周期切换。
- 分布式调度或多实例协调。
- 用户账户或管理后台。
- 通用交易所抽象或行情平台。
- 运行时 CDN 依赖。



## Context Package

- .agent/workstreams/ws-20260911T231749Z-GCTW/context/node-context-intake_claude_brainstorm-001.md

```text
# Context Package

- Workstream: ws-20260911T231749Z-GCTW
- Builder Node: context.intake_claude_brainstorm
- Target Node: intake.claude_brainstorm
- Generated At: 2026-09-11T23:19:07.239978Z
- Profile: intake
- Total: 161 / 3.0k tokens

## Context Governance

| Section | Level | Degraded | Original | Current |
|---|---|---|---|---|
| task_contract | full | - | 0 | 0 |
| ledger_pointers | pointer_only | yes | 170 | 161 |

Degraded sections have full data at their original paths listed below.

## State & Evidence Boundary

This package separates deterministic harness facts from agent proposals.

### Trusted Harness Facts

- TaskContract qualification: not available
- Git Evidence: not generated yet

### Human Decisions

- Requirement Resolution: not available

### Agent Proposed States

- No routed validated agent sidecars yet

### Pending Contract/Evidence Gaps

- No contract failure diagnostics recorded

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Repo map: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/repo-map.json
- Repository fact binding: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/binding.json
- Tracked inventory: count=0; head=; sha256=

- File relevance plan: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/file-relevance-plan.json
- Stage scope policy: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/stage-scope-policy.json
- Workstream memory: .agent/workstreams/ws-20260911T231749Z-GCTW/memory/workstream-memory.json
- Working set: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/working-set.json
- File summaries: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/file-summaries.json
- Read reuse contract: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/read-reuse-contract.json
- Agent capability catalog: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/agent-capability-catalog.json
- Governance report: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/planned-report.json

- Recommended read files: (none planned)
- Contract scope candidates: (none planned)
- Allowed write files: (none planned)
- Forbidden scope:
  - .git/**
  - .agent/workstreams/**[outside-workspace path removed]
  - .agent/workstreams/**[outside-workspace path removed]
  - business source writes
- Already inspected files: (none planned)
- Read reuse rule: use the recommended read files first; no repeated-read risk is known yet.
Read recommendations are context only. Declared edits must match TaskContract.scope and are verified from Git evidence.

## TaskContract

(not available)

## Ledger Pointers

- Events: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/events.jsonl
- Workflow current: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/workflow/current.json
- Node state directory: [outside-workspace path removed]

[adaptively compressed; section degraded to stay within ~125 tokens; full source remains in ledger under /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW]
```

- .agent/workstreams/ws-20260911T231749Z-GCTW/context/agent-governance-node-intake-claude_brainstorm-002-run-1789168747482.md

```text
# Agent Run Governance Context

- Workstream: ws-20260911T231749Z-GCTW
- Target Node: intake.claude_brainstorm
- Agent Node Instance: node-intake-claude_brainstorm-002
- Run Id: run-1789168747482
- Generated At: 2026-09-11T23:19:07.524531Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1789168747482/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1789168747482/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1789168747482/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1789168747482/binding.json

- Tracked inventory: count=4; head=c84807946493a603c789ee40c6a4c615aa846c3b; sha256=df80ed33104a28c6285358790cf77533328b089bd62e5a10379e37ec6e9f9298

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - REQUIREMENT.md
  - scripts/verify-workspace.sh
- Expected edit files: (none planned)
```

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_PRODUCT_REVIEW]



`result.scope.included` is the exhaustive authorization set for permitted repository changes; each entry names one exact repository-relative path. Each scope path must name one exact file, not a directory; it must be repository-relative, must not end with `/`, and must already be canonical (no `./`, `..`, repeated separators, backslashes, leading/trailing whitespace, `.git`, or `.agent` segments). Dual derives CREATE/MODIFY from the effective worktree. It does not require every declared path to be changed. Acceptance criteria, constraints, risks, and other prose cannot authorize an undeclared path. Never describe the typed scope as illustrative or non-exhaustive. When a revision obligation identifies a scope gap, update the typed path entries directly and map the obligation to one or more genuinely relevant clause IDs. Each task-contract clause must contain stable string fields `id` and `text`. On an initial intake, `result.revision_responses` must be `[]`. On a revision, copy every routed Contract Obligation ID exactly once into `review_obligation_id` and list one or more clause IDs in `resolved_by_clause_ids`. Preserve every existing clause not named by the current `revision_responses` by copying its `id` and `text` character-for-character from the verified previous proposal, including whitespace, punctuation, capitalization, and Markdown backticks. Formatting normalization is a modification and is prohibited unless that clause ID is declared in `resolved_by_clause_ids`. List every added or modified clause ID in at least one `resolved_by_clause_ids` entry, and do not delete existing clause IDs. Each `result.revision_responses` item is a closed object with exactly these fields: [review_obligation_id, resolved_by_clause_ids]. No other keys are permitted.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20260911T231749Z-GCTW",
  "run_id" : "run-1789168747482",
  "node_id" : "intake.claude_brainstorm",
  "result" : {
    "artifact_type" : "task_contract_proposal",
    "decision" : "READY_FOR_PRODUCT_REVIEW",
    "summary" : "one short sentence",
    "needs_human_input" : false,
    "objective" : "one clear objective",
    "scope" : {
      "included" : [ {
        "path" : "repo/relative/existing.ext"
      }, {
        "path" : "repo/relative/new.ext"
      } ],
      "excluded" : [ "explicit non-goal" ]
    },
    "acceptance_criteria" : [ {
      "id" : "AC-1",
      "text" : "observable acceptance criterion"
    }, {
      "id" : "AC-2",
      "text" : "second observable criterion"
    } ],
    "test_requirements" : [ {
      "id" : "TR-1",
      "text" : "required verification"
    } ],
    "constraints" : [ {
      "id" : "C-1",
      "text" : "technical or product constraint"
    } ],
    "non_goals" : [ {
      "id" : "NG-1",
      "text" : "explicit non-goal"
    } ],
    "risk_areas" : [ {
      "id" : "R-1",
      "text" : "risk for review"
    } ],
    "evidence_refs" : [ "repo/relative/evidence.ext" ],
    "open_questions" : [ ],
    "revision_responses" : [ ]
  }
}
