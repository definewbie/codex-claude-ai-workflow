# Agent Run Governance Context

- Workstream: ws-20260911T231749Z-GCTW
- Target Node: intake.claude_brainstorm
- Agent Node Instance: node-intake-claude_brainstorm-011
- Run Id: run-1789169178039
- Generated At: 2026-09-11T23:26:18.061548Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-011-run-1789169178039/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-011-run-1789169178039/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-011-run-1789169178039/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-011-run-1789169178039/binding.json

- Tracked inventory: count=4; head=c84807946493a603c789ee40c6a4c615aa846c3b; sha256=df80ed33104a28c6285358790cf77533328b089bd62e5a10379e37ec6e9f9298

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - REQUIREMENT.md
  - scripts/verify-workspace.sh
- Expected edit files: (none planned)
