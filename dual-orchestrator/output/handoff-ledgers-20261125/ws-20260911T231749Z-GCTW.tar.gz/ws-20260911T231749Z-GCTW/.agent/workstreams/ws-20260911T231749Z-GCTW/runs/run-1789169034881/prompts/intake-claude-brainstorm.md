## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW
- This intake run uses restricted contract discovery. Use orchestrator-provided context and bounded discovery only.
- Do not output shell commands or Bash code fences as a substitute for the required structured artifact.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.



# Claude Intake Brainstorm

Workstream: ws-20260911T231749Z-GCTW
Node: intake.claude_brainstorm
Template: intake-claude-brainstorm
Ledger: .agent/workstreams/ws-20260911T231749Z-GCTW

You are Claude acting as the primary developer and product-design partner.

Use the orchestrator-provided seed, tracked-path inventory, memory, contract scope, and context recommendations to clarify the user request before implementation. This intake stage permits targeted Read/Grep/Glob discovery inside the effective workspace so the contract can be grounded in repository facts. Start from the projected repo map, inspect only the files needed to determine exact scope and acceptance semantics, and do not start an open-ended repository survey. Terminal, Bash, execute, write, edit, and file creation remain prohibited. When the tracked inventory is non-empty, `evidence_refs` must include at least one existing repository file that supports the proposed scope; additional durable evidence references remain allowed. Do not return `READY_FOR_PRODUCT_REVIEW` from filenames or requirement prose alone. If evidence remains insufficient, preserve the uncertainty in supported fields for reviewer/human judgment; do not end with a prose-only "I need to inspect the repo" message.

If the context package includes a previous Codex review, Must Fix list, or revision request, treat it as mandatory feedback for this intake revision. Explicitly address each Must Fix in the updated artifact instead of repeating the previous draft.

Revision convergence policy:

- Must Fix feedback is stronger than the previous draft. The revised proposal must change the contract enough that each Must Fix is satisfied by construction.
- Do not move an already-specified user constraint into `open_questions`. If the user request or Codex Must Fix already states the rule, encode the rule directly into `acceptance_criteria`, `constraints`, and `test_requirements`.
- Before returning `READY_FOR_PRODUCT_REVIEW`, account for every explicit user objective, allowed/excluded file, behavior constraint, acceptance criterion, and verification requirement in a binding proposal field: `objective`, `scope`, `acceptance_criteria`, `test_requirements`, `constraints`, or `non_goals`. A requirement mentioned only in `risk_areas`, `open_questions`, or `evidence_refs` is not preserved.
- For an initial proposal over a non-empty tracked inventory, include at least one `evidence_refs` entry from the projected repo map. Evidence references support scope reasoning but never authorize edits by themselves.
- Do not copy the current node's `AgentResultEnvelope`, JSON-only output, or workflow-routing protocol into the task proposal. Those are enforced independently by the orchestrator's Output Contract and are not product or implementation requirements.
- Preserve the user's semantic boundary exactly. Do not broaden or narrow behavior based on language-specific edge cases, inferred product preferences, or a conservative implementation choice that the user did not request.
- Treat the typed scope projected by the Output Contract as the exhaustive authorization set for permitted repository changes. It does not require every declared path to be changed. Do not use acceptance criteria, constraints, risks, or other prose to authorize undeclared paths, and never describe typed scope as illustrative or non-exhaustive. When a revision obligation identifies a scope gap, use only the exact typed scope-addition field rendered by the Output Contract and map the obligation to one or more genuinely relevant clause IDs.
- Use `open_questions` only for real product ambiguity that cannot be resolved from the user request, repository evidence, or prior Codex feedback.
- If an implementation tradeoff does not change user-visible semantics, choose the simplest compliant implementation and record material risk in `risk_areas`. If it would change the accepted input, output, scope, or observable behavior, preserve the literal user requirement and record the unresolved choice without turning it into a constraint or test.
- When revising after a Codex Must Fix, include at least one acceptance criterion or test requirement for each Must Fix. Do not claim readiness while leaving a Must Fix as a future human decision.

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.
- Even when repository evidence is insufficient, the final assistant message must be the required strict JSON result. A prose-only response is a contract failure.

## User Request

# OKX BTC 分钟级 K 线 Web 应用需求

## 目标

构建一个本地 Web 应用，通过 OKX 官方公开行情 REST API 获取 BTC-USDT 现货分钟级 K 线，将数据持久化到 SQLite，并展示可定时刷新的 K 线图。

本应用只读取公开行情，不得下单、访问账户、提供投资建议或抓取 OKX 网页。

## 强制技术栈

- Java 25。
- Spring Boot 4.1.0。
- Maven。
- MyBatis-Plus 3.5.17，必须使用 `mybatis-plus-spring-boot4-starter`。
- SQLite 是唯一应用数据库。
- 使用成熟的 K 线图表库，生产资源必须随应用本地打包，不得依赖运行时 CDN。

不得用 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施替代 MyBatis-Plus。

## OKX 行情契约

- 数据源只能是 OKX 官方公开 Market Data REST API，不得抓取 HTML 页面。
- 交易品种固定为 BTC-USDT 现货。
- K 线周期固定为 `1m`。
- 接口为 `GET /api/v5/market/candles`。
- 首次启动拉取并保存最近 300 根 K 线。
- 响应行格式为 `[ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]`。
- `ts` 是 K 线开盘时间的 Unix 毫秒时间戳。
- `confirm=0` 表示当前 K 线尚未闭合，后续允许更新。
- `confirm=1` 表示 K 线已经闭合。
- OKX 可能按时间倒序返回数据，后一次请求也可能命中较旧缓存。应用不得假设响应严格单调，也不得因旧响应删除本地较新的 K 线。
- OKX base URL、连接/读取超时、调度开关和刷新周期必须支持外部配置。
- 调用公开行情不得要求 API Key 或 OKX 账户。
- 生产应用和显式 live smoke 必须直接调用 OKX 官方 API，不得通过测试桩、代理业务服务或抓取服务替代。

## 数据持久化

- 通过 MyBatis-Plus 将 K 线保存到 SQLite。
- 数据库必须对 `(instrument, bar, open_time)` 建立唯一约束。
- 重复同步必须幂等。
- 未闭合 K 线应原位更新。
- 已闭合 K 线在应用重启后仍可查询。
- 价格和成交量不得以二进制浮点数作为权威值，Java 与 SQLite 均采用 decimal-safe 表示。
- 保存足够的同步状态，以展示最近一次尝试、最近一次成功和最近失败；错误文本不得反向成为生命周期状态 owner。
- 数据库初始化必须确定且版本化，不得在业务代码中临时拼接建表流程。

## 定时同步

- 启用同步时，应用启动后执行一次初始回填。
- 默认每 15 秒轮询一次 OKX，周期可配置。
- 每轮必须先完整解析并校验 OKX envelope，再写数据库。
- 同一响应中的合法 K 线在一个事务内完成 upsert。
- HTTP 超时、非 2xx、OKX 业务错误、限流、非法 JSON、非法行或数据库异常不得删除已有 K 线。
- 不得进行无界立即重试；失败后记录 degraded 状态，等待下一轮调度。
- 单应用实例内不得出现重叠调度执行。
- 日志只记录必要运行元数据，失败时不得打印完整 OKX 响应正文。

## 后端 API

提供稳定 JSON API：

1. 查询最近最多 300 根已保存 K 线，按开盘时间升序返回。
2. 查询同步健康状态，包括当前状态、最近尝试时间、最近成功时间和有界安全的失败摘要。

非法 limit 必须返回明确的客户端错误。浏览器只能调用本应用后端，不得直接请求 OKX。

## Web 体验

- 首屏直接展示可用的行情界面，而不是营销落地页。
- 展示真实蜡烛 K 线和成交量。
- 展示 `BTC / USDT`、`1m`、最新收盘价、最近闭合 K 线时间、同步状态和最近成功刷新时间。
- 浏览器默认每 10 秒从后端刷新数据，不整页重载。
- 同步 degraded 时保留最后可用图表，并显示克制但清晰的状态。
- 正确处理首次加载、无数据、数据降级和后端失败状态。
- 当前桌面和移动端视口均应可用，文字、图表和操作不得重叠。
- 不得把模拟价格冒充为 OKX 实时行情。

## 验证要求

- 生产实现只能直连 OKX 官方公开 API。
- `mvn test` 不得依赖公网 OKX 的可用性；自动化测试使用本地、契约一致的 HTTP stub 和冻结 fixture，专门验证正常响应及公网无法稳定制造的超时、429、乱序、陈旧缓存与畸形响应。
- 测试必须覆盖首次回填、倒序输入、重复同步、未闭合 K 线更新、闭合 K 线持久化、陈旧响应、非法 envelope、非法行、超时、非 2xx、OKX 业务错误和调度不重叠。
- 使用临时 SQLite 数据库验证唯一约束与重启后持久化。
- 覆盖后端 API 排序、limit 校验、健康状态，以及同步失败后保留已有数据。
- 提供浏览器级或 DOM 级验证，证明图表消费本应用后端数据、定时刷新且不从浏览器调用 OKX。
- Java 25 下执行 `mvn test` 必须通过，并且测试执行期间无需访问公开 OKX API。
- 提供显式 opt-in live smoke 命令，直接向 OKX 官方接口发起一次只读请求，并验证至少一根结构合法的 BTC-USDT 1m K 线；该命令不得进入默认 `mvn test`。
- README 必须记录架构、配置、SQLite 路径、启动、测试、live smoke、API、数据新鲜度语义和限制。

## 不在范围内

- 交易、账户访问、认证、API Key、余额或任何私有 OKX API。
- 投资建议、告警、策略、技术指标或预测。
- WebSocket 行情。
- 多交易品种或多周期切换。
- 分布式调度或多实例协调。
- 用户账户或管理后台。
- 通用交易所抽象或行情平台。
- 运行时 CDN 依赖。



## Context Package

### Direct Input Artifacts

- .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789168979272/outputs/intake-codex-product-review.stderr.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789168979272/outputs/intake-codex-product-review.transcript.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789168979272/outputs/intake-codex-product-review.json

```json
{
  "workstreamId" : "ws-20260911T231749Z-GCTW",
  "runId" : "run-1789168979272",
  "nodeId" : "intake.codex_product_review",
  "nodeInstanceId" : "node-intake-codex_product_review-004",
  "stageOutcome" : "NEEDS_REVISION",
  "lifecycleStatus" : "NEEDS_REVISION",
  "decision" : "NEEDS_REVISION",
  "summary" : "提案总体覆盖产品目标，但需澄清陈旧响应语义并补齐首次回填的自动化验证要求。",
  "sourceArtifactType" : "agent_output_contract",
  "sourceOutputRef" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789168979272/outputs/intake-codex-product-review.json",
  "blocking" : true,
  "checks" : [ "对照原始需求审查产品完整性、架构边界、用户体验及验证要求。", "核对精确路径与操作组成的修改授权范围。", "检查需求是否进入具有约束力的字段，以及是否引入未经要求的行为限制。" ],
  "evidence" : [ "AC-5 明确要求未闭合 K 线原位更新；AC-6 同时规定乱序或陈旧响应下已有 K 线“不回退”，但未定义该限制的对象。", "原始需求要求不得因旧响应删除本地较新的 K 线，并未要求价格或成交量数值单调。", "AC-2 描述启动回填最近 300 根，但 TR-1 至 TR-8 未明确要求自动化测试覆盖首次启动回填。", "C-1 至 C-9 已覆盖强制技术栈、官方接口直连、事务、状态字段、日志限制及默认测试与 live smoke 的隔离。" ],
  "mustFix" : [ "将 AC-6 的“不回退”改为可观察且不妨碍未闭合 K 线合法更新的明确规则。", "在 test_requirements 中明确首次启动回填最近 300 根的自动化验证。" ],
  "contractObligations" : [ {
    "id" : "CO-1",
    "text" : "修订 AC-6，明确乱序及陈旧响应不得删除本地较新时间戳的 K 线；不得将价格或成交量数值单调作为更新条件，须保持 AC-5 的未闭合 K 线合法原位更新。若拟增加同一开盘时间的响应新旧判定规则，须说明可用证据及规则，不能假设接口提供未声明的版本信息。"
  }, {
    "id" : "CO-2",
    "text" : "在 test_requirements 中增加首次回填测试：使用本地契约一致 HTTP stub、冻结的 300 根数据及临时 SQLite，启动同步开启的应用，验证启动触发请求并持久化最近 300 根，而非仅直接调用同步方法。可在已授权的 src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java 和 src/test/resources/fixtures/okx/candles-normal.json 中实现，无需扩大路径授权。"
  } ],
  "missingEvidence" : [ ],
  "acceptanceNotes" : [ "无需在产品提案中重复编排器的输出封装或路由协议。", "其余主要产品要求已有明确约束；本次修订不需要新增功能或由用户选择实现技术。", "本次仅审查所提供的契约文本，未修改文件，未执行实现验证。" ],
  "openRisks" : [ ],
  "changedFiles" : [ ],
  "verificationSummary" : "已完成需求与提案的静态对照；两项契约缺口修订后可继续产品评审。",
  "completedWork" : [ ],
  "importantDecisions" : [ ],
  "recommendedNextStage" : "",
  "suggestedNextPrompt" : "",
  "control" : {
    "decision" : "NEEDS_REVISION",
    "summary" : "提案总体覆盖产品目标，但需澄清陈旧响应语义并补齐首次回填的自动化验证要求。"
  },
  "failure" : {
    "categoryHint" : "契约完整性与语义中立性",
    "verificationRemediation" : "NONE",
    "contractGaps" : [ "AC-6 的“不回退”边界不明确，可能限制未闭合 K 线的合法数值更新。", "首次启动回填的自动化测试要求未显式纳入 test_requirements。" ],
    "outOfScopeFiles" : [ ],
    "missingTests" : [ "同步开启时首次启动请求并保存最近 300 根 K 线的自动化测试。" ],
    "contextGaps" : [ ],
    "reason" : "需消除更新语义歧义并保留用户明确要求的首次回填测试义务。"
  },
  "rereadReasons" : [ ],
  "reviewSubject" : {
    "schema_version" : 1,
    "proposal_id" : "node-intake-claude_brainstorm-002:3436838b90db0c6a",
    "workstream_id" : "ws-20260911T231749Z-GCTW",
    "producer_node_id" : "intake.claude_brainstorm",
    "producer_node_instance_id" : "node-intake-claude_brainstorm-002",
    "artifact_ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789168747482/outputs/intake-claude-brainstorm.contract.json",
    "sha256" : "3436838b90db0c6a37bc33dd9168063f5a2c24bb8d390f170dedb50720fe2d0b"
  },
  "taskContractProposal" : null,
  "repositoryFactBinding" : null,
  "proposalDerivation" : null,
  "planArtifact" : null,
  "design" : null,
  "authoredRevisionResponses" : null,
  "authoredContext" : null
}
```

### Verified Previous Task Contract Proposal

- Proposal ID: node-intake-claude_brainstorm-002:3436838b90db0c6a
- Proposal SHA-256: 3436838b90db0c6a37bc33dd9168063f5a2c24bb8d390f170dedb50720fe2d0b

<!-- dual:typed-payload:start -->
```json
{
  "artifact_type" : "task_contract_proposal",
  "schema_version" : 3,
  "objective" : "交付一个 Java 25 + Spring Boot 4.1.0 本地 Web 应用：直连 OKX 官方公开行情 REST API 拉取 BTC-USDT 现货 1m K 线，经 MyBatis-Plus 幂等持久化到 SQLite，前端以本地打包图表库展示可定时刷新的真实蜡烛图与成交量，并以离线自动化测试加显式 live smoke 完成验证。",
  "scope" : {
    "included" : [ {
      "path" : ".gitignore",
      "operation" : "MODIFY"
    }, {
      "path" : "README.md",
      "operation" : "MODIFY"
    }, {
      "path" : "pom.xml",
      "operation" : "CREATE"
    }, {
      "path" : "scripts/live-smoke.sh",
      "operation" : "CREATE"
    }, {
      "path" : "scripts/verify-workspace.sh",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/com/example/okxkline/OkxKlineApplication.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/config/OkxSyncProperties.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/domain/Kline.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxMarketClient.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/CandleRowParser.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/entity/KlineEntity.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/mapper/KlineMapper.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/mapper/SyncStateMapper.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/KlineSyncService.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/SyncStateService.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/MarketController.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/GlobalExceptionHandler.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/application.yml",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/db/migration/V1__init_kline_schema.sql",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/index.html",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/app.js",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/styles.css",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/vendor/klinecharts.min.js",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/CandleRowParserTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/OkxMarketClientTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/SchedulerOverlapTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/persistence/KlinePersistenceTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/MarketControllerTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/ChartPageDomTest.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/support/StubOkxServer.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/smoke/OkxLiveSmokeIT.java",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-normal.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-reversed.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-unconfirmed.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-malformed-row.json",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/envelope-error.json",
      "operation" : "CREATE"
    } ],
    "excluded" : [ "REQUIREMENT.md（需求权威来源，保持原样不改）", ".git/**、.agent/** 以及有效工作区之外的任何路径", "任何 WebSocket 行情、交易、账户或私有 OKX API 相关代码", "运行时 CDN 资源或任何外链前端依赖" ]
  },
  "acceptance_criteria" : [ {
    "id" : "AC-1",
    "text" : "在 Java 25 环境下于仓库根目录执行 `mvn test` 全部通过，且测试运行期间不向公网 OKX（www.okx.com 等）发起任何网络请求。"
  }, {
    "id" : "AC-2",
    "text" : "默认配置（同步开启）启动应用后：启动即回填调用 `GET {okx.base-url}/api/v5/market/candles?instId=BTC-USDT&bar=1m` 拉取并保存最近 300 根 K 线，随后默认每 15 秒轮询一次；OKX base URL、连接/读取超时、调度开关与刷新周期均可经 application.yml 或环境变量外部配置；全程不需要 API Key 或 OKX 账户。"
  }, {
    "id" : "AC-3",
    "text" : "`GET /api/klines?limit=N` 按开盘时间升序返回最近最多 300 根已保存 K 线；limit 缺省时使用默认值，非法值（非正整数或超过 300）返回 400 与明确的客户端错误信息。"
  }, {
    "id" : "AC-4",
    "text" : "`GET /api/sync/health` 返回当前生命周期状态（如 ok/degraded）、最近一次尝试时间、最近一次成功时间和有界且脱敏的失败摘要；失败摘要文本仅是展示元数据，不反向决定状态机取值。"
  }, {
    "id" : "AC-5",
    "text" : "SQLite 表对 (instrument, bar, open_time) 建立唯一约束；重复同步幂等；confirm=0 的未闭合 K 线在后续轮次原位更新（含闭合为 confirm=1 后的最新值）；应用重启后已闭合 K 线仍可经 API 查询；价格与成交量在 Java 侧为 BigDecimal、SQLite 侧为 TEXT 等 decimal-safe 表示。"
  }, {
    "id" : "AC-6",
    "text" : "对超时、非 2xx、429 限流、OKX 业务错误（code 不为 \"0\"）、非法 JSON、非法行以及乱序/陈旧响应：本地已保存 K 线一律不删除不回退；envelope 或任一行校验失败时该轮整体不写入并置 degraded；失败后无无界立即重试，等待下一轮调度；单实例内不出现重叠调度执行。"
  }, {
    "id" : "AC-7",
    "text" : "浏览器访问首页即进入行情界面（非营销落地页）：以本地打包的 KLineCharts 资源渲染真实蜡烛图与成交量，展示 BTC / USDT、1m、最新收盘价、最近闭合 K 线时间、同步状态和最近成功刷新时间；默认每 10 秒增量刷新且不整页重载；同步 degraded 或后端失败时保留最后可用图表并显示克制清晰的状态；首次加载与无数据状态有明确提示；桌面和移动视口下文字、图表、操作不重叠；页面网络请求仅指向本应用后端，无模拟价格冒充 OKX 实时行情，无运行时 CDN 依赖。"
  }, {
    "id" : "AC-8",
    "text" : "README.md 完整记录架构、配置项（OKX base URL、超时、调度开关、刷新周期、SQLite 路径）、启动方式、`mvn test` 的离线性、live smoke 命令、后端 API 契约、数据新鲜度语义（confirm=0/1 含义、最新收盘价可能滞后于 OKX 实时）与已知限制。"
  }, {
    "id" : "AC-9",
    "text" : "`scripts/live-smoke.sh` 为显式 opt-in 命令，直连 OKX 官方公开接口发起一次只读请求并校验至少一根结构合法（9 字段、confirm 取值 0/1）的 BTC-USDT 1m K 线；该命令不在默认 `mvn test` 中执行。"
  }, {
    "id" : "AC-10",
    "text" : "交付后 `scripts/verify-workspace.sh` 的断言与实现状态一致：改为校验 pom.xml 与 src 存在、保留 Java 25 校验与只读 OKX 探测，不再因基线断言 `test ! -e pom.xml`、`test ! -d src` 而必然失败。"
  } ],
  "test_requirements" : [ {
    "id" : "TR-1",
    "text" : "OkxMarketClientTest 与 KlineSyncServiceTest 使用本地契约一致的 HTTP stub（StubOkxServer）与冻结 fixture 覆盖：正常 envelope、倒序行输入、重复同步幂等、未闭合 K 线 confirm=0 到 1 的原位更新、陈旧/旧缓存响应不删除较新本地数据、非法 envelope（code 非 \"0\"）、非法行（字段数/类型/confirm 非法）、HTTP 超时（不回包 socket policy）、非 2xx、429、非法 JSON；断言每轮合法 K 线在单事务内原子 upsert（失败轮零写入）、失败进入 degraded 且无立即重试、已有数据保留。"
  }, {
    "id" : "TR-2",
    "text" : "KlinePersistenceTest 使用临时 SQLite 文件数据库：验证 (instrument, bar, open_time) 唯一约束生效、upsert 幂等、以及模拟重启（新建 ApplicationContext 复用同一数据库文件）后已闭合 K 线仍可查询。"
  }, {
    "id" : "TR-3",
    "text" : "MarketControllerTest 覆盖后端 API：K 线按 open_time 升序与最多 300 条上限、limit 默认值与非法值返回 400、/api/sync/health 字段完整性、同步失败后 K 线接口仍返回既有数据。"
  }, {
    "id" : "TR-4",
    "text" : "SchedulerOverlapTest 以响应时长超过轮询周期的慢速 stub 验证同一时刻仅有一个同步执行（fixedDelay 调度加单线程执行器加显式并发守卫），不出现重叠。"
  }, {
    "id" : "TR-5",
    "text" : "CandleRowParserTest 验证 `[ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]` 行格式解析与校验规则、BigDecimal decimal-safe 转换、ts 为 Unix 毫秒开盘时间与 confirm 0/1 语义。"
  }, {
    "id" : "TR-6",
    "text" : "ChartPageDomTest 以浏览器级验证（Playwright for Java，仅测试期依赖）加载将 OKX 指向本地 stub 的应用实例：断言图表 DOM/canvas 渲染消费本应用 /api 数据、默认 10 秒定时刷新不触发整页导航、页面全部网络请求仅命中本应用源（无 okx.com 与任何 CDN 请求）。"
  }, {
    "id" : "TR-7",
    "text" : "OkxLiveSmokeIT 仅经 `-Plive-smoke` Maven profile 激活（由 scripts/live-smoke.sh 调用），直连 OKX 官方公开接口只读一次并校验至少一根结构合法的 BTC-USDT 1m K 线；默认 surefire/test 配置显式排除该测试，保证其不进入默认 `mvn test`。"
  }, {
    "id" : "TR-8",
    "text" : "全部自动化测试仅使用本地 stub 与仓库内冻结 fixture，不含任何对公网 OKX 的调用，可在无外网环境通过；Playwright 浏览器二进制经构建期获取或预置本地路径并在 README 记录获取方式，不构成应用运行时 CDN 依赖。"
  } ],
  "constraints" : [ {
    "id" : "C-1",
    "text" : "技术栈锁定：Java 25、Spring Boot 4.1.0、Maven、MyBatis-Plus 3.5.17 且必须引入 `mybatis-plus-spring-boot4-starter`；禁止 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施；SQLite 是唯一应用数据库。"
  }, {
    "id" : "C-2",
    "text" : "数据源锁定：仅 OKX 官方公开 Market Data REST `GET /api/v5/market/candles`（instId 固定 BTC-USDT 现货、bar 固定 1m），不得抓取 HTML 页面；生产运行与显式 live smoke 必须直连 OKX 官方 API，不得经测试桩、代理业务服务或抓取服务替代。"
  }, {
    "id" : "C-3",
    "text" : "OKX base URL、连接超时、读取超时、同步调度开关与刷新周期必须支持外部配置（application.yml 加环境变量覆盖）；默认每 15 秒轮询、启动回填最近 300 根、无需 API Key。"
  }, {
    "id" : "C-4",
    "text" : "数据库初始化采用版本化迁移脚本（src/main/resources/db/migration/V1__init_kline_schema.sql，经 Flyway 确定执行），禁止在业务代码中临时拼接建表流程；schema 含 (instrument, bar, open_time) 唯一约束与同步状态表。"
  }, {
    "id" : "C-5",
    "text" : "decimal-safe：Java 侧价格与成交量一律使用 BigDecimal，SQLite 侧以 TEXT 存储十进制字符串，禁止以 float/double 或 SQLite REAL 作为权威值。"
  }, {
    "id" : "C-6",
    "text" : "同步引擎语义：每轮先完整解析并校验 OKX envelope 再写库；同一响应中的合法 K 线在单事务内 upsert；任何失败（超时、非 2xx、业务错误、限流、非法 JSON、非法行、数据库异常）不得删除已有 K 线、不得无界立即重试，置 degraded 等待下一轮；单应用实例内调度不重叠；同步状态由显式生命周期字段管理，错误文本仅为有界摘要。"
  }, {
    "id" : "C-7",
    "text" : "日志只记录必要运行元数据（状态、耗时、行数、错误类别），失败时不得打印完整 OKX 响应正文。"
  }, {
    "id" : "C-8",
    "text" : "前端使用成熟 K 线图表库（KLineCharts）并将生产资源随应用打包到 src/main/resources/static/vendor，运行时零 CDN 零外链；浏览器只调用本应用后端 API，不直接请求 OKX。"
  }, {
    "id" : "C-9",
    "text" : "默认 `mvn test` 不得依赖公网 OKX 可用性，外部行为差异一律以本地契约一致 stub 与冻结 fixture 呈现；live smoke 仅经显式 opt-in 命令执行且不得进入默认测试。"
  }, {
    "id" : "C-10",
    "text" : "所有仓库改动仅限 scope.included 声明的文件，不写 .git、.agent 或工作区外路径。"
  } ],
  "non_goals" : [ {
    "id" : "NG-1",
    "text" : "交易、账户访问、认证、API Key、余额或任何私有 OKX API。"
  }, {
    "id" : "NG-2",
    "text" : "投资建议、告警、策略、技术指标或预测。"
  }, {
    "id" : "NG-3",
    "text" : "WebSocket 行情。"
  }, {
    "id" : "NG-4",
    "text" : "多交易品种或多周期切换（仅 BTC-USDT 1m）。"
  }, {
    "id" : "NG-5",
    "text" : "分布式调度或多实例协调（仅保证单实例内不重叠）。"
  }, {
    "id" : "NG-6",
    "text" : "用户账户或管理后台。"
  }, {
    "id" : "NG-7",
    "text" : "通用交易所抽象或行情平台化。"
  }, {
    "id" : "NG-8",
    "text" : "运行时 CDN 依赖。"
  } ],
  "risk_areas" : [ {
    "id" : "R-1",
    "text" : "Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的兼容矩阵需在实现首日经依赖解析与最小上下文测试验证；若存在装配缺口，需在约束不变前提下调整启动装配方式。"
  }, {
    "id" : "R-2",
    "text" : "Playwright for Java 需要构建期浏览器二进制；若构建环境禁外网，需按 TR-8 以预置本地二进制路径解决，否则 DOM 级验证无法执行。"
  }, {
    "id" : "R-3",
    "text" : "live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 `mvn test`。"
  }, {
    "id" : "R-4",
    "text" : "SQLite 单写者特性下调度写事务与 API 读并发可能遇到 BUSY；以短事务、单连接池与 WAL 模式缓解，需在实现中确认。"
  }, {
    "id" : "R-5",
    "text" : "vendored KLineCharts 版本需固定并在 README 记录，避免后续无意识升级引入行为漂移。"
  } ],
  "evidence_refs" : [ "REQUIREMENT.md", "README.md", "scripts/verify-workspace.sh", ".gitignore" ],
  "open_questions" : [ ],
  "revision_responses" : [ ]
}
```
<!-- dual:typed-payload:end -->

- .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-codex_product_review-004-run-1789168979272/binding.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789168979272/outputs/intake-codex-product-review.contract.json
  (validated typed evidence already projected)

- .agent/workstreams/ws-20260911T231749Z-GCTW/context/agent-governance-node-intake-claude_brainstorm-006-run-1789169034881.md

```text
# Agent Run Governance Context

- Workstream: ws-20260911T231749Z-GCTW
- Target Node: intake.claude_brainstorm
- Agent Node Instance: node-intake-claude_brainstorm-006
- Run Id: run-1789169034881
- Generated At: 2026-09-11T23:23:54.909869Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789169034881/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789169034881/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789169034881/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-006-run-1789169034881/binding.json

- Tracked inventory: count=4; head=c84807946493a603c789ee40c6a4c615aa846c3b; sha256=df80ed33104a28c6285358790cf77533328b089bd62e5a10379e37ec6e9f9298

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - REQUIREMENT.md
  - scripts/verify-workspace.sh
- Expected edit files: (none planned)
```

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_PRODUCT_REVIEW]



Return only `task_contract_revision_patch`; do not return or copy a full proposal. The patch is bound to base proposal id `node-intake-claude_brainstorm-002:3436838b90db0c6a` and sha256 `3436838b90db0c6a37bc33dd9168063f5a2c24bb8d390f170dedb50720fe2d0b`. Cover each authoritative routed obligation exactly once. Preserve its id and implement its text: [{"id":"CO-1","text":"修订 AC-6，明确乱序及陈旧响应不得删除本地较新时间戳的 K 线；不得将价格或成交量数值单调作为更新条件，须保持 AC-5 的未闭合 K 线合法原位更新。若拟增加同一开盘时间的响应新旧判定规则，须说明可用证据及规则，不能假设接口提供未声明的版本信息。"},{"id":"CO-2","text":"在 test_requirements 中增加首次回填测试：使用本地契约一致 HTTP stub、冻结的 300 根数据及临时 SQLite，启动同步开启的应用，验证启动触发请求并持久化最近 300 根，而非仅直接调用同步方法。可在已授权的 src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java 和 src/test/resources/fixtures/okx/candles-normal.json 中实现，无需扩大路径授权。"}]. Only clause ADD/REPLACE, exact scope ADD, and evidence-ref ADD are supported. No DELETE, section move, scope removal, objective/open-question change, JSON Pointer, or arbitrary field patch is allowed. `scope_additions` uses exact repository-relative paths. Each scope path must name one exact file, not a directory; it must be repository-relative, must not end with `/`, and must already be canonical (no `./`, `..`, repeated separators, backslashes, leading/trailing whitespace, `.git`, or `.agent` segments). Dual derives CREATE/MODIFY from the effective worktree. `section` is authoritative; clause IDs are opaque and their prefixes do not determine section. Across the entire `result.obligation_patches` array, each `clause_changes[].id`, `scope_additions[].path`, and `evidence_ref_additions[]` target must appear at most once. When one evidence ref supports multiple obligations, add it in one most relevant patch only; use each obligation's `resolved_by_clause_ids` to express coverage instead of adding the ref again. Each `result.obligation_patches` item is a closed object with exactly these fields: [review_obligation_id, resolved_by_clause_ids, clause_changes, scope_additions, evidence_ref_additions]. No other keys are permitted.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20260911T231749Z-GCTW",
  "run_id" : "run-1789169034881",
  "node_id" : "intake.claude_brainstorm",
  "result" : {
    "artifact_type" : "task_contract_revision_patch",
    "decision" : "READY_FOR_PRODUCT_REVIEW",
    "summary" : "one short sentence",
    "base_proposal_id" : "node-intake-claude_brainstorm-002:3436838b90db0c6a",
    "base_proposal_sha256" : "3436838b90db0c6a37bc33dd9168063f5a2c24bb8d390f170dedb50720fe2d0b",
    "obligation_patches" : [ {
      "review_obligation_id" : "CO-1",
      "resolved_by_clause_ids" : [ "AC-1" ],
      "clause_changes" : [ {
        "operation" : "REPLACE",
        "section" : "ACCEPTANCE_CRITERIA",
        "id" : "AC-1",
        "text" : "replacement text"
      } ],
      "scope_additions" : [ {
        "path" : "repo/relative/new.ext"
      } ],
      "evidence_ref_additions" : [ "repo/relative/evidence.ext" ]
    } ]
  }
}
