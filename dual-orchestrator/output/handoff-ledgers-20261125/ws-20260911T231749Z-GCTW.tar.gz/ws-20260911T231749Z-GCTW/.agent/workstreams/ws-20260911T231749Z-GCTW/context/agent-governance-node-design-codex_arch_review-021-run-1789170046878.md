# Agent Run Governance Context

- Workstream: ws-20260911T231749Z-GCTW
- Target Node: design.codex_arch_review
- Agent Node Instance: node-design-codex_arch_review-021
- Run Id: run-1789170046878
- Generated At: 2026-09-11T23:40:46.894055Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-codex_arch_review-021-run-1789170046878/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-codex_arch_review-021-run-1789170046878/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-codex_arch_review-021-run-1789170046878/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-codex_arch_review-021-run-1789170046878/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - pom.xml
  - scripts/live-smoke.sh
- Expected edit files: (none planned)
