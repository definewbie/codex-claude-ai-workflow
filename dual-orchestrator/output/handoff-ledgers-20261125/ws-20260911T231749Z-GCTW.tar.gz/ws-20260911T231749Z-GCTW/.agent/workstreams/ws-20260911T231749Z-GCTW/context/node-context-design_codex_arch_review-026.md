# Context Package

- Workstream: ws-20260911T231749Z-GCTW
- Builder Node: context.design_codex_arch_review
- Target Node: design.codex_arch_review
- Generated At: 2026-09-11T23:50:44.902457Z
- Profile: architecture_review
- Total: 6.6k / 5.0k tokens

## Context Governance

| Section | Level | Degraded | Original | Current |
|---|---|---|---|---|
| input_artifacts | full | no | 523 | 523 |
| review_evidence | full | no | 181 | 181 |
| human_feedback | full | no | 302 | 302 |
| iteration_history | full | no | 329 | 329 |
| recent_agent_outputs | full | no | 365 | 365 |
| ledger_pointers | pointer_only | yes | 170 | 161 |
| required_architecture_review_subject | full | no | 4.8k | 4.8k |

Degraded sections have full data at their original paths listed below.

## State & Evidence Boundary

This package separates deterministic harness facts from agent proposals.

### Trusted Harness Facts

- TaskContract: READY_FOR_REVIEW - 交付一个 Java 25 + Spring Boot 4.1.0 本地 Web 应用：直连 OKX 官方公开行情 REST API 拉取 BTC-USDT 现货 1m K 线，经 MyBatis-Plus 幂等持久化到 SQLite，前端以本地打包图表库展示可定时刷新的真实蜡烛图与成交量，并以离线自动化测试加显式 live smoke 完成验证。 (.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/task-contract.json)
- Git Evidence: not generated yet

### Human Decisions

- Requirement Resolution: APPROVE by human_gate (.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/contract-resolution.json)

### Agent Proposed States

- design.claude_design: decision=READY_FOR_ARCH_REVIEW, stageOutcome=READY, evidenceState={blocking=false, evidence_count=21, missing_evidence_count=0, must_fix_count=0, acceptance_note_count=0, open_risk_count=5} (/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.contract.json)

### Pending Contract/Evidence Gaps

- No contract failure diagnostics recorded

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Repo map: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-026/repo-map.json
- Repository fact binding: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-026/binding.json
- Tracked inventory: count=0; head=; sha256=

- File relevance plan: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-026/file-relevance-plan.json
- Stage scope policy: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-026/stage-scope-policy.json
- Workstream memory: .agent/workstreams/ws-20260911T231749Z-GCTW/memory/workstream-memory.json
- Working set: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-026/working-set.json
- File summaries: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-026/file-summaries.json
- Read reuse contract: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-026/read-reuse-contract.json
- Agent capability catalog: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-026/agent-capability-catalog.json
- Governance report: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-026/planned-report.json

- Recommended read files:
  - .gitignore
  - README.md
  - pom.xml
  - scripts/live-smoke.sh
  - scripts/verify-workspace.sh
  - src/main/java/com/example/okxkline/OkxKlineApplication.java
  - src/main/java/com/example/okxkline/config/OkxSyncProperties.java
  - src/main/java/com/example/okxkline/domain/Kline.java
- Contract scope candidates:
  - .gitignore
  - README.md
  - pom.xml
  - scripts/live-smoke.sh
  - scripts/verify-workspace.sh
  - src/main/java/com/example/okxkline/OkxKlineApplication.java
  - src/main/java/com/example/okxkline/config/OkxSyncProperties.java
  - src/main/java/com/example/okxkline/domain/Kline.java
  - src/main/java/com/example/okxkline/okx/OkxMarketClient.java
  - src/main/java/com/example/okxkline/okx/CandleRowParser.java
  - src/main/java/com/example/okxkline/entity/KlineEntity.java
  - src/main/java/com/example/okxkline/mapper/KlineMapper.java
- Allowed write files: (none planned)
- Forbidden scope:
  - .git/**
  - .agent/workstreams/**/workflow/**
  - .agent/workstreams/**/nodes/**
  - business source writes
- Already inspected files:
  - .gitignore
  - README.md
  - REQUIREMENT.md
  - scripts/verify-workspace.sh
  - {pom.xml,scripts/*,REQUIREMENT.md,src/**}
  - *
  - scripts/*
- Read reuse contract: the following files were already inspected and their recorded sha is still trusted. Reuse the summary first; re-read only if you need exact current contents for editing or verification.
  - .gitignore: Previously read source file (105 bytes).
  - README.md: headings: OKX BTC K 线演示应用 | relevant: 产品需求以 `REQUIREMENT.md` 为权威来源。实现必须由唯一 fresh workstream 完成，并严格使用 Java 25、Spring Boot 4.1.0、MyBatis-Plus 3.5.17 和 SQLite。; 冻结基线中没有产品代码或构建文件。生产应用与显式 live smoke 必须直接调用 OKX 官方公开 API；只有确定性自动化测试可以使用本地协议桩模拟超时、限流、乱序和畸形响应。
  - REQUIREMENT.md: headings: OKX BTC 分钟级 K 线 Web 应用需求; 目标; 强制技术栈; OKX 行情契约; 数据持久化 | relevant: 构建一个本地 Web 应用，通过 OKX 官方公开行情 REST API 获取 BTC-USDT 现货分钟级 K 线，将数据持久化到 SQLite，并展示可定时刷新的 K 线图。; 提供稳定 JSON API：; 1. 查询最近最多 300 根已保存 K 线，按开盘时间升序返回。; 非法 limit 必须返回明确的客户端错误。浏览器只能调用本应用后端，不得直接请求 OKX。
  - scripts/verify-workspace.sh: Previously read source file (1255 bytes).
  Do not re-read these files unless this stage needs exact current contents; this target artifact does not declare a reread reason field, so the harness will judge re-reads from changed_files, invalidation, and allowed-reread policy.
- Read reuse rule: use existing evidence before re-reading files already inspected in this workstream.
- Re-read a listed file only when this stage needs fresh contents; record the reason in the structured artifact.
- Repeated-read risk:
  - .gitignore (previous reads: 4, evidence known: false)
  - README.md (previous reads: 4, evidence known: false)
  - scripts/verify-workspace.sh (previous reads: 4, evidence known: false)
Read recommendations are context only. Declared edits must match TaskContract.scope and are verified from Git evidence.

## Input Artifacts

### .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.stderr.log

(execution diagnostic omitted from context)

### .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.transcript.log

(execution transcript omitted from context; inspect raw file at /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.transcript.log)

### .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.json

- Contract: design.claude_design
- Decision: READY_FOR_ARCH_REVIEW
- Summary: 按人工门禁指示完成 AR-1..AR-5 的完整替换设计：行情与成功状态单事务原子提交、启动禁用状态机、显式 API 与图表字段映射、固定分类安全摘要与诚实新鲜度语义，37 项 planned_files 路径与操作保持不变。
- Open Risks: Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的坐标解析与最小上下文装配需实现首日验证（含 Flyway SQLite 支持归属 flyway-core 还是附加模块）；如需附加坐标仅添加于已授权 pom.xml。; Hikari data-source-properties 传递 xerial pragma（journal_mode/busy_timeout）的键名绑定需首日验证；备选为 JDBC URL 参数或 yml 显式键，不影响语义。; Playwright for Java 浏览器二进制需构建期获取或预置本地路径（README 记录）；离线构建环境缺二进制时 ChartPageDomTest 无法执行，属环境准备项而非设计缺口。; live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 mvn test。; vendored klinecharts 9.8.0 的构建期获取与 timestamp 单位（秒）需实施首日对包内类型定义复核；ChartPageDomTest 的时间断言已使单位错误必然失败，若复核结论为毫秒仅调整 toChartTimestamp 单点函数，无契约变化。
- Verification: 本阶段仅产出实现就绪的完整替换设计：planned_files 与批准 scope 完全一致，AR-1..AR-5 已逐条落入设计与测试描述；未执行任何代码实现、构建或测试运行。
- Contract Sidecar: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.contract.json
- Raw Output: .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.json

### .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-claude_design-024-run-1789170184692/binding.json

(routed artifact has no typed context projection; content omitted)

## Review Evidence Brief

TaskContract projection: qualified_projection

No cumulative review verdict recorded. Review the complete current subject against the contract baseline.

- Relevant memory (reuse, do not re-read): .gitignore; README.md; REQUIREMENT.md; scripts/verify-workspace.sh

Derive the complete current blocker set from the review subject and acceptance criteria; re-read a file only with a reason (edit/verify/sha-changed/stage-gap).
Evidence: memory .agent/workstreams/ws-20260911T231749Z-GCTW/memory/workstream-memory.json; diff .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/git-evidence/diff.patch; changed .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/git-evidence/changed-files.txt.

## Human Feedback

### gate.human_design_approval

- Action: revise
- Finished At: 2026-09-11T23:43:04.382082Z

```text
接受AR-1至AR-5，保持当前批准TaskContract和37项路径不变，一次性同步checks/evidence/planned_files/测试描述。AR-1：删除每轮解析前recordAttempt写库；获锁后attemptAt仅在内存，HTTP获取及整个envelope和所有行校验完成后，在同一短事务内提交整批upsert与attempt/success/OK状态。失败回滚后再用独立短事务记录attempt/DEGRADED；状态写入本身失败时仅有界报告，不谎称持久化成功，finally释放守卫。补完整故障断言。AR-2：明确SyncStateService的启动enabled/disabled转换，保留历史时间，禁用零请求，覆盖禁用/重启/重新启用。AR-3：统一实际JSON字段与图表OHLCV映射，依据固定图表版本的真实接口确定timestamp单位，不臆测毫秒转秒；浏览器测试核对真实API数据、图表实际数据与刷新，不以canvas存在替代。AR-4：错误摘要使用固定分类与受控字段，不透传或仅截断外部msg；覆盖控制字符与敏感样式响应。AR-5：删除最多滞后一轮的承诺，分别展示行情时间与最近成功时间。其余已闭合的confirm更新规则、schema、scope保持不变，不新增框架、文件或平台。
```

### gate.contract_review

- Action: approved
- Finished At: 2026-09-11T23:31:02.499156Z

```text
已机械比对编译合同与本轮已批准提案的objective、scope、acceptance_criteria、test_requirements、constraints、non_goals、evidence_refs全等，合同与resolution SHA均匹配compile来源。批准该合同进入设计；后续设计、计划与实际修改须保持当前批准身份，测试和验收仍独立进行。
```

### gate.human_requirement_review

- Action: approved
- Finished At: 2026-09-11T23:29:29.799127Z

```text
已核对本轮完整提案、原REQUIREMENT与两轮修订来源，CO-1/CO-2已收敛，按当前提案身份批准进入合同编译。保持需求业务范围和37项文件授权；依赖兼容、浏览器和真实API仍须实际验证，本次不是实现或验收通过。不新增手机图标要求。
```

## Iteration History

### iter-004

- Parent: iter-003
- Trigger: revise
- Target Node: design.claude_design
- Created At: 2026-09-11T23:43:04.552715Z

```text
接受AR-1至AR-5，保持当前批准TaskContract和37项路径不变，一次性同步checks/evidence/planned_files/测试描述。AR-1：删除每轮解析前recordAttempt写库；获锁后attemptAt仅在内存，HTTP获取及整个envelope和所有行校验完成后，在同一短事务内提交整批upsert与attempt/success/OK状态。失败回滚后再用独立短事务记录attempt/DEGRADED；状态写入本身失败时仅有界报告，不谎称持久化成功，finally释放守卫。补完整故障断言。AR-2：明确SyncStateService的启动enabled/disabled转换，保留历史时间，禁用零请求，覆盖禁用/重启/重新启用。AR-3：统一实际JSON字段与图表OHLCV映射，依据固定图表版本的真实接口确定timestamp单位，不臆测毫秒转秒；浏览器测试核对真实API数据、图表实际数据与刷新，不以canvas存在替代。AR-4：错误摘要使用固定分类与受控字段，不透传或仅截断外部msg；覆盖控制字符与敏感样式响应。AR-5：删除最多滞后一轮的承诺，分别展示行情时间与最近成功时间。其余已闭合的confirm更新规则、schema、scope保持不变，不新增框架、文件或平台。
```

### iter-003

- Parent: iter-002
- Trigger: NEEDS_REVISION
- Target Node: intake.claude_brainstorm
- Created At: 2026-09-11T23:26:18.017993Z

```text
首次回填测试已补齐，但 AC-6 新增的闭合数据永久不可更新规则超出了已声明的行情契约。
```

### iter-002

- Parent: iter-001
- Trigger: NEEDS_REVISION
- Target Node: intake.claude_brainstorm
- Created At: 2026-09-11T23:23:54.859410Z

```text
提案总体覆盖产品目标，但需澄清陈旧响应语义并补齐首次回填的自动化验证要求。
```

### iter-001

- Parent: (none)
- Trigger: workflow_started
- Target Node: context.intake_claude_brainstorm
- Created At: 2026-09-11T23:17:49.404227Z

```text
Initial workflow iteration.
```

## Recent Agent Outputs

### /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.contract.json

- Contract: design.claude_design
- Decision: READY_FOR_ARCH_REVIEW
- Summary: 按人工门禁指示完成 AR-1..AR-5 的完整替换设计：行情与成功状态单事务原子提交、启动禁用状态机、显式 API 与图表字段映射、固定分类安全摘要与诚实新鲜度语义，37 项 planned_files 路径与操作保持不变。
- Open Risks: Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的坐标解析与最小上下文装配需实现首日验证（含 Flyway SQLite 支持归属 flyway-core 还是附加模块）；如需附加坐标仅添加于已授权 pom.xml。; Hikari data-source-properties 传递 xerial pragma（journal_mode/busy_timeout）的键名绑定需首日验证；备选为 JDBC URL 参数或 yml 显式键，不影响语义。; Playwright for Java 浏览器二进制需构建期获取或预置本地路径（README 记录）；离线构建环境缺二进制时 ChartPageDomTest 无法执行，属环境准备项而非设计缺口。; live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 mvn test。; vendored klinecharts 9.8.0 的构建期获取与 timestamp 单位（秒）需实施首日对包内类型定义复核；ChartPageDomTest 的时间断言已使单位错误必然失败，若复核结论为毫秒仅调整 toChartTimestamp 单点函数，无契约变化。
- Verification: 本阶段仅产出实现就绪的完整替换设计：planned_files 与批准 scope 完全一致，AR-1..AR-5 已逐条落入设计与测试描述；未执行任何代码实现、构建或测试运行。
- Contract Sidecar: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.contract.json
- Raw Output: .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.json

## Ledger Pointers

- Events: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/events.jsonl
- Workflow current: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/workflow/current.json
- Node state directory: /Users/kriswang/work/proj

[adaptively compressed; section degraded to stay within ~125 tokens; full source remains in ledger under /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW]

## Required Architecture Review Subject

- Contract: design.claude_design
- Decision: READY_FOR_ARCH_REVIEW
- Summary: 按人工门禁指示完成 AR-1..AR-5 的完整替换设计：行情与成功状态单事务原子提交、启动禁用状态机、显式 API 与图表字段映射、固定分类安全摘要与诚实新鲜度语义，37 项 planned_files 路径与操作保持不变。
**Checks:**
- 已重读已批准 TaskContract tc-ws-20260911T231749Z-GCTW-v1（human gate 016 APPROVE）、人工门禁 023 指示、REQUIREMENT.md 与基线仓库现状（root 仅 .gitignore/README.md/REQUIREMENT.md/scripts/verify-workspace.sh，无 pom.xml、无 src/）；planned_files 保持 37 项（3 MODIFY + 34 CREATE）路径与操作逐字一致，仅 responsibility 同步 AR 修订，无越权路径、无新增文件、框架或平台能力。
- AR-1..AR-5 与人工指示逐条落入设计（见 evidence 与 revision_responses）；先前已闭合结论保持不变：confirm 条件 upsert 语义、UNIQUE(instrument,bar,open_time) 约束、Flyway 版本化初始化、decimal-safe 链路、smoke 隔离。
- 生命周期-正常完成：成功轮 获取→完整校验 envelope 与全部行→唯一短事务内 逐行 upsert + markSuccess(attemptAt,successAt,OK,清空错误字段) 原子提交；/api/klines 与 /api/sync/health 即时反映已提交结果，不存在已提交行情但状态滞后的窗口。
- 生命周期-并发：fixedDelay（上次结束才计时）+ spring.task.scheduling.pool.size=1 + AtomicBoolean 在飞守卫三层防重叠；守卫在 try/finally 释放，覆盖全部分支（解析失败、事务回滚、失败记录自身 DB 异常）；启动回填与定时轮共用 syncOnce 同受守卫；Hikari maximum-pool-size=1 串行化 DB 访问；跨实例协调为契约非目标，不适用。
- 生命周期-超时/提供方失败：TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW/DATABASE 归一为该轮失败——解析期失败零写入；写库失败行情与 OK 状态同事务整体回滚；失败后以独立短事务记录 attempt+DEGRADED+受控摘要，该事务自身失败时仅有界报告（固定文本 WARN + 内存镜像 persisted=false），不外抛、不谎称已持久化；无立即重试，唯一恢复路径是下一轮调度；失败路径无 DELETE。
- 生命周期-中断/崩溃：未提交事务由 SQLite WAL/journal 回滚，库中不存在部分轮次；崩溃至多丢失当轮（含其状态记录），sync_state 保持最后一次已入账轮次；对 OKX 仅只读 GET，无外部写副作用，补偿不适用。
- 生命周期-重启/恢复：Flyway 迁移幂等跳过；启动回填重跑为幂等 upsert；sync_state 读取最后持久化行（内存镜像不跨重启，不会出现未持久化的内存值）；已闭合 K 线跨重启可查（KlinePersistenceTest 同一文件新建上下文验证）；状态写失败后的重启读取有专用故障测试。
- 生命周期-回滚/冲突：行键冲突是 ON CONFLICT 正常路径而非错误；唯一约束兜底并以直插重复键用例证明不可绕过；成功事务中途注入失败整轮回滚、行情零写入且状态不为 OK，有注入式 mapper 代理测试。
- cannot-bypass 测试映射：调度不重叠（SchedulerOverlapTest 并发峰值=1）；任何失败不删除数据（KlineSyncServiceTest 失败矩阵断言行数不减）；confirm 1→0 不可回退不可覆盖；非法 limit 返回 400（MarketControllerTest）；浏览器零出站、零 CDN 且图表真实消费本应用后端数据（ChartPageDomTest）；禁用期间零 OKX 请求（KlineSyncServiceTest 新增，stub 请求计数=0）；live smoke 不进默认 mvn test（surefire 排除 + 独立脚本）。
- 不适用边界声明：缓存（未引入，本地毫秒级读无缓存）、异步队列（无）、分布式锁/多实例协调（契约非目标）、对外系统写副作用补偿（OKX 仅只读 GET）；未新增重试框架、内存缓存或额外线程池，失败后唯一恢复路径为下一轮调度。
- 前后端契约一致性：KlineResponse 显式字段 = app.js 映射输入 = ChartPageDomTest 断言字段，三者同名对齐；图表版本锁定 klinecharts 9.8.0，timestamp 单位有依据来源（包内类型定义首日复核）并有可执行强制（DOM 时间断言），不依赖臆测。
- 测试离线性由构造保证：自动化测试仅连本地 StubOkxServer 与冻结 fixture，默认 surefire 排除 **/smoke/**；生产 base-url 仅在显式 live smoke 中使用。

**Evidence:**
- 架构分层：okx 层（OkxMarketClient+CandleRowParser：HTTP+envelope+行校验）→ sync 层（KlineSyncService 调度/守卫/事务编排 + SyncStateService 状态机与安全摘要 owner）→ mapper 层（MyBatis-Plus 唯一持久化通道）→ web 层（MarketController 显式 DTO + GlobalExceptionHandler + 同源静态前端）；浏览器仅访问本应用，唯一出站流量是服务端到 OKX 的只读 GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300。
- AR-1 事务边界（核心修订）：syncOnce 获守卫后 attemptAt 仅存内存、不预写库；HTTP 获取与 envelope/全部行校验完成（零 DB 写）后，成功路径在唯一短事务内先逐行 upsert 再 markSuccess(attemptAt, successAt, state=OK, 错误字段置 NULL) 原子提交——行情与 OK 状态同进同退，recordSuccess-after-commit 失败模式在结构上不存在；该事务不含 HTTP 调用；事务任何失败即整轮回滚（行情零写入且状态不为 OK），进入失败路径并归类 DATABASE。
- AR-1 失败路径与状态写失败：失败路径以独立短事务 markFailure(attemptAt, state=DEGRADED, category, 受控摘要)（last_success_at 不动）；该事务自身抛错时的有界处理：仅输出一条固定文本 WARN（STATE_WRITE_FAILED + 分类 + 异常类名，绝不声称已持久化 DEGRADED、绝不含 OKX 正文），并更新易失内存镜像（persisted=false）；异常不外抛；守卫在 finally 释放，不阻塞下一轮调度。
- AR-1 健康接口结果定义：healthView 合并规则——DB 行可读且 last_attempt_at 不旧于内存镜像时返回持久化行视图（statePersisted=true）；内存镜像较新（失败记录未持久化）时返回内存视图（state=DEGRADED，statePersisted=false，lastSuccessAt 取镜像保留值）；DB 行读取失败且有镜像→内存视图（persisted=false），无镜像→503 有界错误 SYNC_STATE_UNAVAILABLE；重启后镜像为空，持久化行即权威；崩溃场景下 last_attempt_at 语义为『最近一次已入账的尝试』（README 记录）。
- AR-2 启动状态转换：SyncStateService 拥有 ApplicationReadyEvent（排序先于回填入口）上的 applyStartupMode——enabled=false 时短事务仅将 state 列置为 DISABLED（last_attempt_at/last_success_at/last_error_* 历史全部保留；种子 PENDING 不再以 PENDING 示人，旧 OK 也不再在禁用时继续显示）；enabled=true 且持久化状态为 DISABLED 时置为 PENDING（重新启用不沿用旧 DISABLED），随后回填首轮翻为 OK/DEGRADED；两个同步入口在 enabled=false 时直接返回，零 OKX 请求、零状态写。
- AR-3 API 契约统一：MarketController 不再直接序列化 domain Kline，改为显式嵌套 KlineResponse record：openTime(long 毫秒)、open/high/low/close/volume/volumeCcy/volumeCcyQuote（Jackson WRITE_BIGDECIMAL_AS_PLAIN 输出 plain 数值）、confirmed(boolean)；/api/sync/health 返回 state/lastAttemptAt/lastSuccessAt/lastErrorCategory/lastErrorSummary/statePersisted；字段名即前后端契约，MarketControllerTest 逐字段断言。
- AR-3 前端映射与 timestamp 单位：锁定 klinecharts 9.8.0 UMD（vendored 本地打包，README 记录版本与获取方式）；app.js 单点适配 toChartData：{timestamp:toChartTimestamp(openTime), open, high, low, close, volume}，VOL 内置指标消费 volume；klinecharts 9.x KLineData.timestamp 单位为秒，toChartTimestamp=Math.floor(openTime/1000)——该单位依据 vendored 包内类型定义于实施首日复核，并以 ChartPageDomTest 的时间断言强制执行（单位错误必然渲染 1970 年代坐标而失败）；若复核结论为毫秒，仅删除该单点转换，无任何契约变化。
- AR-3 DOM 级验证：ChartPageDomTest（Playwright+随机端口应用+stub OKX+冻结 fixture）：捕获真实 /api/klines 响应 JSON；悬停图表触发内置 tooltip，断言文本包含最新一根 K 线的时间串（期望串在页内以同一 openTime 计算，规避时区偏差）、开/高/低/收与成交量数值串与 fixture 一致；等待第二个 /api/klines 请求（默认 10 秒周期）期间 stub 更新数据，断言无主框架导航、图表与头部最新价随之更新；断言全部网络请求仅命中本应用源（无 okx.com、无 stub 直连、无 CDN）；降级场景页面保留旧图且不出现 stub 原文。
- AR-4 安全摘要：失败分类固定枚举 TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW/DATABASE/STATE_WRITE_FAILED；摘要仅由分类固定中文标签与受控数字片段组成——HTTP 状态码（整数）、OKX envelope code（仅当整体匹配 ^[0-9]{1,10}$ 才输出 code=数字），外部 msg 一律不进入摘要；写 sync_state、渲染 health JSON、输出日志三个 sink 统一 sanitize：剔除 C0/C1 控制字符（U+0000-U+001F、U+007F-U+009F）与零宽/BIDI 字符、截断至 ≤200 字符；OkxMarketClient 异常消息本身即该受控摘要。
- AR-4 测试：envelope-error fixture 与 stub 内联正文构造 msg 含 U+0000、ANSI 转义（U+001B[31m）、HTML 片段、超长文本及非数字 code 的响应；断言异常消息、健康 JSON、页面 DOM 文本与日志 appender 均只出现期望组合摘要，不含任何原始 msg 片段、控制字符或 HTML。
- AR-5 新鲜度语义：README 与前端删除『最多滞后一个轮询周期』表述；明确最近成功同步时间 ≠ 行情最新时间、confirm=0 行仍会变化、OKX 陈旧缓存与连续失败可使滞后超过一个轮询周期且无固定上界、恢复取决于下一次成功调度；页面分列展示 行情时间（最新收盘价对应 K 线与最近闭合 K 线时间，取自数据本身）与 最近成功刷新时间（同步状态区），degraded 文案为『数据可能滞后，最后成功同步于…』。
- AC-6 upsert 语义不变：KlineMapper 单条 upsert SQL：INSERT ... ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 行情字段=excluded.对应字段、confirm=excluded.confirm、updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0——0→0/0→1/1→1 均取最近一次成功校验响应值，1→0 因 WHERE 不触发整行保持原状；全链路无 DELETE；新旧判定只用行内 confirm，不读价格大小/方向，本地较新行因不在冲突键内原样保留。
- 解析先于写入：每轮先校验 HTTP 2xx、JSON 合法、code=='0'、data 为数组与全部 9 字段行（任一非法整轮拒绝零写入），随后才进入写事务；CandleRowParser 仅做格式校验，明确不做价格大小/方向等行情语义校验。
- 调度与并发：@Scheduled(fixedDelayString 与 initialDelayString 均取 okx.sync.fixed-delay，默认 15s）+ 单线程调度器 + AtomicBoolean 守卫三层防重叠；SchedulerOverlapTest 以 fixed-delay 约 1s + stub 响应约 5s 断言并发峰值=1、请求串行，并以两线程并发调 syncOnce 验证守卫跳过（含状态写失败分支后守卫仍释放）。
- 状态机与持久化 schema：sync_state 单行（V1 迁移种子 id=1 PENDING），state CHECK IN (PENDING,OK,DEGRADED,DISABLED)；状态仅由轮次结果分类枚举与启动转换驱动，错误文本只是 ≤200 字符有界展示元数据，绝不参与状态判定；Flyway V1 是唯一且版本化的建表入口，业务代码零 DDL。
- decimal-safe 链路：OKX 十进制字符串 → BigDecimal（parser）→ KlineEntity String(toPlainString) → SQLite TEXT → 读取经 BigDecimal 构造 → API 以 Jackson WRITE_BIGDECIMAL_AS_PLAIN 输出 JSON 数值；全程无 float/double/REAL；实体以 String 承载 TEXT 列规避 xerial ResultSet.getBigDecimal 对 TEXT 列的不确定行为，且不引入未授权 TypeHandler 文件。
- SQLite 并发与配置：Hikari maximum-pool-size=1 串行化读写 + WAL + busy_timeout=5000 + 短事务，缓解单写者 BUSY；OKX base URL、连接/读取超时、okx.sync.enabled、fixed-delay 全部经 @ConfigurationProperties(okx.sync) 外部可配置。
- 测试矩阵映射：TR-1→OkxMarketClientTest+KlineSyncServiceTest；TR-2→KlinePersistenceTest；TR-3→MarketControllerTest；TR-4→SchedulerOverlapTest；TR-5→CandleRowParserTest；TR-6→ChartPageDomTest；TR-7→OkxLiveSmokeIT+-Plive-smoke+scripts/live-smoke.sh；TR-8→全量本地 stub+冻结 fixture；TR-9/TR-10→KlineSyncServiceTest 专用用例；429/非 2xx/非法 JSON/超时由 StubOkxServer 内联正文与挂起策略构造。
- 新增故障与状态用例（KlineSyncServiceTest）：成功事务第 N 行注入 mapper 失败→行情零写入、状态不为 OK、随后 DEGRADED/DATABASE 入账；SyncStateMapper UPDATE 注入失败→健康视图 state=DEGRADED 且 statePersisted=false、日志仅一条有界 WARN、守卫已释放（紧接手动 syncOnce 立即执行）；其后重启新上下文读同一 DB→健康为最后持久化行；enabled=false 首启（stub 计数=0、health=DISABLED）；成功一轮后禁用重启（历史时间保留、计数不增、health=DISABLED）；重新启用（不再显示 DISABLED、请求恢复增长）。
- smoke 隔离：默认 surefire 排除 **/smoke/**（叠加 *IT 命名双保险）；live-smoke profile 以 combine.self=override 清空排除并仅 include OkxLiveSmokeIT；OkxMarketClient 为构造式无 Spring 注解依赖，可被 smoke 直接 new 以直连 www.okx.com。
- 基线文件修改点（已核对现状）：verify-workspace.sh 仅将第 8-9 行 test ! -e pom.xml / test ! -d src 翻转为 test -f pom.xml / test -d src，保留 Java 25、清洁树与只读 OKX 探测；.gitignore 现有 *.db/*.db-shm/*.db-wal/*.sqlite/*.sqlite3，仅补 *.db-journal 与 data/；README 为基线占位文档，整体重写覆盖 REQUIREMENT 验证条目。

- Open Risks: Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的坐标解析与最小上下文装配需实现首日验证（含 Flyway SQLite 支持归属 flyway-core 还是附加模块）；如需附加坐标仅添加于已授权 pom.xml。; Hikari data-source-properties 传递 xerial pragma（journal_mode/busy_timeout）的键名绑定需首日验证；备选为 JDBC URL 参数或 yml 显式键，不影响语义。; Playwright for Java 浏览器二进制需构建期获取或预置本地路径（README 记录）；离线构建环境缺二进制时 ChartPageDomTest 无法执行，属环境准备项而非设计缺口。; live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 mvn test。; vendored klinecharts 9.8.0 的构建期获取与 timestamp 单位（秒）需实施首日对包内类型定义复核；ChartPageDomTest 的时间断言已使单位错误必然失败，若复核结论为毫秒仅调整 toChartTimestamp 单点函数，无契约变化。
- Verification: 本阶段仅产出实现就绪的完整替换设计：planned_files 与批准 scope 完全一致，AR-1..AR-5 已逐条落入设计与测试描述；未执行任何代码实现、构建或测试运行。
- Contract Sidecar: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.contract.json
- Raw Output: .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.json

### Declared Planned Files

- MODIFY `.gitignore`: 补充 SQLite 运行期产物忽略（*.db-journal、data/ 目录），与既有 *.db/*.db-wal/*.db-shm/*.sqlite/*.sqlite3 共同覆盖默认数据库文件及辅助文件。
- MODIFY `README.md`: 重写为交付文档：架构、配置表（okx.sync.* 与 OKX_KLINE_SQLITE_PATH 环境变量）、SQLite 默认路径、启动、离线 mvn test、live smoke 命令、API 契约（/api/klines 与 /api/sync/health 全字段，含 statePersisted 与 last_attempt_at 的『最近一次已入账尝试』语义）、数据新鲜度语义（最近成功同步时间≠行情最新时间；confirm=0 行可变；陈旧缓存与连续失败可致滞后超过一个轮询周期且无固定上界；闭合行可被后续合法响应修正）、klinecharts 9.8.0 版本与 timestamp 单位依据、已知限制；全文不出现『最多滞后一个轮询周期』表述。
- CREATE `pom.xml`: Spring Boot 4.1.0 parent + Java 25；依赖 spring-boot-starter-web、com.baomidou:mybatis-plus-spring-boot4-starter:3.5.17、org.flywaydb:flyway-core、org.xerial:sqlite-jdbc；测试依赖 spring-boot-starter-test 与 com.microsoft.playwright:playwright；surefire 默认排除 **/smoke/**，live-smoke profile 覆盖排除并仅执行 OkxLiveSmokeIT。
- CREATE `scripts/live-smoke.sh`: 显式 opt-in 包装：mvn -Plive-smoke test，仅触发直连 OKX 官方公开接口的只读 smoke，不进入默认测试。
- MODIFY `scripts/verify-workspace.sh`: 将基线断言 test ! -e pom.xml、test ! -d src 翻转为 test -f pom.xml、test -d src；保留 Java 25 校验、清洁树校验与只读 OKX 探测。
- CREATE `src/main/java/com/example/okxkline/OkxKlineApplication.java`: @SpringBootApplication 启动类 + @MapperScan(com.example.okxkline.mapper)；main 中仅为配置的 SQLite 路径创建父目录（初始化准备，不含任何建表逻辑）。
- CREATE `src/main/java/com/example/okxkline/config/OkxSyncProperties.java`: @ConfigurationProperties(okx.sync)：base-url、connect-timeout、read-timeout(Duration)、enabled、fixed-delay(Duration)，经宽松绑定支持环境变量覆盖；limit 固定常量 300，不配置化。
- CREATE `src/main/java/com/example/okxkline/domain/Kline.java`: 纯领域 record：instrument、bar、openTime(long 毫秒)、open/high/low/close/volume/volumeCcy/volumeCcyQuote(BigDecimal)、confirmed(boolean)；服务层与 API 的 decimal-safe 权威载体。
- CREATE `src/main/java/com/example/okxkline/okx/OkxMarketClient.java`: 构造式注入 OkxSyncProperties，基于 RestClient+JDK HttpClient 按 base-url/超时构建；GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300；校验 HTTP 状态与 envelope（code=='0'、data 数组）并委托 CandleRowParser；失败抛出带分类枚举（TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW）的 OkxCallException，异常消息即受控摘要（分类标签+可选数字片段，绝不包含外部 msg 或响应正文）；无 Spring 注解依赖，可被 live smoke 直接构造。
- CREATE `src/main/java/com/example/okxkline/okx/CandleRowParser.java`: 纯静态行解析器：校验 9 字段、数值可解析 BigDecimal、ts 为正整数毫秒、confirm∈{0,1}；仅做格式校验，明确不做价格大小/方向等行情语义校验；输出 domain Kline。
- CREATE `src/main/java/com/example/okxkline/entity/KlineEntity.java`: MyBatis-Plus @TableName(kline) 实体；价格/成交量以 String 承载 TEXT 列（存储编码），confirm 为 Integer 0/1，openTime 为 Long；提供与 domain Kline 的双向转换（toPlainString/BigDecimal 构造），全链路无 float/double。
- CREATE `src/main/java/com/example/okxkline/mapper/KlineMapper.java`: extends BaseMapper<KlineEntity>；核心单条 @Insert upsert：ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 全部行情字段=excluded.对应字段、confirm=excluded.confirm、updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0；另有 @Select 以子查询取最近 N 行并按 open_time 升序返回；无任何删除语句。
- CREATE `src/main/java/com/example/okxkline/mapper/SyncStateMapper.java`: MyBatis 注解 mapper：读取 id=1 单行状态；markSuccess 单语句 UPDATE（state=OK、last_attempt_at、last_success_at、错误字段置 NULL）；markFailure 单语句 UPDATE（state=DEGRADED、last_attempt_at、last_error_category、last_error_summary，不动 last_success_at）；applyStartupState 单语句 UPDATE 仅 state 列（启动转换专用，保留全部历史字段）；无删除。
- CREATE `src/main/java/com/example/okxkline/sync/KlineSyncService.java`: 同步引擎：ApplicationReadyEvent 启动回填（排序于 SyncStateService 启动转换之后）+ @Scheduled(fixedDelayString 与 initialDelayString 取 okx.sync.fixed-delay) 轮询；enabled=false 时两个入口直接返回（零 OKX 请求、零状态写）；AtomicBoolean 在飞守卫 try/finally 必释放；syncOnce：获锁后 attemptAt 仅存内存→HTTP 获取与 envelope+全部行校验（零 DB 写）→成功在唯一短事务内逐行 upsert 并 markSuccess 原子提交（事务不含 HTTP）→任何失败整轮回滚后经 SyncStateService.markFailure 独立短事务记录 DEGRADED（其自身失败由 SyncStateService 有界处理，不外抛、不谎称持久化）；日志仅记状态/耗时/行数/错误分类，不打响应正文。
- CREATE `src/main/java/com/example/okxkline/sync/SyncStateService.java`: 同步生命周期与状态事实 owner：ApplicationReadyEvent 上按 enabled 执行启动转换（false→state=DISABLED；true 且持久化为 DISABLED→state=PENDING），仅改 state 列并保留全部历史时间与错误字段；markSuccess/markFailure 以独立短事务写 sync_state，markFailure 自身 DB 异常时仅输出固定文本有界 WARN（STATE_WRITE_FAILED+分类+异常类名）并更新易失内存镜像（persisted=false），不声称已持久化；composeSummary 固定分类+受控字段（外部 msg 一律不进入），sanitize（剔除控制/零宽/BIDI 字符、≤200 截断）应用于写库/health JSON/日志三个 sink；healthView 合并 DB 行与内存镜像（较新者为准；DB 读失败有镜像→内存视图 persisted=false，无镜像→转 503 有界错误）；暴露 SyncHealthView 供 API。
- CREATE `src/main/java/com/example/okxkline/web/MarketController.java`: GET /api/klines?limit=（缺省 300；非正整数或>300 抛 InvalidLimitException→400）：经 mapper 取最近 N 行升序，映射为显式嵌套 KlineResponse record（openTime/open/high/low/close/volume/volumeCcy/volumeCcyQuote/confirmed，BigDecimal 以 plain 数值输出），不直接序列化 domain Kline；GET /api/sync/health 返回 state/lastAttemptAt/lastSuccessAt/lastErrorCategory/lastErrorSummary/statePersisted。
- CREATE `src/main/java/com/example/okxkline/web/GlobalExceptionHandler.java`: @RestControllerAdvice：InvalidLimitException 与参数类型错误→400 明确客户端错误 JSON；sync_state 读取失败→503 有界错误（SYNC_STATE_UNAVAILABLE）；未捕获异常→500 通用信息，不泄漏内部细节。
- CREATE `src/main/resources/application.yml`: 声明式配置：datasource url jdbc:sqlite:${OKX_KLINE_SQLITE_PATH:./data/okx-kline.db}、Hikari maximum-pool-size=1、journal_mode=WAL、busy_timeout=5000；flyway classpath:db/migration；jackson write-bigdecimal-as-plain；spring.task.scheduling.pool.size=1；okx.sync 默认值（www.okx.com、connect 5s、read 10s、enabled=true、fixed-delay 15s）。
- CREATE `src/main/resources/db/migration/V1__init_kline_schema.sql`: Flyway V1：kline 表（UNIQUE(instrument,bar,open_time)、confirm CHECK 0/1、价格/成交量 TEXT、open_time INTEGER 毫秒、updated_at TEXT）与 sync_state 单行表（state CHECK IN (PENDING,OK,DEGRADED,DISABLED)、attempt/success 时间与错误字段），并种子 INSERT id=1 PENDING 行；唯一且版本化的建表入口。
- CREATE `src/main/resources/static/index.html`: 首屏即行情页：仅引用本地 /vendor/klinecharts.min.js、/app.js、/styles.css（零外链）；头部信息区（BTC / USDT、1m、最新收盘价、最近闭合 K 线时间=行情时间字段、同步状态与最近成功刷新时间=独立的同步时间字段）、图表容器、无数据/降级/错误状态区；状态区仅渲染受控摘要文本。
- CREATE `src/main/resources/static/app.js`: 加载即拉取 /api/klines 与 /api/sync/health；单点适配 toChartData：{timestamp:toChartTimestamp(openTime), open, high, low, close, volume}（klinecharts 9.8.0 KLineData.timestamp 单位为秒，Math.floor(openTime/1000)，依据 vendored 包类型定义首日复核并由 DOM 测试强制）；applyNewData 渲染蜡烛+VOL 成交量；setInterval 10 秒刷新不整页重载；失败保留旧图并显示『数据可能滞后，最后成功同步于…』；最新收盘价取最后一行 close、最近闭合 K 线时间取最后一行 confirmed=true 的 openTime（行情时间与最近成功刷新时间分开标注）；空数据与首次加载提示；全部请求相对路径仅指向本应用。
- CREATE `src/main/resources/static/styles.css`: 桌面/移动响应式布局，信息区、状态区、图表不重叠；克制的 degraded 状态样式。
- CREATE `src/main/resources/static/vendor/klinecharts.min.js`: 构建期固定的 KLineCharts 9.8.0 UMD 产物（版本与获取方式记录于 README），运行时零 CDN。
- CREATE `src/test/java/com/example/okxkline/okx/CandleRowParserTest.java`: 纯单测：合法行、BigDecimal 精确保持、ts 毫秒语义、confirm 0/1；非法：字段数≠9、非数值、非正 ts、confirm 越界、空字段。
- CREATE `src/test/java/com/example/okxkline/okx/OkxMarketClientTest.java`: 经 StubOkxServer：正常 envelope、code≠0、非 2xx、429、非法 JSON、读超时（挂起不回包）；断言查询参数 instId=BTC-USDT&bar=1m&limit=300 与异常分类；新增恶意响应用例（msg 含 U+0000、ANSI 转义、HTML 片段、超长文本，及非数字 code）断言异常消息仅为受控摘要、不含原始 msg、控制字符或 HTML。
- CREATE `src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java`: 真实上下文（stub OKX+临时 SQLite+长 fixed-delay 隔离调度）覆盖：启动回填（300 行 fixture 断言由启动流程触发的请求与升序入库）；倒序/乱序输入；重复同步幂等；confirm 0→1 原位更新；闭合行 1→1 更新被接受、1→0 不回退不覆盖且无删除；陈旧响应不删较新行；非法 envelope/行整轮零写入+DEGRADED+无立即重试（请求计数静止）；同步失败后已有数据保留；AR-1 故障用例：成功事务第 N 行注入 mapper 失败→行情零写入且状态不为 OK、随后 DEGRADED/DATABASE 入账；SyncStateMapper UPDATE 注入失败→健康视图 state=DEGRADED 且 statePersisted=false、日志仅一条有界 WARN、守卫已释放（紧接手动 syncOnce 立即执行）；其后重启新上下文读同一 DB→健康为最后持久化行；AR-2 用例：enabled=false 首启（stub 计数=0、health=DISABLED）、成功一轮后禁用重启（历史时间保留、计数不增）、重新启用（不再显示 DISABLED、请求恢复增长）。
- CREATE `src/test/java/com/example/okxkline/sync/SchedulerOverlapTest.java`: fixed-delay 约 1s + stub 响应约 5s：断言并发峰值=1、请求串行；另以两线程并发调 syncOnce 验证在飞守卫跳过（含状态写失败分支后守卫仍释放）。
- CREATE `src/test/java/com/example/okxkline/persistence/KlinePersistenceTest.java`: 临时 SQLite 文件库：MP BaseMapper.insert 重复键证明唯一约束生效（cannot-bypass）、upsert 幂等；关闭上下文后以新上下文复用同一文件模拟重启，已闭合 K 线仍可查询。
- CREATE `src/test/java/com/example/okxkline/web/MarketControllerTest.java`: MockMvc+真实库：升序与 300 上限；limit 缺省与 0/301/abc→400 明确信息；/api/klines 逐字段断言（openTime/open/high/low/close/volume/volumeCcy/volumeCcyQuote/confirmed）；health 字段完整性（state/lastAttemptAt/lastSuccessAt/lastErrorCategory/lastErrorSummary/statePersisted）；同步失败后 klines 仍返回既有数据。
- CREATE `src/test/java/com/example/okxkline/web/ChartPageDomTest.java`: Playwright 加载随机端口应用（OKX 指向 stub+冻结 fixture）：捕获真实 /api/klines 响应；悬停图表触发内置 tooltip，断言时间串（期望值页内以同一 openTime 计算，规避时区偏差）、开/高/低/收与成交量与 fixture 一致（证明图表真实消费本应用后端数据且 timestamp 单位正确）；等待第二个 /api/klines 请求（默认 10 秒周期）断言无主框架导航且 stub 更新数据后图表与最新价随之变化；断言全部网络请求仅命中本应用源（无 okx.com、无 stub 直连、无 CDN）；stub 切换 500 后页面保留旧图且不出现 stub 原文。
- CREATE `src/test/java/com/example/okxkline/support/StubOkxServer.java`: 基于 JDK com.sun.net.httpserver 的契约一致 stub：可编程状态码/正文/延迟/挂起不回包；记录请求与并发计数；支持运行中切换响应序列；零新增依赖。
- CREATE `src/test/java/com/example/okxkline/smoke/OkxLiveSmokeIT.java`: 仅 -Plive-smoke 执行：直接构造 OkxMarketClient（默认 www.okx.com 配置）发起一次只读 GET，断言至少一根结构合法（9 字段、confirm∈{0,1}、开盘时间对齐分钟）的 BTC-USDT 1m K 线。
- CREATE `src/test/resources/fixtures/okx/candles-normal.json`: 冻结 300 行 BTC-USDT 1m 响应（ts 新→旧、分钟对齐，最新一根 confirm=0 其余 1），驱动启动回填与幂等用例，并作为 ChartPageDomTest 的时间/价格/成交量断言基准。
- CREATE `src/test/resources/fixtures/okx/candles-reversed.json`: 冻结倒序/乱序小集合（含早于本地已有数据的键），驱动乱序与陈旧响应不删较新数据用例。
- CREATE `src/test/resources/fixtures/okx/candles-unconfirmed.json`: 冻结同一 open_time 的 confirm=0 与 confirm=1 两个响应版本，驱动未闭合 K 线原位更新用例。
- CREATE `src/test/resources/fixtures/okx/candles-malformed-row.json`: code=0 但含非法行（字段数/数值/confirm 越界其一）的冻结响应，驱动整轮拒绝零写入用例。
- CREATE `src/test/resources/fixtures/okx/envelope-error.json`: code≠0 的业务错误冻结响应，msg 填充控制字符、HTML 片段与超长文本（非数字 code 变体由 stub 内联正文构造），同时驱动 BUSINESS_ERROR 与 AR-4 安全摘要用例。



# Required Authored Context

The following verified inputs are mandatory. Respond to every active obligation; ADDRESSED does not close it. Use NOT_ADDRESSED honestly. Initial authors return [].

## Revision parent

.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.contract.json

{
  "artifact_type" : "agent_output_contract",
  "schema_version" : 1,
  "workstream_id" : "ws-20260911T231749Z-GCTW",
  "run_id" : "run-1789169462819",
  "node_id" : "design.claude_design",
  "node_instance_id" : "node-design-claude_design-019",
  "handler_type" : "acpx.agent_run",
  "decision" : "READY_FOR_ARCH_REVIEW",
  "summary" : "围绕 confirm 语义的单语句幂等 upsert、fixedDelay 单飞调度与全离线测试矩阵的实现就绪设计，planned_files 与已批准 scope 逐项对齐。",
  "required_keys" : [ "decision", "summary" ],
  "allowed_decisions" : [ "READY_FOR_ARCH_REVIEW" ],
  "source_output_ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.json",
  "source_artifact_type" : "design_result",
  "generated_at" : "2026-09-11T23:40:46.716692Z",
  "control" : {
    "summary" : "围绕 confirm 语义的单语句幂等 upsert、fixedDelay 单飞调度与全离线测试矩阵的实现就绪设计，planned_files 与已批准 scope 逐项对齐。",
    "decision" : "READY_FOR_ARCH_REVIEW"
  },
  "control_source" : {
    "kind" : "strict_agent_result_envelope"
  },
  "revision_responses" : [ ],
  "lifecycle_status" : "READY",
  "checks" : [ "已通读已批准 TaskContract tc-ws-20260911T231749Z-GCTW-v1（human gate 016 APPROVE）、REQUIREMENT.md 与基线 README.md、.gitignore、scripts/verify-workspace.sh；当前为空基线（无 pom.xml、无 src/），交付物均为新建或对三个基线文件的窄修改。", "planned_files 与 scope.included 37 项（3 MODIFY + 34 CREATE）路径与操作逐字一致，无越权路径；REQUIREMENT.md、.git/、.agent/ 与工作区外路径不触碰。", "AC-1..AC-10 与 TR-1..TR-10 逐条映射到具体文件、fixture 与断言（见 evidence），约束 C-1..C-10 逐条满足。", "生命周期-正常完成：ApplicationReadyEvent 启动回填，每轮 获取→完整解析校验 envelope 与全部行→短事务逐行 upsert→recordSuccess(OK,lastSuccessAt)；/api/klines 与 /api/sync/health 即时反映已提交结果。", "生命周期-并发：单实例三重防重叠（@Scheduled fixedDelay 从上次结束计时 + spring.task.scheduling.pool.size=1 + AtomicBoolean 在飞守卫 try/finally 释放；启动回填与定时轮共用 syncOnce 同受守卫保护）；DB 层 Hikari maximum-pool-size=1 串行化；跨实例协调为契约非目标，不适用。", "生命周期-超时/提供方失败：TIMEOUT、HTTP_STATUS、RATE_LIMITED、BUSINESS_ERROR、MALFORMED_RESPONSE、MALFORMED_ROW、DATABASE 归一为该轮失败——解析期失败零写入，写库期失败事务回滚；置 DEGRADED 记有界摘要；无立即重试，唯一恢复路径是下一轮 fixedDelay；失败路径无 DELETE。", "生命周期-中断/崩溃：未提交事务由 SQLite journal/WAL 回滚，库中只存在完整轮次；对 OKX 仅只读 GET、无外部写副作用、无需补偿；崩溃时 sync_state 至多滞后一轮，下一轮自愈。", "生命周期-重启/恢复：Flyway 迁移幂等跳过；启动回填重跑为幂等 upsert；sync_state 持久化最近尝试/成功/失败；已闭合 K 线跨重启可查（KlinePersistenceTest 以同一文件新建 ApplicationContext 验证）。", "生命周期-回滚/冲突：行键冲突是 ON CONFLICT 正常路径而非错误；唯一约束兜底且经直插重复键用例证明不可绕过；DB 异常经 TransactionTemplate 整体回滚、失败轮零写入（注入式失败 mapper 代理验证）。", "cannot-bypass 测试映射：调度不重叠（SchedulerOverlapTest 并发峰值=1）；任何失败不删除数据（KlineSyncServiceTest 失败矩阵断言行数不减）；confirm 1→0 不可回退不可覆盖（TR-10b）；非法 limit 返回 400（MarketControllerTest）；浏览器不出站、无 CDN（ChartPageDomTest 全量网络断言）；smoke 不进默认 mvn test（surefire 排除 + 脚本）。", "不适用边界声明：缓存（未引入，本地读无缓存）、队列（无异步队列）、分布式锁（非目标）、对外系统的写副作用补偿（OKX 仅只读 GET）。", "未新增平台能力：无重试框架、无内存缓存、无额外线程池；失败后唯一恢复路径为下一轮调度；MyBatis-Plus mapper 是唯一持久化通道（无 JPA/JdbcTemplate/平行 repository，SyncStateMapper 亦是同一 SqlSessionFactory 下的 MyBatis 注解 mapper）。", "测试离线性由构造保证：自动化测试仅连本地 StubOkxServer 与冻结 fixture，生产代码默认 base-url 仅在显式 live smoke 中使用。" ],
  "evidence" : [ "架构分层：okx 层（OkxMarketClient+CandleRowParser：HTTP+envelope+行校验）→ sync 层（KlineSyncService 调度/事务/守卫 + SyncStateService 状态）→ mapper 层（MyBatis-Plus 唯一持久化通道）→ web 层（MarketController JSON API + 同源静态前端）；浏览器仅访问本应用，唯一出站流量是服务端到 OKX 的只读 GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300。", "AC-6 核心语义收敛为 KlineMapper 单条 upsert SQL：INSERT ... ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 各行情字段=excluded.对应字段, confirm=excluded.confirm, updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0——0→0/0→1/1→1 均取最近一次成功校验响应值（含闭合行价格与成交量更新），唯一被禁止的 1→0 因 WHERE 不触发而整行保持原状；全链路无 DELETE；新旧判定只用行内声明的 confirm，不读价格大小/方向，不假设未声明的版本号，且本地晚于响应最晚 open_time 的行因根本不在冲突键内而原样保留。", "解析先于写入：每轮先完整解析校验 envelope（HTTP 2xx、JSON 合法、code=='0'、data 为数组）与全部行（任一非法即抛分类异常、零 DB 写），随后 TransactionTemplate 短事务内循环 mapper.upsertOne（事务仅包 DB 写、绝不包 HTTP 调用）；同一响应重复 open_time 由循环 upsert 确定性后写覆盖。", "调度设计：@Scheduled(fixedDelayString 与 initialDelayString 均取 okx.sync.fixed-delay，默认 15s) + 启动回填经 ApplicationReadyEvent；fixedDelay 语义（上次结束才计时）+ 单线程调度器 + AtomicBoolean 守卫三层防重叠；okx.sync.enabled=false 时两个入口直接返回，无调度副作用。", "状态机：sync_state 单行（V1 迁移种子 PENDING 行 id=1）；状态集合 PENDING/OK/DEGRADED/DISABLED 仅由轮次结果的分类枚举驱动；last_error_summary 为≤200 字符白名单摘要（HTTP 只记状态码、业务错误只记 code+截断 msg、其余记异常类别），响应正文绝不入库/入日志；错误文本仅是展示元数据，不参与状态判定。", "decimal-safe 链路：OKX 十进制字符串 → BigDecimal（parser）→ KlineEntity String(toPlainString) → SQLite TEXT → 读取经 BigDecimal 构造 → API 以 Jackson WRITE_BIGDECIMAL_AS_PLAIN 输出 JSON 数值；全程无 float/double/REAL；实体用 String 承载 TEXT 列是存储编码选择，规避 xerial ResultSet.getBigDecimal 对 TEXT 列的不确定行为，且不引入未授权的 TypeHandler 文件。", "SQLite 并发：Hikari maximum-pool-size=1 串行化读写 + WAL + busy_timeout=5000 + 短事务，缓解单写者 BUSY（契约 Risk Area 4）；读路径为本地毫秒级查询，不引入缓存。", "版本化初始化：建表唯一入口 db/migration/V1__init_kline_schema.sql（Flyway）——kline 表含 UNIQUE(instrument,bar,open_time) 与 confirm CHECK(0/1)、价格/成交量 TEXT、open_time INTEGER 毫秒；sync_state 表含 state CHECK 与时间/错误字段；业务代码零 DDL。", "API 契约：GET /api/klines?limit=N（缺省 300；非正整数或>300 → 400 与明确错误信息；升序、最多 300、行含 openTime/o/h/l/c/vol/volCcy/volCcyQuote/confirmed）；GET /api/sync/health（state/lastAttemptAt/lastSuccessAt/lastErrorCategory/lastErrorSummary）；GlobalExceptionHandler 统一 400/500 JSON，不泄漏内部细节。", "前端：index.html+app.js+styles.css+vendor/klinecharts.min.js 全部同源打包零 CDN；加载即拉取 /api/klines 与 /api/sync/health，KLineCharts 渲染蜡烛+VOL 成交量（timestamp 毫秒转秒）；setInterval 10 秒 applyNewData 不整页重载；degraded/后端失败保留旧图+克制状态条；无数据与首次加载提示；最新收盘价取最后一根（可能未闭合、滞后一个同步周期，README 明示），最近闭合 K 线时间取最后一根 confirmed；桌面/移动视口不重叠。", "测试矩阵映射：TR-1→OkxMarketClientTest+KlineSyncServiceTest；TR-2→KlinePersistenceTest；TR-3→MarketControllerTest；TR-4→SchedulerOverlapTest；TR-5→CandleRowParserTest；TR-6→ChartPageDomTest；TR-7→OkxLiveSmokeIT+-Plive-smoke+scripts/live-smoke.sh；TR-8→全量本地 stub+冻结 fixture，Playwright 浏览器构建期获取并 README 记录；TR-9/TR-10→KlineSyncServiceTest 专用用例；429/非 2xx/非法 JSON/超时由 StubOkxServer 内联正文与挂起策略构造。", "smoke 隔离：默认 surefire 排除 **/smoke/**（叠加 *IT 命名双保险）；live-smoke profile 以 combine.self=override 清空排除并仅 include OkxLiveSmokeIT；OkxMarketClient 为构造式无 Spring 注解依赖，可被 smoke 直接 new 以直连 www.okx.com。", "兼容矩阵首日验证（契约 Risk Area 1）：实现首日验证 spring-boot 4.1.0 + mybatis-plus-spring-boot4-starter 3.5.17 + sqlite-jdbc + flyway（SQLite 支持归属 flyway-core 还是附加模块）的坐标解析与最小上下文装配；如需 flyway-database-sqlite 等坐标仅添加于已授权 pom.xml。", "基线文件修改点：verify-workspace.sh 仅将 test ! -e pom.xml / test ! -d src 翻转为存在性断言，保留 Java 25、清洁树与只读 OKX 探测；.gitignore 仅补 *.db-journal 与 data/；README 重写覆盖 AC-8 全部条目。" ],
  "missing_evidence" : [ ],
  "must_fix" : [ ],
  "open_risks" : [ "Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的坐标解析与装配需实现首日以最小上下文验证（契约 Risk Area 1）；若 Flyway SQLite 需附加模块坐标，仅修改已授权 pom.xml。", "Hikari data-source-properties 传递 xerial pragma（journal_mode/busy_timeout）的键名绑定需首日验证；备选为 JDBC URL 参数或 yml 显式键，不影响语义。", "Playwright for Java 浏览器二进制需构建期获取或预置本地路径（TR-8/README 记录）；离线构建环境缺二进制时 ChartPageDomTest 无法执行，属环境准备项而非设计缺口。", "live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 mvn test。", "vendored KLineCharts 具体版本在实现时锁定（9.x UMD）并写入 README，避免后续无意识升级引入行为漂移。" ],
  "verification_summary" : "本阶段仅产出实现就绪设计：已核对 TaskContract、REQUIREMENT.md 与基线仓库文件，planned_files 与批准 scope 完全一致；未执行任何代码实现、构建或测试运行。",
  "design" : {
    "planned_files" : [ {
      "path" : ".gitignore",
      "responsibility" : "补充 SQLite 运行期产物忽略（*.db-journal、data/ 目录），与既有 *.db/*.db-wal/*.db-shm 共同覆盖默认数据库文件及辅助文件。",
      "operation" : "MODIFY"
    }, {
      "path" : "README.md",
      "responsibility" : "重写为交付文档：架构、配置表（okx.sync.* 与 OKX_KLINE_SQLITE_PATH 环境变量）、SQLite 默认路径、启动、离线 mvn test、live smoke 命令、API 契约、数据新鲜度语义（confirm=0/1、闭合行可被后续合法响应修正、最新价可能滞后一个轮询周期）与已知限制。",
      "operation" : "MODIFY"
    }, {
      "path" : "pom.xml",
      "responsibility" : "Spring Boot 4.1.0 parent + Java 25；依赖 spring-boot-starter-web、com.baomidou:mybatis-plus-spring-boot4-starter:3.5.17、org.flywaydb:flyway-core、org.xerial:sqlite-jdbc；测试依赖 spring-boot-starter-test 与 com.microsoft.playwright:playwright；surefire 默认排除 **/smoke/**，live-smoke profile 覆盖排除并仅执行 OkxLiveSmokeIT。",
      "operation" : "CREATE"
    }, {
      "path" : "scripts/live-smoke.sh",
      "responsibility" : "显式 opt-in 包装：mvn -Plive-smoke test，仅触发直连 OKX 官方公开接口的只读 smoke，不进入默认测试。",
      "operation" : "CREATE"
    }, {
      "path" : "scripts/verify-workspace.sh",
      "responsibility" : "将基线断言 test ! -e pom.xml、test ! -d src 翻转为 test -f pom.xml、test -d src；保留 Java 25 校验、清洁树校验与只读 OKX 探测。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/com/example/okxkline/OkxKlineApplication.java",
      "responsibility" : "@SpringBootApplication 启动类 + @MapperScan(com.example.okxkline.mapper)；main 中仅为配置的 SQLite 路径创建父目录（初始化准备，不含任何建表逻辑）。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/config/OkxSyncProperties.java",
      "responsibility" : "@ConfigurationProperties(okx.sync)：base-url、connect-timeout、read-timeout(Duration)、enabled、fixed-delay(Duration)，经宽松绑定支持环境变量覆盖；limit 固定常量 300，不配置化。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/domain/Kline.java",
      "responsibility" : "纯领域 record：instrument、bar、openTime(long 毫秒)、open/high/low/close/volume/volumeCcy/volumeCcyQuote(BigDecimal)、confirmed(boolean)；服务层与 API 的 decimal-safe 权威载体。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxMarketClient.java",
      "responsibility" : "构造式注入 OkxSyncProperties，基于 RestClient+JDK HttpClient 按 base-url/超时构建；GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300；负责 HTTP 状态、JSON envelope（code=='0'、data 数组）校验并委托 CandleRowParser，返回 List<Kline>；失败抛出带分类枚举（TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW）与脱敏摘要的 OkxCallException；无 Spring 注解依赖，可被 live smoke 直接构造。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/CandleRowParser.java",
      "responsibility" : "纯静态行解析器：校验 9 字段、数值可解析 BigDecimal、ts 为正整数毫秒、confirm∈{0,1}；仅做格式校验，明确不做价格大小/方向等行情语义校验；输出 domain Kline。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/entity/KlineEntity.java",
      "responsibility" : "MyBatis-Plus @TableName(kline) 实体；价格/成交量以 String 承载 TEXT 列（存储编码），confirm 为 Integer 0/1，openTime 为 Long；提供与 domain Kline 的双向转换（toPlainString/BigDecimal 构造），全链路无 float/double。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/mapper/KlineMapper.java",
      "responsibility" : "extends BaseMapper<KlineEntity>；核心单条 @Insert upsert：ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 全部行情字段=excluded.对应字段、confirm=excluded.confirm、updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0；另有 @Select 以子查询取最近 N 行并按 open_time 升序返回；无任何删除语句。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/mapper/SyncStateMapper.java",
      "responsibility" : "MyBatis 注解 mapper：读取 id=1 单行状态；按轮次结果 UPDATE state/last_attempt_at/last_success_at/last_error_category/last_error_summary；无删除。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/KlineSyncService.java",
      "responsibility" : "同步引擎：ApplicationReadyEvent 启动回填 + @Scheduled(fixedDelayString 与 initialDelayString 取 okx.sync.fixed-delay) 轮询；AtomicBoolean 在飞守卫；syncOnce 先 recordAttempt，再完整获取+校验（解析期失败零写入），随后 TransactionTemplate 短事务内逐行 upsert（事务仅包 DB 写、不包 HTTP），成功 recordSuccess、失败按分类 recordFailure 并等待下一轮（无立即重试）；日志仅记状态/耗时/行数/错误分类，不打响应正文。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/SyncStateService.java",
      "responsibility" : "同步生命周期 owner：读写 sync_state 单行；状态 PENDING/OK/DEGRADED/DISABLED 仅由轮次结果分类枚举驱动（错误文本只是≤200 字符有界展示摘要，绝不参与状态判定）；暴露嵌套 SyncHealthView 供 API。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/MarketController.java",
      "responsibility" : "GET /api/klines?limit=（缺省 300；非正整数或>300 抛 InvalidLimitException→400）：经 mapper 取最近 N 行升序返回 domain Kline；GET /api/sync/health 返回状态视图；仅读本应用 SQLite。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/GlobalExceptionHandler.java",
      "responsibility" : "@RestControllerAdvice：InvalidLimitException 与参数类型错误→400 明确客户端错误 JSON；未捕获异常→500 通用信息，不泄漏内部细节。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/application.yml",
      "responsibility" : "声明式配置：datasource url jdbc:sqlite:${OKX_KLINE_SQLITE_PATH:./data/okx-kline.db}、Hikari maximum-pool-size=1、journal_mode=WAL、busy_timeout=5000；flyway classpath:db/migration；jackson write-bigdecimal-as-plain；spring.task.scheduling.pool.size=1；okx.sync 默认值（www.okx.com、connect 5s、read 10s、enabled=true、fixed-delay 15s）。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/db/migration/V1__init_kline_schema.sql",
      "responsibility" : "Flyway V1：kline 表（UNIQUE(instrument,bar,open_time)、confirm CHECK 0/1、价格/成交量 TEXT、open_time INTEGER 毫秒、updated_at TEXT）与 sync_state 单行表（state CHECK、时间与错误字段），并种子 INSERT id=1 PENDING 行；唯一且版本化的建表入口。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/index.html",
      "responsibility" : "首屏即行情页：仅引用本地 /vendor/klinecharts.min.js、/app.js、/styles.css（零外链）；头部信息区（BTC / USDT、1m、最新收盘价、最近闭合 K 线时间、同步状态、最近刷新时间）、图表容器、无数据/降级/错误状态区。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/app.js",
      "responsibility" : "加载即拉取 /api/klines 与 /api/sync/health；KLineCharts 蜡烛图+VOL 成交量（timestamp 毫秒转秒）；setInterval 10 秒 applyNewData 刷新不整页重载；失败保留旧图并显示状态；空数据与首次加载提示；全部请求相对路径仅指向本应用。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/styles.css",
      "responsibility" : "桌面/移动响应式布局，信息区、状态区、图表不重叠；克制的 degraded 状态样式。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/vendor/klinecharts.min.js",
      "responsibility" : "构建期固定的 KLineCharts UMD 产物（版本锁定并记录于 README），运行时零 CDN。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/CandleRowParserTest.java",
      "responsibility" : "纯单测：合法行、BigDecimal 精确保持、ts 毫秒语义、confirm 0/1；非法：字段数≠9、非数值、非正 ts、confirm 越界、空字段。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/OkxMarketClientTest.java",
      "responsibility" : "经 StubOkxServer：正常 envelope、code≠0、非 2xx、429、非法 JSON、读超时（挂起不回包）；断言查询参数 instId=BTC-USDT&bar=1m&limit=300 与异常分类。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java",
      "responsibility" : "真实上下文（stub OKX+临时 SQLite+长 fixed-delay 隔离调度）：启动回填 TR-9（300 行 fixture，断言由启动流程触发的请求与 300 行升序入库）；倒序/乱序输入；重复同步幂等；confirm 0→1 原位更新；闭合行 confirm=1→1 更新被接受、confirm=1 遇 0 不回退不覆盖（TR-10）且无删除；陈旧响应不删较新行；非法 envelope/行整轮零写入+DEGRADED+无立即重试（请求计数静止）；嵌套 @TestConfiguration 注入第 N 行抛错的 mapper 代理验证事务回滚零写入。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/SchedulerOverlapTest.java",
      "responsibility" : "fixed-delay 约 1s + stub 响应约 5s：断言并发峰值=1、请求串行；另以两线程并发调 syncOnce 验证在飞守卫跳过。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/persistence/KlinePersistenceTest.java",
      "responsibility" : "临时 SQLite 文件库：MP BaseMapper.insert 重复键证明唯一约束生效、upsert 幂等；关闭上下文后以新上下文复用同一文件模拟重启，已闭合 K 线仍可查询。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/MarketControllerTest.java",
      "responsibility" : "MockMvc+真实库：升序与 300 上限、limit 缺省与 0/301/abc→400 明确信息、health 字段完整性、同步失败后 klines 仍返回既有数据。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/ChartPageDomTest.java",
      "responsibility" : "Playwright 加载随机端口应用（OKX 指向 stub）：断言图表 canvas 渲染消费 /api/klines、等待 10 秒周期请求且无主框架导航、全部网络请求仅命中本应用源（无 okx.com、无 CDN、无 stub 直连）。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/support/StubOkxServer.java",
      "responsibility" : "基于 JDK com.sun.net.httpserver 的契约一致 stub：可编程状态码/正文/延迟/挂起不回包；记录请求与并发计数；零新增依赖。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/smoke/OkxLiveSmokeIT.java",
      "responsibility" : "仅 -Plive-smoke 执行：直接构造 OkxMarketClient（默认 www.okx.com 配置）发起一次只读 GET，断言至少一根结构合法（9 字段、confirm∈{0,1}、开盘时间对齐分钟）的 BTC-USDT 1m K 线。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-normal.json",
      "responsibility" : "冻结 300 行 BTC-USDT 1m 响应（ts 新→旧、分钟对齐，最新一根 confirm=0 其余 1），驱动启动回填与幂等用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-reversed.json",
      "responsibility" : "冻结倒序/乱序小集合（含早于本地已有数据的键），驱动乱序与陈旧响应不删较新数据用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-unconfirmed.json",
      "responsibility" : "冻结同一 open_time 的 confirm=0 与 confirm=1 两个响应版本，驱动未闭合 K 线原位更新用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-malformed-row.json",
      "responsibility" : "code=0 但含非法行（字段数/数值/confirm 越界其一）的冻结响应，驱动整轮拒绝零写入用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/envelope-error.json",
      "responsibility" : "code≠0 的业务错误冻结响应（如限流），驱动 BUSINESS_ERROR 用例。",
      "operation" : "CREATE"
    } ]
  },
  "stage_outcome" : "READY",
  "stage_outcome_source" : "declared_status",
  "evidence_state" : {
    "blocking" : false,
    "evidence_count" : 14,
    "missing_evidence_count" : 0,
    "must_fix_count" : 0,
    "acceptance_note_count" : 0,
    "open_risk_count" : 5
  },
  "authored_context" : {
    "sha256" : "540f6ad30b33cf2c1abafa7de9cfafc31ad264a733e3ba6ee8be4004bcec5d17",
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/prompts/design-claude.md.manifest.json"
  }
}


## Active obligations

[ {
  "id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:0",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json",
    "sha256" : "4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210"
  },
  "text" : "AR-1：明确行情提交与成功状态的事务边界。优先让行情 upsert 和成功状态在同一短事务提交，避免 recordSuccess 失败后把已提交行情描述为失败轮零写入。另明确尝试记录、失败记录自身遇到数据库异常时的有界处理、健康接口结果及守卫释放；数据库不可写时不得声称已持久化 DEGRADED。补充状态写入失败、提交失败与重启读取的故障测试。"
}, {
  "id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:1",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json",
    "sha256" : "4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210"
  },
  "text" : "AR-2：由 SyncStateService 明确拥有启动时 enabled 配置对应的状态转换。禁用时不得继续返回旧 OK 或种子 PENDING；重新启用时不得沿用旧 DISABLED。保留历史尝试、成功和失败信息，并测试首次禁用、成功后禁用重启及重新启用，确认禁用期间零 OKX 请求。"
}, {
  "id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:2",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json",
    "sha256" : "4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210"
  },
  "text" : "AR-3：统一 API 的公开字段与 domain Kline 序列化结果，并明确 app.js 的 OHLCV 和时间适配。核实固定图表版本的 timestamp 单位后决定是否转换；ChartPageDomTest 须通过真实 API 响应核对图表实际消费的时间、价格、成交量及后续刷新结果，不能仅证明 canvas 存在与请求发生。"
}, {
  "id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:3",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json",
    "sha256" : "4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210"
  },
  "text" : "AR-4：将失败摘要收敛为固定分类与受控字段，或定义可验证的外部文本清理规则；仅截断业务 msg 不足以支持安全摘要声明。补充包含控制字符和敏感样式文本的错误响应测试，验证健康 JSON、页面和日志不暴露未经处理的内容。"
}, {
  "id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:4",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json",
    "sha256" : "4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210"
  },
  "text" : "AR-5：修正 README 与前端的新鲜度说明，不得承诺最多滞后一个轮询周期。明确最近成功同步时间不等于行情最新时间，陈旧缓存和连续失败可能导致更长滞后；展示继续使用真实行情时间与最近成功时间。"
}, {
  "id" : "sha256:a93bafaa80b5336b0cf7d6b463798e868a9d0bb03e4fd24c8b28fc537b542305#human-note:0",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/gates/gate-node-gate-human_design_approval-023.json",
    "sha256" : "a93bafaa80b5336b0cf7d6b463798e868a9d0bb03e4fd24c8b28fc537b542305"
  },
  "text" : "接受AR-1至AR-5，保持当前批准TaskContract和37项路径不变，一次性同步checks/evidence/planned_files/测试描述。AR-1：删除每轮解析前recordAttempt写库；获锁后attemptAt仅在内存，HTTP获取及整个envelope和所有行校验完成后，在同一短事务内提交整批upsert与attempt/success/OK状态。失败回滚后再用独立短事务记录attempt/DEGRADED；状态写入本身失败时仅有界报告，不谎称持久化成功，finally释放守卫。补完整故障断言。AR-2：明确SyncStateService的启动enabled/disabled转换，保留历史时间，禁用零请求，覆盖禁用/重启/重新启用。AR-3：统一实际JSON字段与图表OHLCV映射，依据固定图表版本的真实接口确定timestamp单位，不臆测毫秒转秒；浏览器测试核对真实API数据、图表实际数据与刷新，不以canvas存在替代。AR-4：错误摘要使用固定分类与受控字段，不透传或仅截断外部msg；覆盖控制字符与敏感样式响应。AR-5：删除最多滞后一轮的承诺，分别展示行情时间与最近成功时间。其余已闭合的confirm更新规则、schema、scope保持不变，不新增框架、文件或平台。"
} ]

## Current review candidate

.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.contract.json

{
  "artifact_type" : "agent_output_contract",
  "schema_version" : 1,
  "workstream_id" : "ws-20260911T231749Z-GCTW",
  "run_id" : "run-1789170184692",
  "node_id" : "design.claude_design",
  "node_instance_id" : "node-design-claude_design-024",
  "handler_type" : "acpx.agent_run",
  "decision" : "READY_FOR_ARCH_REVIEW",
  "summary" : "按人工门禁指示完成 AR-1..AR-5 的完整替换设计：行情与成功状态单事务原子提交、启动禁用状态机、显式 API 与图表字段映射、固定分类安全摘要与诚实新鲜度语义，37 项 planned_files 路径与操作保持不变。",
  "required_keys" : [ "decision", "summary" ],
  "allowed_decisions" : [ "READY_FOR_ARCH_REVIEW" ],
  "source_output_ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/outputs/design-claude.json",
  "source_artifact_type" : "design_result",
  "generated_at" : "2026-09-11T23:50:44.780307Z",
  "control" : {
    "decision" : "READY_FOR_ARCH_REVIEW",
    "summary" : "按人工门禁指示完成 AR-1..AR-5 的完整替换设计：行情与成功状态单事务原子提交、启动禁用状态机、显式 API 与图表字段映射、固定分类安全摘要与诚实新鲜度语义，37 项 planned_files 路径与操作保持不变。"
  },
  "control_source" : {
    "kind" : "strict_agent_result_envelope"
  },
  "revision_responses" : [ {
    "evidence" : "成功路径已改为唯一短事务：全部行 upsert 与 markSuccess(attemptAt, successAt, OK, 清空错误字段) 原子提交，事务不含 HTTP，recordSuccess-after-commit 失败模式结构性消除；attemptAt 获锁后仅存内存、不预写库。失败路径先整轮回滚，再以独立短事务写 DEGRADED+attempt+受控摘要；该事务自身 DB 异常时仅有界 WARN（固定文本+分类+异常类名，不声称已持久化）、更新内存镜像 persisted=false、异常不外抛、守卫 finally 释放。健康接口合并规则与 503 兜底已定义：DB 行较新→持久化视图（statePersisted=true）；内存较新→DEGRADED/persisted=false；读失败有镜像→内存视图，无镜像→503 SYNC_STATE_UNAVAILABLE；重启后镜像为空、持久化行权威。新增故障测试：成功事务中途注入失败（行情零写入且状态不为 OK）、状态 UPDATE 注入失败（persisted=false+有界日志+守卫释放）、重启读取最后持久化行。",
    "disposition" : "ADDRESSED",
    "obligation_id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:0"
  }, {
    "evidence" : "SyncStateService 拥有 ApplicationReadyEvent（排序先于回填入口）上的 applyStartupMode：enabled=false 时短事务仅将 state 列置为 DISABLED（last_attempt_at/last_success_at/last_error_* 历史全部保留，种子 PENDING 与旧 OK 不再示出）；enabled=true 且持久化为 DISABLED 时置为 PENDING（重新启用不沿用旧 DISABLED），首轮回填翻为 OK/DEGRADED；两个同步入口禁用时直接返回。测试覆盖：首启即禁用（stub 请求计数=0、health=DISABLED）、成功一轮后禁用重启（历史时间保留、计数不增、health=DISABLED）、重新启用（不再显示 DISABLED、请求恢复增长）。",
    "disposition" : "ADDRESSED",
    "obligation_id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:1"
  }, {
    "evidence" : "MarketController 改用显式嵌套 KlineResponse record（openTime/open/high/low/close/volume/volumeCcy/volumeCcyQuote/confirmed），不再直接序列化 domain Kline，字段名与 app.js 映射输入、MarketControllerTest 断言三方同名对齐；app.js 逐字段映射并锁定 klinecharts 9.8.0 UMD；timestamp 单位依据包内类型定义首日复核（9.x 为秒，toChartTimestamp=Math.floor(openTime/1000)），ChartPageDomTest 以页内同源时间串断言使单位错误必然渲染 1970 年代坐标而失败，若复核为毫秒仅改该单点函数。DOM 测试捕获真实 /api/klines 响应并悬停断言 tooltip 的时间/开高低收/成交量与 fixture 一致、等待第二次请求断言无主框架导航且图表更新、全部网络请求仅本应用源。",
    "disposition" : "ADDRESSED",
    "obligation_id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:2"
  }, {
    "evidence" : "失败摘要收敛为固定分类枚举（TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW/DATABASE/STATE_WRITE_FAILED）+受控字段：仅分类固定中文标签、HTTP 状态码整数、以及整体匹配 ^[0-9]{1,10}$ 的 OKX code（输出 code=数字）；外部 msg 一律不进入摘要，不再有截断透传；写 sync_state、渲染 health JSON、输出日志三个 sink 统一 sanitize（剔除 C0/C1 控制字符与零宽/BIDI 字符、≤200 截断）；OkxMarketClient 异常消息本身即受控摘要。测试以 msg 含 U+0000、ANSI 转义、HTML 片段、超长文本及非数字 code 的响应，断言健康 JSON、页面 DOM 与日志 appender 均不出现未处理内容。",
    "disposition" : "ADDRESSED",
    "obligation_id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:3"
  }, {
    "evidence" : "README『数据新鲜度语义』与前端说明删除『最多滞后一个轮询周期』承诺；明确最近成功同步时间≠行情最新时间、confirm=0 行仍会变化、OKX 陈旧缓存与连续失败可使滞后超过一个轮询周期且无固定上界、恢复取决于下一次成功调度；页面分列展示行情时间（最新收盘价对应 K 线与最近闭合 K 线时间，取自数据本身）与最近成功刷新时间（同步状态区），degraded 文案为『数据可能滞后，最后成功同步于…』；last_attempt_at 的『最近一次已入账尝试』语义写入 README。",
    "disposition" : "ADDRESSED",
    "obligation_id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:4"
  }, {
    "evidence" : "已按人工指示一次性同步完整替换设计：删除每轮解析前 recordAttempt 写库，获锁后 attemptAt 仅内存，成功轮在同一短事务内原子提交整批 upsert 与 attempt/success/OK 状态；失败回滚后以独立短事务记录 attempt/DEGRADED，状态写入自身失败时仅有界报告不谎称持久化，finally 释放守卫；启动 enabled/disabled 转换归属 SyncStateService（禁用零请求、重启保留历史、重新启用不沿用 DISABLED）；API 与图表 OHLCV 字段统一，timestamp 单位依据固定版本 klinecharts 9.8.0 真实接口首日复核并以 DOM 测试强制；错误摘要固定分类+受控字段+sink 净化；新鲜度说明删除单轮承诺并分列行情时间与最近成功时间。confirm 更新规则、V1 schema、批准 scope 与 37 项 planned_files 路径保持不变，未新增框架、文件或平台能力。",
    "disposition" : "ADDRESSED",
    "obligation_id" : "sha256:a93bafaa80b5336b0cf7d6b463798e868a9d0bb03e4fd24c8b28fc537b542305#human-note:0"
  } ],
  "lifecycle_status" : "READY",
  "checks" : [ "已重读已批准 TaskContract tc-ws-20260911T231749Z-GCTW-v1（human gate 016 APPROVE）、人工门禁 023 指示、REQUIREMENT.md 与基线仓库现状（root 仅 .gitignore/README.md/REQUIREMENT.md/scripts/verify-workspace.sh，无 pom.xml、无 src/）；planned_files 保持 37 项（3 MODIFY + 34 CREATE）路径与操作逐字一致，仅 responsibility 同步 AR 修订，无越权路径、无新增文件、框架或平台能力。", "AR-1..AR-5 与人工指示逐条落入设计（见 evidence 与 revision_responses）；先前已闭合结论保持不变：confirm 条件 upsert 语义、UNIQUE(instrument,bar,open_time) 约束、Flyway 版本化初始化、decimal-safe 链路、smoke 隔离。", "生命周期-正常完成：成功轮 获取→完整校验 envelope 与全部行→唯一短事务内 逐行 upsert + markSuccess(attemptAt,successAt,OK,清空错误字段) 原子提交；/api/klines 与 /api/sync/health 即时反映已提交结果，不存在已提交行情但状态滞后的窗口。", "生命周期-并发：fixedDelay（上次结束才计时）+ spring.task.scheduling.pool.size=1 + AtomicBoolean 在飞守卫三层防重叠；守卫在 try/finally 释放，覆盖全部分支（解析失败、事务回滚、失败记录自身 DB 异常）；启动回填与定时轮共用 syncOnce 同受守卫；Hikari maximum-pool-size=1 串行化 DB 访问；跨实例协调为契约非目标，不适用。", "生命周期-超时/提供方失败：TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW/DATABASE 归一为该轮失败——解析期失败零写入；写库失败行情与 OK 状态同事务整体回滚；失败后以独立短事务记录 attempt+DEGRADED+受控摘要，该事务自身失败时仅有界报告（固定文本 WARN + 内存镜像 persisted=false），不外抛、不谎称已持久化；无立即重试，唯一恢复路径是下一轮调度；失败路径无 DELETE。", "生命周期-中断/崩溃：未提交事务由 SQLite WAL/journal 回滚，库中不存在部分轮次；崩溃至多丢失当轮（含其状态记录），sync_state 保持最后一次已入账轮次；对 OKX 仅只读 GET，无外部写副作用，补偿不适用。", "生命周期-重启/恢复：Flyway 迁移幂等跳过；启动回填重跑为幂等 upsert；sync_state 读取最后持久化行（内存镜像不跨重启，不会出现未持久化的内存值）；已闭合 K 线跨重启可查（KlinePersistenceTest 同一文件新建上下文验证）；状态写失败后的重启读取有专用故障测试。", "生命周期-回滚/冲突：行键冲突是 ON CONFLICT 正常路径而非错误；唯一约束兜底并以直插重复键用例证明不可绕过；成功事务中途注入失败整轮回滚、行情零写入且状态不为 OK，有注入式 mapper 代理测试。", "cannot-bypass 测试映射：调度不重叠（SchedulerOverlapTest 并发峰值=1）；任何失败不删除数据（KlineSyncServiceTest 失败矩阵断言行数不减）；confirm 1→0 不可回退不可覆盖；非法 limit 返回 400（MarketControllerTest）；浏览器零出站、零 CDN 且图表真实消费本应用后端数据（ChartPageDomTest）；禁用期间零 OKX 请求（KlineSyncServiceTest 新增，stub 请求计数=0）；live smoke 不进默认 mvn test（surefire 排除 + 独立脚本）。", "不适用边界声明：缓存（未引入，本地毫秒级读无缓存）、异步队列（无）、分布式锁/多实例协调（契约非目标）、对外系统写副作用补偿（OKX 仅只读 GET）；未新增重试框架、内存缓存或额外线程池，失败后唯一恢复路径为下一轮调度。", "前后端契约一致性：KlineResponse 显式字段 = app.js 映射输入 = ChartPageDomTest 断言字段，三者同名对齐；图表版本锁定 klinecharts 9.8.0，timestamp 单位有依据来源（包内类型定义首日复核）并有可执行强制（DOM 时间断言），不依赖臆测。", "测试离线性由构造保证：自动化测试仅连本地 StubOkxServer 与冻结 fixture，默认 surefire 排除 **/smoke/**；生产 base-url 仅在显式 live smoke 中使用。" ],
  "evidence" : [ "架构分层：okx 层（OkxMarketClient+CandleRowParser：HTTP+envelope+行校验）→ sync 层（KlineSyncService 调度/守卫/事务编排 + SyncStateService 状态机与安全摘要 owner）→ mapper 层（MyBatis-Plus 唯一持久化通道）→ web 层（MarketController 显式 DTO + GlobalExceptionHandler + 同源静态前端）；浏览器仅访问本应用，唯一出站流量是服务端到 OKX 的只读 GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300。", "AR-1 事务边界（核心修订）：syncOnce 获守卫后 attemptAt 仅存内存、不预写库；HTTP 获取与 envelope/全部行校验完成（零 DB 写）后，成功路径在唯一短事务内先逐行 upsert 再 markSuccess(attemptAt, successAt, state=OK, 错误字段置 NULL) 原子提交——行情与 OK 状态同进同退，recordSuccess-after-commit 失败模式在结构上不存在；该事务不含 HTTP 调用；事务任何失败即整轮回滚（行情零写入且状态不为 OK），进入失败路径并归类 DATABASE。", "AR-1 失败路径与状态写失败：失败路径以独立短事务 markFailure(attemptAt, state=DEGRADED, category, 受控摘要)（last_success_at 不动）；该事务自身抛错时的有界处理：仅输出一条固定文本 WARN（STATE_WRITE_FAILED + 分类 + 异常类名，绝不声称已持久化 DEGRADED、绝不含 OKX 正文），并更新易失内存镜像（persisted=false）；异常不外抛；守卫在 finally 释放，不阻塞下一轮调度。", "AR-1 健康接口结果定义：healthView 合并规则——DB 行可读且 last_attempt_at 不旧于内存镜像时返回持久化行视图（statePersisted=true）；内存镜像较新（失败记录未持久化）时返回内存视图（state=DEGRADED，statePersisted=false，lastSuccessAt 取镜像保留值）；DB 行读取失败且有镜像→内存视图（persisted=false），无镜像→503 有界错误 SYNC_STATE_UNAVAILABLE；重启后镜像为空，持久化行即权威；崩溃场景下 last_attempt_at 语义为『最近一次已入账的尝试』（README 记录）。", "AR-2 启动状态转换：SyncStateService 拥有 ApplicationReadyEvent（排序先于回填入口）上的 applyStartupMode——enabled=false 时短事务仅将 state 列置为 DISABLED（last_attempt_at/last_success_at/last_error_* 历史全部保留；种子 PENDING 不再以 PENDING 示人，旧 OK 也不再在禁用时继续显示）；enabled=true 且持久化状态为 DISABLED 时置为 PENDING（重新启用不沿用旧 DISABLED），随后回填首轮翻为 OK/DEGRADED；两个同步入口在 enabled=false 时直接返回，零 OKX 请求、零状态写。", "AR-3 API 契约统一：MarketController 不再直接序列化 domain Kline，改为显式嵌套 KlineResponse record：openTime(long 毫秒)、open/high/low/close/volume/volumeCcy/volumeCcyQuote（Jackson WRITE_BIGDECIMAL_AS_PLAIN 输出 plain 数值）、confirmed(boolean)；/api/sync/health 返回 state/lastAttemptAt/lastSuccessAt/lastErrorCategory/lastErrorSummary/statePersisted；字段名即前后端契约，MarketControllerTest 逐字段断言。", "AR-3 前端映射与 timestamp 单位：锁定 klinecharts 9.8.0 UMD（vendored 本地打包，README 记录版本与获取方式）；app.js 单点适配 toChartData：{timestamp:toChartTimestamp(openTime), open, high, low, close, volume}，VOL 内置指标消费 volume；klinecharts 9.x KLineData.timestamp 单位为秒，toChartTimestamp=Math.floor(openTime/1000)——该单位依据 vendored 包内类型定义于实施首日复核，并以 ChartPageDomTest 的时间断言强制执行（单位错误必然渲染 1970 年代坐标而失败）；若复核结论为毫秒，仅删除该单点转换，无任何契约变化。", "AR-3 DOM 级验证：ChartPageDomTest（Playwright+随机端口应用+stub OKX+冻结 fixture）：捕获真实 /api/klines 响应 JSON；悬停图表触发内置 tooltip，断言文本包含最新一根 K 线的时间串（期望串在页内以同一 openTime 计算，规避时区偏差）、开/高/低/收与成交量数值串与 fixture 一致；等待第二个 /api/klines 请求（默认 10 秒周期）期间 stub 更新数据，断言无主框架导航、图表与头部最新价随之更新；断言全部网络请求仅命中本应用源（无 okx.com、无 stub 直连、无 CDN）；降级场景页面保留旧图且不出现 stub 原文。", "AR-4 安全摘要：失败分类固定枚举 TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW/DATABASE/STATE_WRITE_FAILED；摘要仅由分类固定中文标签与受控数字片段组成——HTTP 状态码（整数）、OKX envelope code（仅当整体匹配 ^[0-9]{1,10}$ 才输出 code=数字），外部 msg 一律不进入摘要；写 sync_state、渲染 health JSON、输出日志三个 sink 统一 sanitize：剔除 C0/C1 控制字符（U+0000-U+001F、U+007F-U+009F）与零宽/BIDI 字符、截断至 ≤200 字符；OkxMarketClient 异常消息本身即该受控摘要。", "AR-4 测试：envelope-error fixture 与 stub 内联正文构造 msg 含 U+0000、ANSI 转义（U+001B[31m）、HTML 片段、超长文本及非数字 code 的响应；断言异常消息、健康 JSON、页面 DOM 文本与日志 appender 均只出现期望组合摘要，不含任何原始 msg 片段、控制字符或 HTML。", "AR-5 新鲜度语义：README 与前端删除『最多滞后一个轮询周期』表述；明确最近成功同步时间 ≠ 行情最新时间、confirm=0 行仍会变化、OKX 陈旧缓存与连续失败可使滞后超过一个轮询周期且无固定上界、恢复取决于下一次成功调度；页面分列展示 行情时间（最新收盘价对应 K 线与最近闭合 K 线时间，取自数据本身）与 最近成功刷新时间（同步状态区），degraded 文案为『数据可能滞后，最后成功同步于…』。", "AC-6 upsert 语义不变：KlineMapper 单条 upsert SQL：INSERT ... ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 行情字段=excluded.对应字段、confirm=excluded.confirm、updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0——0→0/0→1/1→1 均取最近一次成功校验响应值，1→0 因 WHERE 不触发整行保持原状；全链路无 DELETE；新旧判定只用行内 confirm，不读价格大小/方向，本地较新行因不在冲突键内原样保留。", "解析先于写入：每轮先校验 HTTP 2xx、JSON 合法、code=='0'、data 为数组与全部 9 字段行（任一非法整轮拒绝零写入），随后才进入写事务；CandleRowParser 仅做格式校验，明确不做价格大小/方向等行情语义校验。", "调度与并发：@Scheduled(fixedDelayString 与 initialDelayString 均取 okx.sync.fixed-delay，默认 15s）+ 单线程调度器 + AtomicBoolean 守卫三层防重叠；SchedulerOverlapTest 以 fixed-delay 约 1s + stub 响应约 5s 断言并发峰值=1、请求串行，并以两线程并发调 syncOnce 验证守卫跳过（含状态写失败分支后守卫仍释放）。", "状态机与持久化 schema：sync_state 单行（V1 迁移种子 id=1 PENDING），state CHECK IN (PENDING,OK,DEGRADED,DISABLED)；状态仅由轮次结果分类枚举与启动转换驱动，错误文本只是 ≤200 字符有界展示元数据，绝不参与状态判定；Flyway V1 是唯一且版本化的建表入口，业务代码零 DDL。", "decimal-safe 链路：OKX 十进制字符串 → BigDecimal（parser）→ KlineEntity String(toPlainString) → SQLite TEXT → 读取经 BigDecimal 构造 → API 以 Jackson WRITE_BIGDECIMAL_AS_PLAIN 输出 JSON 数值；全程无 float/double/REAL；实体以 String 承载 TEXT 列规避 xerial ResultSet.getBigDecimal 对 TEXT 列的不确定行为，且不引入未授权 TypeHandler 文件。", "SQLite 并发与配置：Hikari maximum-pool-size=1 串行化读写 + WAL + busy_timeout=5000 + 短事务，缓解单写者 BUSY；OKX base URL、连接/读取超时、okx.sync.enabled、fixed-delay 全部经 @ConfigurationProperties(okx.sync) 外部可配置。", "测试矩阵映射：TR-1→OkxMarketClientTest+KlineSyncServiceTest；TR-2→KlinePersistenceTest；TR-3→MarketControllerTest；TR-4→SchedulerOverlapTest；TR-5→CandleRowParserTest；TR-6→ChartPageDomTest；TR-7→OkxLiveSmokeIT+-Plive-smoke+scripts/live-smoke.sh；TR-8→全量本地 stub+冻结 fixture；TR-9/TR-10→KlineSyncServiceTest 专用用例；429/非 2xx/非法 JSON/超时由 StubOkxServer 内联正文与挂起策略构造。", "新增故障与状态用例（KlineSyncServiceTest）：成功事务第 N 行注入 mapper 失败→行情零写入、状态不为 OK、随后 DEGRADED/DATABASE 入账；SyncStateMapper UPDATE 注入失败→健康视图 state=DEGRADED 且 statePersisted=false、日志仅一条有界 WARN、守卫已释放（紧接手动 syncOnce 立即执行）；其后重启新上下文读同一 DB→健康为最后持久化行；enabled=false 首启（stub 计数=0、health=DISABLED）；成功一轮后禁用重启（历史时间保留、计数不增、health=DISABLED）；重新启用（不再显示 DISABLED、请求恢复增长）。", "smoke 隔离：默认 surefire 排除 **/smoke/**（叠加 *IT 命名双保险）；live-smoke profile 以 combine.self=override 清空排除并仅 include OkxLiveSmokeIT；OkxMarketClient 为构造式无 Spring 注解依赖，可被 smoke 直接 new 以直连 www.okx.com。", "基线文件修改点（已核对现状）：verify-workspace.sh 仅将第 8-9 行 test ! -e pom.xml / test ! -d src 翻转为 test -f pom.xml / test -d src，保留 Java 25、清洁树与只读 OKX 探测；.gitignore 现有 *.db/*.db-shm/*.db-wal/*.sqlite/*.sqlite3，仅补 *.db-journal 与 data/；README 为基线占位文档，整体重写覆盖 REQUIREMENT 验证条目。" ],
  "missing_evidence" : [ ],
  "must_fix" : [ ],
  "open_risks" : [ "Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的坐标解析与最小上下文装配需实现首日验证（含 Flyway SQLite 支持归属 flyway-core 还是附加模块）；如需附加坐标仅添加于已授权 pom.xml。", "Hikari data-source-properties 传递 xerial pragma（journal_mode/busy_timeout）的键名绑定需首日验证；备选为 JDBC URL 参数或 yml 显式键，不影响语义。", "Playwright for Java 浏览器二进制需构建期获取或预置本地路径（README 记录）；离线构建环境缺二进制时 ChartPageDomTest 无法执行，属环境准备项而非设计缺口。", "live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 mvn test。", "vendored klinecharts 9.8.0 的构建期获取与 timestamp 单位（秒）需实施首日对包内类型定义复核；ChartPageDomTest 的时间断言已使单位错误必然失败，若复核结论为毫秒仅调整 toChartTimestamp 单点函数，无契约变化。" ],
  "verification_summary" : "本阶段仅产出实现就绪的完整替换设计：planned_files 与批准 scope 完全一致，AR-1..AR-5 已逐条落入设计与测试描述；未执行任何代码实现、构建或测试运行。",
  "design" : {
    "planned_files" : [ {
      "responsibility" : "补充 SQLite 运行期产物忽略（*.db-journal、data/ 目录），与既有 *.db/*.db-wal/*.db-shm/*.sqlite/*.sqlite3 共同覆盖默认数据库文件及辅助文件。",
      "operation" : "MODIFY",
      "path" : ".gitignore"
    }, {
      "responsibility" : "重写为交付文档：架构、配置表（okx.sync.* 与 OKX_KLINE_SQLITE_PATH 环境变量）、SQLite 默认路径、启动、离线 mvn test、live smoke 命令、API 契约（/api/klines 与 /api/sync/health 全字段，含 statePersisted 与 last_attempt_at 的『最近一次已入账尝试』语义）、数据新鲜度语义（最近成功同步时间≠行情最新时间；confirm=0 行可变；陈旧缓存与连续失败可致滞后超过一个轮询周期且无固定上界；闭合行可被后续合法响应修正）、klinecharts 9.8.0 版本与 timestamp 单位依据、已知限制；全文不出现『最多滞后一个轮询周期』表述。",
      "operation" : "MODIFY",
      "path" : "README.md"
    }, {
      "responsibility" : "Spring Boot 4.1.0 parent + Java 25；依赖 spring-boot-starter-web、com.baomidou:mybatis-plus-spring-boot4-starter:3.5.17、org.flywaydb:flyway-core、org.xerial:sqlite-jdbc；测试依赖 spring-boot-starter-test 与 com.microsoft.playwright:playwright；surefire 默认排除 **/smoke/**，live-smoke profile 覆盖排除并仅执行 OkxLiveSmokeIT。",
      "operation" : "CREATE",
      "path" : "pom.xml"
    }, {
      "responsibility" : "显式 opt-in 包装：mvn -Plive-smoke test，仅触发直连 OKX 官方公开接口的只读 smoke，不进入默认测试。",
      "operation" : "CREATE",
      "path" : "scripts/live-smoke.sh"
    }, {
      "responsibility" : "将基线断言 test ! -e pom.xml、test ! -d src 翻转为 test -f pom.xml、test -d src；保留 Java 25 校验、清洁树校验与只读 OKX 探测。",
      "operation" : "MODIFY",
      "path" : "scripts/verify-workspace.sh"
    }, {
      "responsibility" : "@SpringBootApplication 启动类 + @MapperScan(com.example.okxkline.mapper)；main 中仅为配置的 SQLite 路径创建父目录（初始化准备，不含任何建表逻辑）。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/OkxKlineApplication.java"
    }, {
      "responsibility" : "@ConfigurationProperties(okx.sync)：base-url、connect-timeout、read-timeout(Duration)、enabled、fixed-delay(Duration)，经宽松绑定支持环境变量覆盖；limit 固定常量 300，不配置化。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/config/OkxSyncProperties.java"
    }, {
      "responsibility" : "纯领域 record：instrument、bar、openTime(long 毫秒)、open/high/low/close/volume/volumeCcy/volumeCcyQuote(BigDecimal)、confirmed(boolean)；服务层与 API 的 decimal-safe 权威载体。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/domain/Kline.java"
    }, {
      "responsibility" : "构造式注入 OkxSyncProperties，基于 RestClient+JDK HttpClient 按 base-url/超时构建；GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300；校验 HTTP 状态与 envelope（code=='0'、data 数组）并委托 CandleRowParser；失败抛出带分类枚举（TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW）的 OkxCallException，异常消息即受控摘要（分类标签+可选数字片段，绝不包含外部 msg 或响应正文）；无 Spring 注解依赖，可被 live smoke 直接构造。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/okx/OkxMarketClient.java"
    }, {
      "responsibility" : "纯静态行解析器：校验 9 字段、数值可解析 BigDecimal、ts 为正整数毫秒、confirm∈{0,1}；仅做格式校验，明确不做价格大小/方向等行情语义校验；输出 domain Kline。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/okx/CandleRowParser.java"
    }, {
      "responsibility" : "MyBatis-Plus @TableName(kline) 实体；价格/成交量以 String 承载 TEXT 列（存储编码），confirm 为 Integer 0/1，openTime 为 Long；提供与 domain Kline 的双向转换（toPlainString/BigDecimal 构造），全链路无 float/double。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/entity/KlineEntity.java"
    }, {
      "responsibility" : "extends BaseMapper<KlineEntity>；核心单条 @Insert upsert：ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 全部行情字段=excluded.对应字段、confirm=excluded.confirm、updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0；另有 @Select 以子查询取最近 N 行并按 open_time 升序返回；无任何删除语句。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/mapper/KlineMapper.java"
    }, {
      "responsibility" : "MyBatis 注解 mapper：读取 id=1 单行状态；markSuccess 单语句 UPDATE（state=OK、last_attempt_at、last_success_at、错误字段置 NULL）；markFailure 单语句 UPDATE（state=DEGRADED、last_attempt_at、last_error_category、last_error_summary，不动 last_success_at）；applyStartupState 单语句 UPDATE 仅 state 列（启动转换专用，保留全部历史字段）；无删除。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/mapper/SyncStateMapper.java"
    }, {
      "responsibility" : "同步引擎：ApplicationReadyEvent 启动回填（排序于 SyncStateService 启动转换之后）+ @Scheduled(fixedDelayString 与 initialDelayString 取 okx.sync.fixed-delay) 轮询；enabled=false 时两个入口直接返回（零 OKX 请求、零状态写）；AtomicBoolean 在飞守卫 try/finally 必释放；syncOnce：获锁后 attemptAt 仅存内存→HTTP 获取与 envelope+全部行校验（零 DB 写）→成功在唯一短事务内逐行 upsert 并 markSuccess 原子提交（事务不含 HTTP）→任何失败整轮回滚后经 SyncStateService.markFailure 独立短事务记录 DEGRADED（其自身失败由 SyncStateService 有界处理，不外抛、不谎称持久化）；日志仅记状态/耗时/行数/错误分类，不打响应正文。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/sync/KlineSyncService.java"
    }, {
      "responsibility" : "同步生命周期与状态事实 owner：ApplicationReadyEvent 上按 enabled 执行启动转换（false→state=DISABLED；true 且持久化为 DISABLED→state=PENDING），仅改 state 列并保留全部历史时间与错误字段；markSuccess/markFailure 以独立短事务写 sync_state，markFailure 自身 DB 异常时仅输出固定文本有界 WARN（STATE_WRITE_FAILED+分类+异常类名）并更新易失内存镜像（persisted=false），不声称已持久化；composeSummary 固定分类+受控字段（外部 msg 一律不进入），sanitize（剔除控制/零宽/BIDI 字符、≤200 截断）应用于写库/health JSON/日志三个 sink；healthView 合并 DB 行与内存镜像（较新者为准；DB 读失败有镜像→内存视图 persisted=false，无镜像→转 503 有界错误）；暴露 SyncHealthView 供 API。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/sync/SyncStateService.java"
    }, {
      "responsibility" : "GET /api/klines?limit=（缺省 300；非正整数或>300 抛 InvalidLimitException→400）：经 mapper 取最近 N 行升序，映射为显式嵌套 KlineResponse record（openTime/open/high/low/close/volume/volumeCcy/volumeCcyQuote/confirmed，BigDecimal 以 plain 数值输出），不直接序列化 domain Kline；GET /api/sync/health 返回 state/lastAttemptAt/lastSuccessAt/lastErrorCategory/lastErrorSummary/statePersisted。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/web/MarketController.java"
    }, {
      "responsibility" : "@RestControllerAdvice：InvalidLimitException 与参数类型错误→400 明确客户端错误 JSON；sync_state 读取失败→503 有界错误（SYNC_STATE_UNAVAILABLE）；未捕获异常→500 通用信息，不泄漏内部细节。",
      "operation" : "CREATE",
      "path" : "src/main/java/com/example/okxkline/web/GlobalExceptionHandler.java"
    }, {
      "responsibility" : "声明式配置：datasource url jdbc:sqlite:${OKX_KLINE_SQLITE_PATH:./data/okx-kline.db}、Hikari maximum-pool-size=1、journal_mode=WAL、busy_timeout=5000；flyway classpath:db/migration；jackson write-bigdecimal-as-plain；spring.task.scheduling.pool.size=1；okx.sync 默认值（www.okx.com、connect 5s、read 10s、enabled=true、fixed-delay 15s）。",
      "operation" : "CREATE",
      "path" : "src/main/resources/application.yml"
    }, {
      "responsibility" : "Flyway V1：kline 表（UNIQUE(instrument,bar,open_time)、confirm CHECK 0/1、价格/成交量 TEXT、open_time INTEGER 毫秒、updated_at TEXT）与 sync_state 单行表（state CHECK IN (PENDING,OK,DEGRADED,DISABLED)、attempt/success 时间与错误字段），并种子 INSERT id=1 PENDING 行；唯一且版本化的建表入口。",
      "operation" : "CREATE",
      "path" : "src/main/resources/db/migration/V1__init_kline_schema.sql"
    }, {
      "responsibility" : "首屏即行情页：仅引用本地 /vendor/klinecharts.min.js、/app.js、/styles.css（零外链）；头部信息区（BTC / USDT、1m、最新收盘价、最近闭合 K 线时间=行情时间字段、同步状态与最近成功刷新时间=独立的同步时间字段）、图表容器、无数据/降级/错误状态区；状态区仅渲染受控摘要文本。",
      "operation" : "CREATE",
      "path" : "src/main/resources/static/index.html"
    }, {
      "responsibility" : "加载即拉取 /api/klines 与 /api/sync/health；单点适配 toChartData：{timestamp:toChartTimestamp(openTime), open, high, low, close, volume}（klinecharts 9.8.0 KLineData.timestamp 单位为秒，Math.floor(openTime/1000)，依据 vendored 包类型定义首日复核并由 DOM 测试强制）；applyNewData 渲染蜡烛+VOL 成交量；setInterval 10 秒刷新不整页重载；失败保留旧图并显示『数据可能滞后，最后成功同步于…』；最新收盘价取最后一行 close、最近闭合 K 线时间取最后一行 confirmed=true 的 openTime（行情时间与最近成功刷新时间分开标注）；空数据与首次加载提示；全部请求相对路径仅指向本应用。",
      "operation" : "CREATE",
      "path" : "src/main/resources/static/app.js"
    }, {
      "responsibility" : "桌面/移动响应式布局，信息区、状态区、图表不重叠；克制的 degraded 状态样式。",
      "operation" : "CREATE",
      "path" : "src/main/resources/static/styles.css"
    }, {
      "responsibility" : "构建期固定的 KLineCharts 9.8.0 UMD 产物（版本与获取方式记录于 README），运行时零 CDN。",
      "operation" : "CREATE",
      "path" : "src/main/resources/static/vendor/klinecharts.min.js"
    }, {
      "responsibility" : "纯单测：合法行、BigDecimal 精确保持、ts 毫秒语义、confirm 0/1；非法：字段数≠9、非数值、非正 ts、confirm 越界、空字段。",
      "operation" : "CREATE",
      "path" : "src/test/java/com/example/okxkline/okx/CandleRowParserTest.java"
    }, {
      "responsibility" : "经 StubOkxServer：正常 envelope、code≠0、非 2xx、429、非法 JSON、读超时（挂起不回包）；断言查询参数 instId=BTC-USDT&bar=1m&limit=300 与异常分类；新增恶意响应用例（msg 含 U+0000、ANSI 转义、HTML 片段、超长文本，及非数字 code）断言异常消息仅为受控摘要、不含原始 msg、控制字符或 HTML。",
      "operation" : "CREATE",
      "path" : "src/test/java/com/example/okxkline/okx/OkxMarketClientTest.java"
    }, {
      "responsibility" : "真实上下文（stub OKX+临时 SQLite+长 fixed-delay 隔离调度）覆盖：启动回填（300 行 fixture 断言由启动流程触发的请求与升序入库）；倒序/乱序输入；重复同步幂等；confirm 0→1 原位更新；闭合行 1→1 更新被接受、1→0 不回退不覆盖且无删除；陈旧响应不删较新行；非法 envelope/行整轮零写入+DEGRADED+无立即重试（请求计数静止）；同步失败后已有数据保留；AR-1 故障用例：成功事务第 N 行注入 mapper 失败→行情零写入且状态不为 OK、随后 DEGRADED/DATABASE 入账；SyncStateMapper UPDATE 注入失败→健康视图 state=DEGRADED 且 statePersisted=false、日志仅一条有界 WARN、守卫已释放（紧接手动 syncOnce 立即执行）；其后重启新上下文读同一 DB→健康为最后持久化行；AR-2 用例：enabled=false 首启（stub 计数=0、health=DISABLED）、成功一轮后禁用重启（历史时间保留、计数不增）、重新启用（不再显示 DISABLED、请求恢复增长）。",
      "operation" : "CREATE",
      "path" : "src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java"
    }, {
      "responsibility" : "fixed-delay 约 1s + stub 响应约 5s：断言并发峰值=1、请求串行；另以两线程并发调 syncOnce 验证在飞守卫跳过（含状态写失败分支后守卫仍释放）。",
      "operation" : "CREATE",
      "path" : "src/test/java/com/example/okxkline/sync/SchedulerOverlapTest.java"
    }, {
      "responsibility" : "临时 SQLite 文件库：MP BaseMapper.insert 重复键证明唯一约束生效（cannot-bypass）、upsert 幂等；关闭上下文后以新上下文复用同一文件模拟重启，已闭合 K 线仍可查询。",
      "operation" : "CREATE",
      "path" : "src/test/java/com/example/okxkline/persistence/KlinePersistenceTest.java"
    }, {
      "responsibility" : "MockMvc+真实库：升序与 300 上限；limit 缺省与 0/301/abc→400 明确信息；/api/klines 逐字段断言（openTime/open/high/low/close/volume/volumeCcy/volumeCcyQuote/confirmed）；health 字段完整性（state/lastAttemptAt/lastSuccessAt/lastErrorCategory/lastErrorSummary/statePersisted）；同步失败后 klines 仍返回既有数据。",
      "operation" : "CREATE",
      "path" : "src/test/java/com/example/okxkline/web/MarketControllerTest.java"
    }, {
      "responsibility" : "Playwright 加载随机端口应用（OKX 指向 stub+冻结 fixture）：捕获真实 /api/klines 响应；悬停图表触发内置 tooltip，断言时间串（期望值页内以同一 openTime 计算，规避时区偏差）、开/高/低/收与成交量与 fixture 一致（证明图表真实消费本应用后端数据且 timestamp 单位正确）；等待第二个 /api/klines 请求（默认 10 秒周期）断言无主框架导航且 stub 更新数据后图表与最新价随之变化；断言全部网络请求仅命中本应用源（无 okx.com、无 stub 直连、无 CDN）；stub 切换 500 后页面保留旧图且不出现 stub 原文。",
      "operation" : "CREATE",
      "path" : "src/test/java/com/example/okxkline/web/ChartPageDomTest.java"
    }, {
      "responsibility" : "基于 JDK com.sun.net.httpserver 的契约一致 stub：可编程状态码/正文/延迟/挂起不回包；记录请求与并发计数；支持运行中切换响应序列；零新增依赖。",
      "operation" : "CREATE",
      "path" : "src/test/java/com/example/okxkline/support/StubOkxServer.java"
    }, {
      "responsibility" : "仅 -Plive-smoke 执行：直接构造 OkxMarketClient（默认 www.okx.com 配置）发起一次只读 GET，断言至少一根结构合法（9 字段、confirm∈{0,1}、开盘时间对齐分钟）的 BTC-USDT 1m K 线。",
      "operation" : "CREATE",
      "path" : "src/test/java/com/example/okxkline/smoke/OkxLiveSmokeIT.java"
    }, {
      "responsibility" : "冻结 300 行 BTC-USDT 1m 响应（ts 新→旧、分钟对齐，最新一根 confirm=0 其余 1），驱动启动回填与幂等用例，并作为 ChartPageDomTest 的时间/价格/成交量断言基准。",
      "operation" : "CREATE",
      "path" : "src/test/resources/fixtures/okx/candles-normal.json"
    }, {
      "responsibility" : "冻结倒序/乱序小集合（含早于本地已有数据的键），驱动乱序与陈旧响应不删较新数据用例。",
      "operation" : "CREATE",
      "path" : "src/test/resources/fixtures/okx/candles-reversed.json"
    }, {
      "responsibility" : "冻结同一 open_time 的 confirm=0 与 confirm=1 两个响应版本，驱动未闭合 K 线原位更新用例。",
      "operation" : "CREATE",
      "path" : "src/test/resources/fixtures/okx/candles-unconfirmed.json"
    }, {
      "responsibility" : "code=0 但含非法行（字段数/数值/confirm 越界其一）的冻结响应，驱动整轮拒绝零写入用例。",
      "operation" : "CREATE",
      "path" : "src/test/resources/fixtures/okx/candles-malformed-row.json"
    }, {
      "responsibility" : "code≠0 的业务错误冻结响应，msg 填充控制字符、HTML 片段与超长文本（非数字 code 变体由 stub 内联正文构造），同时驱动 BUSINESS_ERROR 与 AR-4 安全摘要用例。",
      "operation" : "CREATE",
      "path" : "src/test/resources/fixtures/okx/envelope-error.json"
    } ]
  },
  "stage_outcome" : "READY",
  "stage_outcome_source" : "declared_status",
  "evidence_state" : {
    "blocking" : false,
    "evidence_count" : 21,
    "missing_evidence_count" : 0,
    "must_fix_count" : 0,
    "acceptance_note_count" : 0,
    "open_risk_count" : 5
  },
  "authored_context" : {
    "sha256" : "d681599a0f30480d9dca49c3a1742e7df68c4d777957dd4eb0a0b126d956325d",
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170184692/prompts/design-claude.md.manifest.json"
  }
}
