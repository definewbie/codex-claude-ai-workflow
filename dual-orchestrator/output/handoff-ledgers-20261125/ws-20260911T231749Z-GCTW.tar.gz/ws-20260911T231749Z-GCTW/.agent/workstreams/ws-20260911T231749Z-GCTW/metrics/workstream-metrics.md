# Workstream Metrics

- Workstream: ws-20260911T231749Z-GCTW
- Workflow: agent-lifecycle-small-plan-human-review-experiment@1
- Status: WAITING_FOR_RECOVERY
- Generated At: 2026-09-12T00:07:59.882314Z

## Counts

- Nodes: 32
- Agent Runs: 13
- Gates: 5
- Decisions: 6
- Iterations: 6
- Revisions: 5
- Total Node Duration(ms): 2513250

## Longest Nodes

| Node | Status | Iteration | Duration(ms) |
| --- | --- | --- | --- |
| design.claude_design | COMPLETED | iter-003 | 583936 |
| design.claude_design | COMPLETED | iter-004 | 460148 |
| design.claude_design | COMPLETED | iter-005 | 396592 |
| design.claude_design | FAILED | iter-006 | 361293 |
| intake.claude_brainstorm | COMPLETED | iter-001 | 231697 |

## Provider Metrics

| Provider | Runs | Completed | Failed | Recoverable | Total Duration(ms) | Average Duration(ms) |
| --- | --- | --- | --- | --- | --- | --- |
| claude | 7 | 6 | 1 | 1 | 2209539 | 315648 |
| codex | 6 | 6 | 0 | 0 | 272733 | 45455 |
| outcomeStatusCounts | null | null | null | null | null | null |
| executionConsistencyCounts | null | null | null | null | null | null |

## Token Metrics

- Measured Runs: 13 / 13
- Session Snapshots: 0
- Estimated Runs: 0
- Input Tokens: 443217
- Output Tokens: 182183
- Cached Read Tokens: 958976
- Cached Write Tokens: 0
- Total Tokens: 1584376
- Estimated Tokens (fallback, not in total): 0

### Token Usage By Step

| Node | Agent | Status | Outcome | Source | Input | Output | Transcript | Context | Prompt Overhead | Adapter Overhead | Total |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| intake.claude_brainstorm | claude | completed | SUCCESS | acpx_stream | 16494 | 17243 | 5187 | 991 | 4225 | 11278 | 40137 |
| intake.codex_product_review | codex | completed | SUCCESS | acpx_stream | 19295 | 1230 | 967 | 4820 | 4480 | 9995 | 33453 |
| intake.claude_brainstorm | claude | completed | SUCCESS | acpx_stream | 19908 | 7885 | 2640 | 991 | 8627 | 10290 | 39057 |
| intake.codex_product_review | codex | completed | SUCCESS | acpx_stream | 17457 | 979 | 805 | 4820 | 4924 | 7713 | 50436 |
| intake.claude_brainstorm | claude | completed | SUCCESS | acpx_stream | 19772 | 7582 | 1838 | 991 | 8859 | 9922 | 38874 |
| intake.codex_product_review | codex | completed | SUCCESS | acpx_stream | 12330 | 621 | 561 | 4820 | 5221 | 2289 | 62231 |
| design.claude_design | claude | completed | SUCCESS | acpx_stream | 51933 | 39126 | 10865 | 0 | 3445 | 48488 | 343987 |
| design.codex_arch_review | codex | completed | SUCCESS | acpx_stream | 28584 | 1675 | 1461 | 25582 | 0 | 3571 | 91699 |
| design.claude_design | claude | completed | SUCCESS | acpx_stream | 44258 | 36472 | 11473 | 0 | 12686 | 31572 | 219482 |
| design.codex_arch_review | codex | completed | SUCCESS | acpx_stream | 52072 | 1713 | 1475 | 25582 | 19190 | 7300 | 143641 |
| design.claude_design | claude | completed | SUCCESS | acpx_stream | 45435 | 34887 | 13530 | 0 | 17706 | 27729 | 153986 |
| design.codex_arch_review | codex | completed | SUCCESS | acpx_stream | 72613 | 1314 | 1191 | 25582 | 32613 | 14418 | 215623 |
| design.claude_design | claude | failed | OUTPUT_INCOMPLETE | acpx_stream | 43066 | 31456 | 16252 | 0 | 20816 | 22250 | 151770 |

### Top Context Sections

| Target Node | Profile | Section | Rendered | Original | Degraded | Dropped |
| --- | --- | --- | --- | --- | --- | --- |
| design.codex_arch_review | architecture_review | input_artifacts | 513 | 513 | false | false |
| design.codex_arch_review | architecture_review | human_feedback | 430 | 430 | false | false |
| design.codex_arch_review | architecture_review | iteration_history | 426 | 524 | true | false |
| intake.codex_product_review | product_review | input_artifacts | 422 | 422 | false | false |
| design.codex_arch_review | architecture_review | recent_agent_outputs | 355 | 355 | false | false |
| intake.codex_product_review | product_review | recent_agent_outputs | 202 | 202 | false | false |
| design.codex_arch_review | architecture_review | review_evidence | 181 | 181 | false | false |
| intake.codex_product_review | product_review | review_evidence | 179 | 179 | false | false |
| design.codex_arch_review | architecture_review | ledger_pointers | 161 | 170 | true | false |
| intake.claude_brainstorm | intake | ledger_pointers | 161 | 170 | true | false |

## Tool Metrics

- Tool Calls: 31
- Reads: 31
- Writes: 0
- Bash Commands: 0
- Evidence Files: 0

### Repeated Read Files

| File | Reads | Agents | Nodes | Evidence Known | Reread Reason |
| --- | --- | --- | --- | --- | --- |
| .gitignore | 6 | claude | intake.claude_brainstorm, design.claude_design | false | not_required |
| scripts/verify-workspace.sh | 6 | claude | intake.claude_brainstorm, design.claude_design | false | not_required |
| README.md | 4 | claude | intake.claude_brainstorm, design.claude_design | false | not_required |
| REQUIREMENT.md | 4 | claude | intake.claude_brainstorm, design.claude_design | false | not_required |
| * | 3 | claude | design.claude_design | false | not_required |
| scripts/* | 3 | claude | design.claude_design | false | not_required |
