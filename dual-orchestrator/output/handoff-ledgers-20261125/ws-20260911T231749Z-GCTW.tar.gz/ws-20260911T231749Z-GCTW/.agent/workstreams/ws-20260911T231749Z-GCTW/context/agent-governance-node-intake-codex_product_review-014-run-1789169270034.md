# Agent Run Governance Context

- Workstream: ws-20260911T231749Z-GCTW
- Target Node: intake.codex_product_review
- Agent Node Instance: node-intake-codex_product_review-014
- Run Id: run-1789169270034
- Generated At: 2026-09-11T23:27:50.042984Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-codex_product_review-014-run-1789169270034/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-codex_product_review-014-run-1789169270034/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-codex_product_review-014-run-1789169270034/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-intake-codex_product_review-014-run-1789169270034/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
