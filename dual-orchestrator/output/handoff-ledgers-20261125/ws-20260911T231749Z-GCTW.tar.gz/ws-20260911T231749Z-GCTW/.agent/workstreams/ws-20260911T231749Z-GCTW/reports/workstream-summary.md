# Workstream Summary

- Workstream: ws-20260911T231749Z-GCTW
- Workspace: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW
- Ledger: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW
- Generated At: 2026-09-12T00:07:59.894139Z

## Workflow

- Definition: agent-lifecycle-small-plan-human-review-experiment@1
- Status: WAITING_FOR_RECOVERY
- Status Source: workflow_current
- Active Nodes: node-design-claude_design-036
- Open Gates: recovery-node-design-claude_design-036
- Updated At: 2026-09-12T00:07:59.875288Z

## Metrics

- Nodes: 32
- Agent Runs: 13
- Gates: 5
- Decisions: 6
- Iterations: 6
- Revisions: 5
- Total Node Duration(ms): 2513250
- Token Runs: 13 / 13
- Total Tokens: 1584376 (input 443217, output 182183)
- Metrics: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/metrics/workstream-metrics.md

## Recommended Next Action

Agent output incomplete

The final ACP assistant message did not contain a valid AgentResultEnvelope.

Inspect the agent output contract, then retry the same active node.

```bash
dualctl recovery show --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW' ws-20260911T231749Z-GCTW
dualctl retry --workdir /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW ws-20260911T231749Z-GCTW
```

## Recent Timeline

| Node | Kind | Status | Iteration | Duration |
| --- | --- | --- | --- | --- |
| gate.human_design_approval | GATE | COMPLETED | iter-003 |  |
| design.claude_design | TASK | COMPLETED | iter-004 | 460148 |
| context.design_codex_arch_review | TASK | COMPLETED | iter-004 | 54 |
| design.codex_arch_review | TASK | COMPLETED | iter-004 | 56128 |
| design.decision | DECISION | COMPLETED | iter-004 | 19 |
| gate.human_design_approval | GATE | COMPLETED | iter-004 |  |
| design.claude_design | TASK | COMPLETED | iter-005 | 396592 |
| context.design_codex_arch_review | TASK | COMPLETED | iter-005 | 58 |
| design.codex_arch_review | TASK | COMPLETED | iter-005 | 50615 |
| design.decision | DECISION | COMPLETED | iter-005 | 20 |
| gate.human_design_approval | GATE | COMPLETED | iter-005 |  |
| design.claude_design | TASK | FAILED | iter-006 | 361293 |

## Artifacts

- Final Report: missing
- Current Failure Summary: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/recovery/current-failure.md
- Delivery: BLOCKED, changedFiles=0, target=/Users/kriswang/work/projects/ai/okx-btc-k-line-demo, reason=WORKFLOW_NOT_DELIVERABLE:workstream is not completed: WAITING_FOR_RECOVERY
- Calibration Candidates: 0
- Calibration Apply Plans: 0

## Useful Commands

```bash
dualctl status --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW' ws-20260911T231749Z-GCTW
dualctl timeline --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW' ws-20260911T231749Z-GCTW
dualctl review show --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW' ws-20260911T231749Z-GCTW
dualctl recovery show --workdir '/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW' ws-20260911T231749Z-GCTW
```
