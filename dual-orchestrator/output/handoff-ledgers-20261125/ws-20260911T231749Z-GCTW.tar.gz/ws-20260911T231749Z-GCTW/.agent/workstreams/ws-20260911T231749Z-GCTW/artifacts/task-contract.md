# Task Contract

## Objective

交付一个 Java 25 + Spring Boot 4.1.0 本地 Web 应用：直连 OKX 官方公开行情 REST API 拉取 BTC-USDT 现货 1m K 线，经 MyBatis-Plus 幂等持久化到 SQLite，前端以本地打包图表库展示可定时刷新的真实蜡烛图与成交量，并以离线自动化测试加显式 live smoke 完成验证。

## Scope

**Included:**
- MODIFY: .gitignore
- MODIFY: README.md
- CREATE: pom.xml
- CREATE: scripts/live-smoke.sh
- MODIFY: scripts/verify-workspace.sh
- CREATE: src/main/java/com/example/okxkline/OkxKlineApplication.java
- CREATE: src/main/java/com/example/okxkline/config/OkxSyncProperties.java
- CREATE: src/main/java/com/example/okxkline/domain/Kline.java
- CREATE: src/main/java/com/example/okxkline/okx/OkxMarketClient.java
- CREATE: src/main/java/com/example/okxkline/okx/CandleRowParser.java
- CREATE: src/main/java/com/example/okxkline/entity/KlineEntity.java
- CREATE: src/main/java/com/example/okxkline/mapper/KlineMapper.java
- CREATE: src/main/java/com/example/okxkline/mapper/SyncStateMapper.java
- CREATE: src/main/java/com/example/okxkline/sync/KlineSyncService.java
- CREATE: src/main/java/com/example/okxkline/sync/SyncStateService.java
- CREATE: src/main/java/com/example/okxkline/web/MarketController.java
- CREATE: src/main/java/com/example/okxkline/web/GlobalExceptionHandler.java
- CREATE: src/main/resources/application.yml
- CREATE: src/main/resources/db/migration/V1__init_kline_schema.sql
- CREATE: src/main/resources/static/index.html
- CREATE: src/main/resources/static/app.js
- CREATE: src/main/resources/static/styles.css
- CREATE: src/main/resources/static/vendor/klinecharts.min.js
- CREATE: src/test/java/com/example/okxkline/okx/CandleRowParserTest.java
- CREATE: src/test/java/com/example/okxkline/okx/OkxMarketClientTest.java
- CREATE: src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java
- CREATE: src/test/java/com/example/okxkline/sync/SchedulerOverlapTest.java
- CREATE: src/test/java/com/example/okxkline/persistence/KlinePersistenceTest.java
- CREATE: src/test/java/com/example/okxkline/web/MarketControllerTest.java
- CREATE: src/test/java/com/example/okxkline/web/ChartPageDomTest.java
- CREATE: src/test/java/com/example/okxkline/support/StubOkxServer.java
- CREATE: src/test/java/com/example/okxkline/smoke/OkxLiveSmokeIT.java
- CREATE: src/test/resources/fixtures/okx/candles-normal.json
- CREATE: src/test/resources/fixtures/okx/candles-reversed.json
- CREATE: src/test/resources/fixtures/okx/candles-unconfirmed.json
- CREATE: src/test/resources/fixtures/okx/candles-malformed-row.json
- CREATE: src/test/resources/fixtures/okx/envelope-error.json

**Excluded:**
- REQUIREMENT.md（需求权威来源，保持原样不改）
- .git/**、.agent/** 以及有效工作区之外的任何路径
- 任何 WebSocket 行情、交易、账户或私有 OKX API 相关代码
- 运行时 CDN 资源或任何外链前端依赖

## Acceptance Criteria

- [ ] 在 Java 25 环境下于仓库根目录执行 `mvn test` 全部通过，且测试运行期间不向公网 OKX（www.okx.com 等）发起任何网络请求。
- [ ] 默认配置（同步开启）启动应用后：启动即回填调用 `GET {okx.base-url}/api/v5/market/candles?instId=BTC-USDT&bar=1m` 拉取并保存最近 300 根 K 线，随后默认每 15 秒轮询一次；OKX base URL、连接/读取超时、调度开关与刷新周期均可经 application.yml 或环境变量外部配置；全程不需要 API Key 或 OKX 账户。
- [ ] `GET /api/klines?limit=N` 按开盘时间升序返回最近最多 300 根已保存 K 线；limit 缺省时使用默认值，非法值（非正整数或超过 300）返回 400 与明确的客户端错误信息。
- [ ] `GET /api/sync/health` 返回当前生命周期状态（如 ok/degraded）、最近一次尝试时间、最近一次成功时间和有界且脱敏的失败摘要；失败摘要文本仅是展示元数据，不反向决定状态机取值。
- [ ] SQLite 表对 (instrument, bar, open_time) 建立唯一约束；重复同步幂等；confirm=0 的未闭合 K 线在后续轮次原位更新（含闭合为 confirm=1 后的最新值）；应用重启后已闭合 K 线仍可经 API 查询；价格与成交量在 Java 侧为 BigDecimal、SQLite 侧为 TEXT 等 decimal-safe 表示。
- [ ] 对超时、非 2xx、429 限流、OKX 业务错误（code 不为 "0"）、非法 JSON、非法行以及乱序/陈旧响应，同步仅执行幂等 upsert、绝不执行删除：任何响应（含按时间倒序返回或命中较旧缓存的响应）都不得删除本地已保存的 K 线，本地 open_time 晚于该响应所含最晚开盘时间的 K 线必须原样保留；价格或成交量数值的大小与涨跌方向不得作为接受或拒绝某行更新的条件。同一 (instrument, bar, open_time) 的响应新旧判定仅使用响应行自身已声明的字段：依据 REQUIREMENT.md 的 OKX 契约，confirm=0 表示未闭合、后续允许更新，confirm=1 表示已闭合，接口未声明任何版本号或序号，因此不假设存在未声明的版本信息，也不得仅由“已经闭合”推导出任何字段永久不可修正。具体规则为：已存行为 confirm=0 时，按最近一次成功校验响应中同 open_time 的行原位更新（含最终闭合为 confirm=1 及其最新价格与成交量，保持 AC-5 的未闭合 K 线原位更新语义）；已存行为 confirm=1 时，后续同键的合法 confirm=1 行仍执行幂等 upsert，闭合价格与成交量以最近一次成功校验的响应为准更新，不得仅因该行已经闭合而拒绝或跳过该更新；唯一禁止的回退是 confirm 状态由 1 变为 0：对已存 confirm=1 的行，后续 confirm=0 的行（如命中较旧缓存的响应）不得将其重新标记为未闭合，也不得以未闭合值覆盖其闭合值，该行既有闭合数据保持原样。envelope 或任一行校验失败时该轮整体不写入并置 degraded；失败后无无界立即重试，等待下一轮调度；单实例内不出现重叠调度执行。
- [ ] 浏览器访问首页即进入行情界面（非营销落地页）：以本地打包的 KLineCharts 资源渲染真实蜡烛图与成交量，展示 BTC / USDT、1m、最新收盘价、最近闭合 K 线时间、同步状态和最近成功刷新时间；默认每 10 秒增量刷新且不整页重载；同步 degraded 或后端失败时保留最后可用图表并显示克制清晰的状态；首次加载与无数据状态有明确提示；桌面和移动视口下文字、图表、操作不重叠；页面网络请求仅指向本应用后端，无模拟价格冒充 OKX 实时行情，无运行时 CDN 依赖。
- [ ] README.md 完整记录架构、配置项（OKX base URL、超时、调度开关、刷新周期、SQLite 路径）、启动方式、`mvn test` 的离线性、live smoke 命令、后端 API 契约、数据新鲜度语义（confirm=0/1 含义、最新收盘价可能滞后于 OKX 实时）与已知限制。
- [ ] `scripts/live-smoke.sh` 为显式 opt-in 命令，直连 OKX 官方公开接口发起一次只读请求并校验至少一根结构合法（9 字段、confirm 取值 0/1）的 BTC-USDT 1m K 线；该命令不在默认 `mvn test` 中执行。
- [ ] 交付后 `scripts/verify-workspace.sh` 的断言与实现状态一致：改为校验 pom.xml 与 src 存在、保留 Java 25 校验与只读 OKX 探测，不再因基线断言 `test ! -e pom.xml`、`test ! -d src` 而必然失败。

## Test Requirements

- OkxMarketClientTest 与 KlineSyncServiceTest 使用本地契约一致的 HTTP stub（StubOkxServer）与冻结 fixture 覆盖：正常 envelope、倒序行输入、重复同步幂等、未闭合 K 线 confirm=0 到 1 的原位更新、陈旧/旧缓存响应不删除较新本地数据、非法 envelope（code 非 "0"）、非法行（字段数/类型/confirm 非法）、HTTP 超时（不回包 socket policy）、非 2xx、429、非法 JSON；断言每轮合法 K 线在单事务内原子 upsert（失败轮零写入）、失败进入 degraded 且无立即重试、已有数据保留。
- KlinePersistenceTest 使用临时 SQLite 文件数据库：验证 (instrument, bar, open_time) 唯一约束生效、upsert 幂等、以及模拟重启（新建 ApplicationContext 复用同一数据库文件）后已闭合 K 线仍可查询。
- MarketControllerTest 覆盖后端 API：K 线按 open_time 升序与最多 300 条上限、limit 默认值与非法值返回 400、/api/sync/health 字段完整性、同步失败后 K 线接口仍返回既有数据。
- SchedulerOverlapTest 以响应时长超过轮询周期的慢速 stub 验证同一时刻仅有一个同步执行（fixedDelay 调度加单线程执行器加显式并发守卫），不出现重叠。
- CandleRowParserTest 验证 `[ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]` 行格式解析与校验规则、BigDecimal decimal-safe 转换、ts 为 Unix 毫秒开盘时间与 confirm 0/1 语义。
- ChartPageDomTest 以浏览器级验证（Playwright for Java，仅测试期依赖）加载将 OKX 指向本地 stub 的应用实例：断言图表 DOM/canvas 渲染消费本应用 /api 数据、默认 10 秒定时刷新不触发整页导航、页面全部网络请求仅命中本应用源（无 okx.com 与任何 CDN 请求）。
- OkxLiveSmokeIT 仅经 `-Plive-smoke` Maven profile 激活（由 scripts/live-smoke.sh 调用），直连 OKX 官方公开接口只读一次并校验至少一根结构合法的 BTC-USDT 1m K 线；默认 surefire/test 配置显式排除该测试，保证其不进入默认 `mvn test`。
- 全部自动化测试仅使用本地 stub 与仓库内冻结 fixture，不含任何对公网 OKX 的调用，可在无外网环境通过；Playwright 浏览器二进制经构建期获取或预置本地路径并在 README 记录获取方式，不构成应用运行时 CDN 依赖。
- 首次启动回填自动化验证：在 src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java 中，以本地契约一致的 StubOkxServer 提供冻结的 300 根 BTC-USDT 1m K 线响应（fixture 为 src/test/resources/fixtures/okx/candles-normal.json，含 300 行冻结数据），配合临时 SQLite 数据库与同步开启的配置启动真实应用上下文（OKX base URL 指向 stub），断言应用启动后自动触发一次 GET /api/v5/market/candles 回填请求并将该 300 根 K 线全部持久化（保存行数为 300、open_time 与 fixture 一致且可按升序查询）；该用例必须验证由应用启动流程触发的初始回填，而非直接调用同步方法。
- 在 src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java 中以本地契约一致的 StubOkxServer 与冻结 fixture 补充闭合行更新语义验证（复用已授权文件，无需新增路径）：已存 confirm=1 的 K 线收到后续同 (instrument, bar, open_time) 的合法 confirm=1 行时，必须按幂等 upsert 接受并更新闭合价格与成交量，不得因已闭合而拒绝或跳过；已存 confirm=1 的 K 线收到后续 confirm=0 的行时，不得将 confirm 由 1 回退为 0、不得以未闭合值覆盖闭合值，该行既有闭合数据保持不变；两种场景下任何本地已保存 K 线均不得被删除。

## Constraints

- 技术栈锁定：Java 25、Spring Boot 4.1.0、Maven、MyBatis-Plus 3.5.17 且必须引入 `mybatis-plus-spring-boot4-starter`；禁止 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施；SQLite 是唯一应用数据库。
- 数据源锁定：仅 OKX 官方公开 Market Data REST `GET /api/v5/market/candles`（instId 固定 BTC-USDT 现货、bar 固定 1m），不得抓取 HTML 页面；生产运行与显式 live smoke 必须直连 OKX 官方 API，不得经测试桩、代理业务服务或抓取服务替代。
- OKX base URL、连接超时、读取超时、同步调度开关与刷新周期必须支持外部配置（application.yml 加环境变量覆盖）；默认每 15 秒轮询、启动回填最近 300 根、无需 API Key。
- 数据库初始化采用版本化迁移脚本（src/main/resources/db/migration/V1__init_kline_schema.sql，经 Flyway 确定执行），禁止在业务代码中临时拼接建表流程；schema 含 (instrument, bar, open_time) 唯一约束与同步状态表。
- decimal-safe：Java 侧价格与成交量一律使用 BigDecimal，SQLite 侧以 TEXT 存储十进制字符串，禁止以 float/double 或 SQLite REAL 作为权威值。
- 同步引擎语义：每轮先完整解析并校验 OKX envelope 再写库；同一响应中的合法 K 线在单事务内 upsert；任何失败（超时、非 2xx、业务错误、限流、非法 JSON、非法行、数据库异常）不得删除已有 K 线、不得无界立即重试，置 degraded 等待下一轮；单应用实例内调度不重叠；同步状态由显式生命周期字段管理，错误文本仅为有界摘要。
- 日志只记录必要运行元数据（状态、耗时、行数、错误类别），失败时不得打印完整 OKX 响应正文。
- 前端使用成熟 K 线图表库（KLineCharts）并将生产资源随应用打包到 src/main/resources/static/vendor，运行时零 CDN 零外链；浏览器只调用本应用后端 API，不直接请求 OKX。
- 默认 `mvn test` 不得依赖公网 OKX 可用性，外部行为差异一律以本地契约一致 stub 与冻结 fixture 呈现；live smoke 仅经显式 opt-in 命令执行且不得进入默认测试。
- 所有仓库改动仅限 scope.included 声明的文件，不写 .git、.agent 或工作区外路径。

## Non-Goals

- 交易、账户访问、认证、API Key、余额或任何私有 OKX API。
- 投资建议、告警、策略、技术指标或预测。
- WebSocket 行情。
- 多交易品种或多周期切换（仅 BTC-USDT 1m）。
- 分布式调度或多实例协调（仅保证单实例内不重叠）。
- 用户账户或管理后台。
- 通用交易所抽象或行情平台化。
- 运行时 CDN 依赖。

## Risk Areas

- Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的兼容矩阵需在实现首日经依赖解析与最小上下文测试验证；若存在装配缺口，需在约束不变前提下调整启动装配方式。
- Playwright for Java 需要构建期浏览器二进制；若构建环境禁外网，需按 TR-8 以预置本地二进制路径解决，否则 DOM 级验证无法执行。
- live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 `mvn test`。
- SQLite 单写者特性下调度写事务与 API 读并发可能遇到 BUSY；以短事务、单连接池与 WAL 模式缓解，需在实现中确认。
- vendored KLineCharts 版本需固定并在 README 记录，避免后续无意识升级引入行为漂移。

## Evidence References

- REQUIREMENT.md
- README.md
- scripts/verify-workspace.sh
- .gitignore

## Source

- **Created by:** task_contract_proposal
- **Raw request:** .agent/workstreams/ws-20260911T231749Z-GCTW/requirement.md

