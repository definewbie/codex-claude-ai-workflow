# Contract Failure Diagnostic

- Category: malformed_agent_result
- Reason: AGENT_RESULT_CONTRACT_VIOLATION
- Node: design.claude_design
- Node Instance: node-design-claude_design-036
- Source Output: .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789171318596/outputs/design-claude.json
- Recommended Owner: agent_or_prompt

## Message

AgentResultEnvelope failed contract validation: [AUTHORED_RESPONSE_ID_INVALID]

## Recovery Hint

Repair the final AgentResultEnvelope JSON so it matches the node contract and contains no Markdown or trailing prose.

## Contract Shape

- Required Keys: [decision, summary]
- Allowed Decisions: [READY_FOR_ARCH_REVIEW]
