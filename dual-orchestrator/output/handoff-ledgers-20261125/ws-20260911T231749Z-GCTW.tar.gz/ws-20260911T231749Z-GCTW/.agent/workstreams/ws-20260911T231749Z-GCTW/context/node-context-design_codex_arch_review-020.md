# Context Package

- Workstream: ws-20260911T231749Z-GCTW
- Builder Node: context.design_codex_arch_review
- Target Node: design.codex_arch_review
- Generated At: 2026-09-11T23:40:46.820822Z
- Profile: architecture_review
- Total: 5.0k / 5.0k tokens

## Context Governance

| Section | Level | Degraded | Original | Current |
|---|---|---|---|---|
| input_artifacts | full | no | 501 | 501 |
| review_evidence | full | no | 181 | 181 |
| human_feedback | full | no | 134 | 134 |
| iteration_history | full | no | 152 | 152 |
| recent_agent_outputs | full | no | 343 | 343 |
| ledger_pointers | pointer_only | yes | 170 | 161 |
| required_architecture_review_subject | full | no | 3.5k | 3.5k |

Degraded sections have full data at their original paths listed below.

## State & Evidence Boundary

This package separates deterministic harness facts from agent proposals.

### Trusted Harness Facts

- TaskContract: READY_FOR_REVIEW - 交付一个 Java 25 + Spring Boot 4.1.0 本地 Web 应用：直连 OKX 官方公开行情 REST API 拉取 BTC-USDT 现货 1m K 线，经 MyBatis-Plus 幂等持久化到 SQLite，前端以本地打包图表库展示可定时刷新的真实蜡烛图与成交量，并以离线自动化测试加显式 live smoke 完成验证。 (.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/task-contract.json)
- Git Evidence: not generated yet

### Human Decisions

- Requirement Resolution: APPROVE by human_gate (.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/contract-resolution.json)

### Agent Proposed States

- design.claude_design: decision=READY_FOR_ARCH_REVIEW, stageOutcome=READY, evidenceState={blocking=false, evidence_count=14, missing_evidence_count=0, must_fix_count=0, acceptance_note_count=0, open_risk_count=5} (/Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.contract.json)

### Pending Contract/Evidence Gaps

- No contract failure diagnostics recorded

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Repo map: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-020/repo-map.json
- Repository fact binding: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-020/binding.json
- Tracked inventory: count=0; head=; sha256=

- File relevance plan: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-020/file-relevance-plan.json
- Stage scope policy: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-020/stage-scope-policy.json
- Workstream memory: .agent/workstreams/ws-20260911T231749Z-GCTW/memory/workstream-memory.json
- Working set: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-020/working-set.json
- File summaries: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-020/file-summaries.json
- Read reuse contract: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-020/read-reuse-contract.json
- Agent capability catalog: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-020/agent-capability-catalog.json
- Governance report: .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-020/planned-report.json

- Recommended read files:
  - .gitignore
  - README.md
  - pom.xml
  - scripts/live-smoke.sh
  - scripts/verify-workspace.sh
  - src/main/java/com/example/okxkline/OkxKlineApplication.java
  - src/main/java/com/example/okxkline/config/OkxSyncProperties.java
  - src/main/java/com/example/okxkline/domain/Kline.java
- Contract scope candidates:
  - .gitignore
  - README.md
  - pom.xml
  - scripts/live-smoke.sh
  - scripts/verify-workspace.sh
  - src/main/java/com/example/okxkline/OkxKlineApplication.java
  - src/main/java/com/example/okxkline/config/OkxSyncProperties.java
  - src/main/java/com/example/okxkline/domain/Kline.java
  - src/main/java/com/example/okxkline/okx/OkxMarketClient.java
  - src/main/java/com/example/okxkline/okx/CandleRowParser.java
  - src/main/java/com/example/okxkline/entity/KlineEntity.java
  - src/main/java/com/example/okxkline/mapper/KlineMapper.java
- Allowed write files: (none planned)
- Forbidden scope:
  - .git/**
  - .agent/workstreams/**/workflow/**
  - .agent/workstreams/**/nodes/**
  - business source writes
- Already inspected files:
  - .gitignore
  - README.md
  - REQUIREMENT.md
  - scripts/verify-workspace.sh
  - {pom.xml,scripts/*,REQUIREMENT.md,src/**}
- Read reuse contract: the following files were already inspected and their recorded sha is still trusted. Reuse the summary first; re-read only if you need exact current contents for editing or verification.
  - .gitignore: Previously read source file (105 bytes).
  - README.md: headings: OKX BTC K 线演示应用 | relevant: 产品需求以 `REQUIREMENT.md` 为权威来源。实现必须由唯一 fresh workstream 完成，并严格使用 Java 25、Spring Boot 4.1.0、MyBatis-Plus 3.5.17 和 SQLite。; 冻结基线中没有产品代码或构建文件。生产应用与显式 live smoke 必须直接调用 OKX 官方公开 API；只有确定性自动化测试可以使用本地协议桩模拟超时、限流、乱序和畸形响应。
  - REQUIREMENT.md: headings: OKX BTC 分钟级 K 线 Web 应用需求; 目标; 强制技术栈; OKX 行情契约; 数据持久化 | relevant: 构建一个本地 Web 应用，通过 OKX 官方公开行情 REST API 获取 BTC-USDT 现货分钟级 K 线，将数据持久化到 SQLite，并展示可定时刷新的 K 线图。; 提供稳定 JSON API：; 1. 查询最近最多 300 根已保存 K 线，按开盘时间升序返回。; 非法 limit 必须返回明确的客户端错误。浏览器只能调用本应用后端，不得直接请求 OKX。
  - scripts/verify-workspace.sh: Previously read source file (1255 bytes).
  Do not re-read these files unless this stage needs exact current contents; this target artifact does not declare a reread reason field, so the harness will judge re-reads from changed_files, invalidation, and allowed-reread policy.
- Read reuse rule: use existing evidence before re-reading files already inspected in this workstream.
- Re-read a listed file only when this stage needs fresh contents; record the reason in the structured artifact.
- Repeated-read risk:
  - .gitignore (previous reads: 3, evidence known: false)
  - README.md (previous reads: 3, evidence known: false)
  - scripts/verify-workspace.sh (previous reads: 3, evidence known: false)
Read recommendations are context only. Declared edits must match TaskContract.scope and are verified from Git evidence.

## Input Artifacts

### .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.stderr.log

(execution diagnostic omitted from context)

### .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.transcript.log

(execution transcript omitted from context; inspect raw file at /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.transcript.log)

### .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.json

- Contract: design.claude_design
- Decision: READY_FOR_ARCH_REVIEW
- Summary: 围绕 confirm 语义的单语句幂等 upsert、fixedDelay 单飞调度与全离线测试矩阵的实现就绪设计，planned_files 与已批准 scope 逐项对齐。
- Open Risks: Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的坐标解析与装配需实现首日以最小上下文验证（契约 Risk Area 1）；若 Flyway SQLite 需附加模块坐标，仅修改已授权 pom.xml。; Hikari data-source-properties 传递 xerial pragma（journal_mode/busy_timeout）的键名绑定需首日验证；备选为 JDBC URL 参数或 yml 显式键，不影响语义。; Playwright for Java 浏览器二进制需构建期获取或预置本地路径（TR-8/README 记录）；离线构建环境缺二进制时 ChartPageDomTest 无法执行，属环境准备项而非设计缺口。; live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 mvn test。; vendored KLineCharts 具体版本在实现时锁定（9.x UMD）并写入 README，避免后续无意识升级引入行为漂移。
- Verification: 本阶段仅产出实现就绪设计：已核对 TaskContract、REQUIREMENT.md 与基线仓库文件，planned_files 与批准 scope 完全一致；未执行任何代码实现、构建或测试运行。
- Contract Sidecar: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.contract.json
- Raw Output: .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.json

### .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-claude_design-019-run-1789169462819/binding.json

(routed artifact has no typed context projection; content omitted)

## Review Evidence Brief

TaskContract projection: qualified_projection

No cumulative review verdict recorded. Review the complete current subject against the contract baseline.

- Relevant memory (reuse, do not re-read): .gitignore; README.md; REQUIREMENT.md; scripts/verify-workspace.sh

Derive the complete current blocker set from the review subject and acceptance criteria; re-read a file only with a reason (edit/verify/sha-changed/stage-gap).
Evidence: memory .agent/workstreams/ws-20260911T231749Z-GCTW/memory/workstream-memory.json; diff .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/git-evidence/diff.patch; changed .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/git-evidence/changed-files.txt.

## Human Feedback

### gate.contract_review

- Action: approved
- Finished At: 2026-09-11T23:31:02.499156Z

```text
已机械比对编译合同与本轮已批准提案的objective、scope、acceptance_criteria、test_requirements、constraints、non_goals、evidence_refs全等，合同与resolution SHA均匹配compile来源。批准该合同进入设计；后续设计、计划与实际修改须保持当前批准身份，测试和验收仍独立进行。
```

### gate.human_requirement_review

- Action: approved
- Finished At: 2026-09-11T23:29:29.799127Z

```text
已核对本轮完整提案、原REQUIREMENT与两轮修订来源，CO-1/CO-2已收敛，按当前提案身份批准进入合同编译。保持需求业务范围和37项文件授权；依赖兼容、浏览器和真实API仍须实际验证，本次不是实现或验收通过。不新增手机图标要求。
```

## Iteration History

### iter-003

- Parent: iter-002
- Trigger: NEEDS_REVISION
- Target Node: intake.claude_brainstorm
- Created At: 2026-09-11T23:26:18.017993Z

```text
首次回填测试已补齐，但 AC-6 新增的闭合数据永久不可更新规则超出了已声明的行情契约。
```

### iter-002

- Parent: iter-001
- Trigger: NEEDS_REVISION
- Target Node: intake.claude_brainstorm
- Created At: 2026-09-11T23:23:54.859410Z

```text
提案总体覆盖产品目标，但需澄清陈旧响应语义并补齐首次回填的自动化验证要求。
```

### iter-001

- Parent: (none)
- Trigger: workflow_started
- Target Node: context.intake_claude_brainstorm
- Created At: 2026-09-11T23:17:49.404227Z

```text
Initial workflow iteration.
```

## Recent Agent Outputs

### /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.contract.json

- Contract: design.claude_design
- Decision: READY_FOR_ARCH_REVIEW
- Summary: 围绕 confirm 语义的单语句幂等 upsert、fixedDelay 单飞调度与全离线测试矩阵的实现就绪设计，planned_files 与已批准 scope 逐项对齐。
- Open Risks: Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的坐标解析与装配需实现首日以最小上下文验证（契约 Risk Area 1）；若 Flyway SQLite 需附加模块坐标，仅修改已授权 pom.xml。; Hikari data-source-properties 传递 xerial pragma（journal_mode/busy_timeout）的键名绑定需首日验证；备选为 JDBC URL 参数或 yml 显式键，不影响语义。; Playwright for Java 浏览器二进制需构建期获取或预置本地路径（TR-8/README 记录）；离线构建环境缺二进制时 ChartPageDomTest 无法执行，属环境准备项而非设计缺口。; live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 mvn test。; vendored KLineCharts 具体版本在实现时锁定（9.x UMD）并写入 README，避免后续无意识升级引入行为漂移。
- Verification: 本阶段仅产出实现就绪设计：已核对 TaskContract、REQUIREMENT.md 与基线仓库文件，planned_files 与批准 scope 完全一致；未执行任何代码实现、构建或测试运行。
- Contract Sidecar: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.contract.json
- Raw Output: .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.json

## Ledger Pointers

- Events: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/events.jsonl
- Workflow current: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/workflow/current.json
- Node state directory: /Users/kriswang/work/proj

[adaptively compressed; section degraded to stay within ~125 tokens; full source remains in ledger under /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW]

## Required Architecture Review Subject

- Contract: design.claude_design
- Decision: READY_FOR_ARCH_REVIEW
- Summary: 围绕 confirm 语义的单语句幂等 upsert、fixedDelay 单飞调度与全离线测试矩阵的实现就绪设计，planned_files 与已批准 scope 逐项对齐。
**Checks:**
- 已通读已批准 TaskContract tc-ws-20260911T231749Z-GCTW-v1（human gate 016 APPROVE）、REQUIREMENT.md 与基线 README.md、.gitignore、scripts/verify-workspace.sh；当前为空基线（无 pom.xml、无 src/），交付物均为新建或对三个基线文件的窄修改。
- planned_files 与 scope.included 37 项（3 MODIFY + 34 CREATE）路径与操作逐字一致，无越权路径；REQUIREMENT.md、.git/、.agent/ 与工作区外路径不触碰。
- AC-1..AC-10 与 TR-1..TR-10 逐条映射到具体文件、fixture 与断言（见 evidence），约束 C-1..C-10 逐条满足。
- 生命周期-正常完成：ApplicationReadyEvent 启动回填，每轮 获取→完整解析校验 envelope 与全部行→短事务逐行 upsert→recordSuccess(OK,lastSuccessAt)；/api/klines 与 /api/sync/health 即时反映已提交结果。
- 生命周期-并发：单实例三重防重叠（@Scheduled fixedDelay 从上次结束计时 + spring.task.scheduling.pool.size=1 + AtomicBoolean 在飞守卫 try/finally 释放；启动回填与定时轮共用 syncOnce 同受守卫保护）；DB 层 Hikari maximum-pool-size=1 串行化；跨实例协调为契约非目标，不适用。
- 生命周期-超时/提供方失败：TIMEOUT、HTTP_STATUS、RATE_LIMITED、BUSINESS_ERROR、MALFORMED_RESPONSE、MALFORMED_ROW、DATABASE 归一为该轮失败——解析期失败零写入，写库期失败事务回滚；置 DEGRADED 记有界摘要；无立即重试，唯一恢复路径是下一轮 fixedDelay；失败路径无 DELETE。
- 生命周期-中断/崩溃：未提交事务由 SQLite journal/WAL 回滚，库中只存在完整轮次；对 OKX 仅只读 GET、无外部写副作用、无需补偿；崩溃时 sync_state 至多滞后一轮，下一轮自愈。
- 生命周期-重启/恢复：Flyway 迁移幂等跳过；启动回填重跑为幂等 upsert；sync_state 持久化最近尝试/成功/失败；已闭合 K 线跨重启可查（KlinePersistenceTest 以同一文件新建 ApplicationContext 验证）。
- 生命周期-回滚/冲突：行键冲突是 ON CONFLICT 正常路径而非错误；唯一约束兜底且经直插重复键用例证明不可绕过；DB 异常经 TransactionTemplate 整体回滚、失败轮零写入（注入式失败 mapper 代理验证）。
- cannot-bypass 测试映射：调度不重叠（SchedulerOverlapTest 并发峰值=1）；任何失败不删除数据（KlineSyncServiceTest 失败矩阵断言行数不减）；confirm 1→0 不可回退不可覆盖（TR-10b）；非法 limit 返回 400（MarketControllerTest）；浏览器不出站、无 CDN（ChartPageDomTest 全量网络断言）；smoke 不进默认 mvn test（surefire 排除 + 脚本）。
- 不适用边界声明：缓存（未引入，本地读无缓存）、队列（无异步队列）、分布式锁（非目标）、对外系统的写副作用补偿（OKX 仅只读 GET）。
- 未新增平台能力：无重试框架、无内存缓存、无额外线程池；失败后唯一恢复路径为下一轮调度；MyBatis-Plus mapper 是唯一持久化通道（无 JPA/JdbcTemplate/平行 repository，SyncStateMapper 亦是同一 SqlSessionFactory 下的 MyBatis 注解 mapper）。
- 测试离线性由构造保证：自动化测试仅连本地 StubOkxServer 与冻结 fixture，生产代码默认 base-url 仅在显式 live smoke 中使用。

**Evidence:**
- 架构分层：okx 层（OkxMarketClient+CandleRowParser：HTTP+envelope+行校验）→ sync 层（KlineSyncService 调度/事务/守卫 + SyncStateService 状态）→ mapper 层（MyBatis-Plus 唯一持久化通道）→ web 层（MarketController JSON API + 同源静态前端）；浏览器仅访问本应用，唯一出站流量是服务端到 OKX 的只读 GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300。
- AC-6 核心语义收敛为 KlineMapper 单条 upsert SQL：INSERT ... ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 各行情字段=excluded.对应字段, confirm=excluded.confirm, updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0——0→0/0→1/1→1 均取最近一次成功校验响应值（含闭合行价格与成交量更新），唯一被禁止的 1→0 因 WHERE 不触发而整行保持原状；全链路无 DELETE；新旧判定只用行内声明的 confirm，不读价格大小/方向，不假设未声明的版本号，且本地晚于响应最晚 open_time 的行因根本不在冲突键内而原样保留。
- 解析先于写入：每轮先完整解析校验 envelope（HTTP 2xx、JSON 合法、code=='0'、data 为数组）与全部行（任一非法即抛分类异常、零 DB 写），随后 TransactionTemplate 短事务内循环 mapper.upsertOne（事务仅包 DB 写、绝不包 HTTP 调用）；同一响应重复 open_time 由循环 upsert 确定性后写覆盖。
- 调度设计：@Scheduled(fixedDelayString 与 initialDelayString 均取 okx.sync.fixed-delay，默认 15s) + 启动回填经 ApplicationReadyEvent；fixedDelay 语义（上次结束才计时）+ 单线程调度器 + AtomicBoolean 守卫三层防重叠；okx.sync.enabled=false 时两个入口直接返回，无调度副作用。
- 状态机：sync_state 单行（V1 迁移种子 PENDING 行 id=1）；状态集合 PENDING/OK/DEGRADED/DISABLED 仅由轮次结果的分类枚举驱动；last_error_summary 为≤200 字符白名单摘要（HTTP 只记状态码、业务错误只记 code+截断 msg、其余记异常类别），响应正文绝不入库/入日志；错误文本仅是展示元数据，不参与状态判定。
- decimal-safe 链路：OKX 十进制字符串 → BigDecimal（parser）→ KlineEntity String(toPlainString) → SQLite TEXT → 读取经 BigDecimal 构造 → API 以 Jackson WRITE_BIGDECIMAL_AS_PLAIN 输出 JSON 数值；全程无 float/double/REAL；实体用 String 承载 TEXT 列是存储编码选择，规避 xerial ResultSet.getBigDecimal 对 TEXT 列的不确定行为，且不引入未授权的 TypeHandler 文件。
- SQLite 并发：Hikari maximum-pool-size=1 串行化读写 + WAL + busy_timeout=5000 + 短事务，缓解单写者 BUSY（契约 Risk Area 4）；读路径为本地毫秒级查询，不引入缓存。
- 版本化初始化：建表唯一入口 db/migration/V1__init_kline_schema.sql（Flyway）——kline 表含 UNIQUE(instrument,bar,open_time) 与 confirm CHECK(0/1)、价格/成交量 TEXT、open_time INTEGER 毫秒；sync_state 表含 state CHECK 与时间/错误字段；业务代码零 DDL。
- API 契约：GET /api/klines?limit=N（缺省 300；非正整数或>300 → 400 与明确错误信息；升序、最多 300、行含 openTime/o/h/l/c/vol/volCcy/volCcyQuote/confirmed）；GET /api/sync/health（state/lastAttemptAt/lastSuccessAt/lastErrorCategory/lastErrorSummary）；GlobalExceptionHandler 统一 400/500 JSON，不泄漏内部细节。
- 前端：index.html+app.js+styles.css+vendor/klinecharts.min.js 全部同源打包零 CDN；加载即拉取 /api/klines 与 /api/sync/health，KLineCharts 渲染蜡烛+VOL 成交量（timestamp 毫秒转秒）；setInterval 10 秒 applyNewData 不整页重载；degraded/后端失败保留旧图+克制状态条；无数据与首次加载提示；最新收盘价取最后一根（可能未闭合、滞后一个同步周期，README 明示），最近闭合 K 线时间取最后一根 confirmed；桌面/移动视口不重叠。
- 测试矩阵映射：TR-1→OkxMarketClientTest+KlineSyncServiceTest；TR-2→KlinePersistenceTest；TR-3→MarketControllerTest；TR-4→SchedulerOverlapTest；TR-5→CandleRowParserTest；TR-6→ChartPageDomTest；TR-7→OkxLiveSmokeIT+-Plive-smoke+scripts/live-smoke.sh；TR-8→全量本地 stub+冻结 fixture，Playwright 浏览器构建期获取并 README 记录；TR-9/TR-10→KlineSyncServiceTest 专用用例；429/非 2xx/非法 JSON/超时由 StubOkxServer 内联正文与挂起策略构造。
- smoke 隔离：默认 surefire 排除 **/smoke/**（叠加 *IT 命名双保险）；live-smoke profile 以 combine.self=override 清空排除并仅 include OkxLiveSmokeIT；OkxMarketClient 为构造式无 Spring 注解依赖，可被 smoke 直接 new 以直连 www.okx.com。
- 兼容矩阵首日验证（契约 Risk Area 1）：实现首日验证 spring-boot 4.1.0 + mybatis-plus-spring-boot4-starter 3.5.17 + sqlite-jdbc + flyway（SQLite 支持归属 flyway-core 还是附加模块）的坐标解析与最小上下文装配；如需 flyway-database-sqlite 等坐标仅添加于已授权 pom.xml。
- 基线文件修改点：verify-workspace.sh 仅将 test ! -e pom.xml / test ! -d src 翻转为存在性断言，保留 Java 25、清洁树与只读 OKX 探测；.gitignore 仅补 *.db-journal 与 data/；README 重写覆盖 AC-8 全部条目。

- Open Risks: Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的坐标解析与装配需实现首日以最小上下文验证（契约 Risk Area 1）；若 Flyway SQLite 需附加模块坐标，仅修改已授权 pom.xml。; Hikari data-source-properties 传递 xerial pragma（journal_mode/busy_timeout）的键名绑定需首日验证；备选为 JDBC URL 参数或 yml 显式键，不影响语义。; Playwright for Java 浏览器二进制需构建期获取或预置本地路径（TR-8/README 记录）；离线构建环境缺二进制时 ChartPageDomTest 无法执行，属环境准备项而非设计缺口。; live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 mvn test。; vendored KLineCharts 具体版本在实现时锁定（9.x UMD）并写入 README，避免后续无意识升级引入行为漂移。
- Verification: 本阶段仅产出实现就绪设计：已核对 TaskContract、REQUIREMENT.md 与基线仓库文件，planned_files 与批准 scope 完全一致；未执行任何代码实现、构建或测试运行。
- Contract Sidecar: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW/.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.contract.json
- Raw Output: .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.json

### Declared Planned Files

- MODIFY `.gitignore`: 补充 SQLite 运行期产物忽略（*.db-journal、data/ 目录），与既有 *.db/*.db-wal/*.db-shm 共同覆盖默认数据库文件及辅助文件。
- MODIFY `README.md`: 重写为交付文档：架构、配置表（okx.sync.* 与 OKX_KLINE_SQLITE_PATH 环境变量）、SQLite 默认路径、启动、离线 mvn test、live smoke 命令、API 契约、数据新鲜度语义（confirm=0/1、闭合行可被后续合法响应修正、最新价可能滞后一个轮询周期）与已知限制。
- CREATE `pom.xml`: Spring Boot 4.1.0 parent + Java 25；依赖 spring-boot-starter-web、com.baomidou:mybatis-plus-spring-boot4-starter:3.5.17、org.flywaydb:flyway-core、org.xerial:sqlite-jdbc；测试依赖 spring-boot-starter-test 与 com.microsoft.playwright:playwright；surefire 默认排除 **/smoke/**，live-smoke profile 覆盖排除并仅执行 OkxLiveSmokeIT。
- CREATE `scripts/live-smoke.sh`: 显式 opt-in 包装：mvn -Plive-smoke test，仅触发直连 OKX 官方公开接口的只读 smoke，不进入默认测试。
- MODIFY `scripts/verify-workspace.sh`: 将基线断言 test ! -e pom.xml、test ! -d src 翻转为 test -f pom.xml、test -d src；保留 Java 25 校验、清洁树校验与只读 OKX 探测。
- CREATE `src/main/java/com/example/okxkline/OkxKlineApplication.java`: @SpringBootApplication 启动类 + @MapperScan(com.example.okxkline.mapper)；main 中仅为配置的 SQLite 路径创建父目录（初始化准备，不含任何建表逻辑）。
- CREATE `src/main/java/com/example/okxkline/config/OkxSyncProperties.java`: @ConfigurationProperties(okx.sync)：base-url、connect-timeout、read-timeout(Duration)、enabled、fixed-delay(Duration)，经宽松绑定支持环境变量覆盖；limit 固定常量 300，不配置化。
- CREATE `src/main/java/com/example/okxkline/domain/Kline.java`: 纯领域 record：instrument、bar、openTime(long 毫秒)、open/high/low/close/volume/volumeCcy/volumeCcyQuote(BigDecimal)、confirmed(boolean)；服务层与 API 的 decimal-safe 权威载体。
- CREATE `src/main/java/com/example/okxkline/okx/OkxMarketClient.java`: 构造式注入 OkxSyncProperties，基于 RestClient+JDK HttpClient 按 base-url/超时构建；GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300；负责 HTTP 状态、JSON envelope（code=='0'、data 数组）校验并委托 CandleRowParser，返回 List<Kline>；失败抛出带分类枚举（TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW）与脱敏摘要的 OkxCallException；无 Spring 注解依赖，可被 live smoke 直接构造。
- CREATE `src/main/java/com/example/okxkline/okx/CandleRowParser.java`: 纯静态行解析器：校验 9 字段、数值可解析 BigDecimal、ts 为正整数毫秒、confirm∈{0,1}；仅做格式校验，明确不做价格大小/方向等行情语义校验；输出 domain Kline。
- CREATE `src/main/java/com/example/okxkline/entity/KlineEntity.java`: MyBatis-Plus @TableName(kline) 实体；价格/成交量以 String 承载 TEXT 列（存储编码），confirm 为 Integer 0/1，openTime 为 Long；提供与 domain Kline 的双向转换（toPlainString/BigDecimal 构造），全链路无 float/double。
- CREATE `src/main/java/com/example/okxkline/mapper/KlineMapper.java`: extends BaseMapper<KlineEntity>；核心单条 @Insert upsert：ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 全部行情字段=excluded.对应字段、confirm=excluded.confirm、updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0；另有 @Select 以子查询取最近 N 行并按 open_time 升序返回；无任何删除语句。
- CREATE `src/main/java/com/example/okxkline/mapper/SyncStateMapper.java`: MyBatis 注解 mapper：读取 id=1 单行状态；按轮次结果 UPDATE state/last_attempt_at/last_success_at/last_error_category/last_error_summary；无删除。
- CREATE `src/main/java/com/example/okxkline/sync/KlineSyncService.java`: 同步引擎：ApplicationReadyEvent 启动回填 + @Scheduled(fixedDelayString 与 initialDelayString 取 okx.sync.fixed-delay) 轮询；AtomicBoolean 在飞守卫；syncOnce 先 recordAttempt，再完整获取+校验（解析期失败零写入），随后 TransactionTemplate 短事务内逐行 upsert（事务仅包 DB 写、不包 HTTP），成功 recordSuccess、失败按分类 recordFailure 并等待下一轮（无立即重试）；日志仅记状态/耗时/行数/错误分类，不打响应正文。
- CREATE `src/main/java/com/example/okxkline/sync/SyncStateService.java`: 同步生命周期 owner：读写 sync_state 单行；状态 PENDING/OK/DEGRADED/DISABLED 仅由轮次结果分类枚举驱动（错误文本只是≤200 字符有界展示摘要，绝不参与状态判定）；暴露嵌套 SyncHealthView 供 API。
- CREATE `src/main/java/com/example/okxkline/web/MarketController.java`: GET /api/klines?limit=（缺省 300；非正整数或>300 抛 InvalidLimitException→400）：经 mapper 取最近 N 行升序返回 domain Kline；GET /api/sync/health 返回状态视图；仅读本应用 SQLite。
- CREATE `src/main/java/com/example/okxkline/web/GlobalExceptionHandler.java`: @RestControllerAdvice：InvalidLimitException 与参数类型错误→400 明确客户端错误 JSON；未捕获异常→500 通用信息，不泄漏内部细节。
- CREATE `src/main/resources/application.yml`: 声明式配置：datasource url jdbc:sqlite:${OKX_KLINE_SQLITE_PATH:./data/okx-kline.db}、Hikari maximum-pool-size=1、journal_mode=WAL、busy_timeout=5000；flyway classpath:db/migration；jackson write-bigdecimal-as-plain；spring.task.scheduling.pool.size=1；okx.sync 默认值（www.okx.com、connect 5s、read 10s、enabled=true、fixed-delay 15s）。
- CREATE `src/main/resources/db/migration/V1__init_kline_schema.sql`: Flyway V1：kline 表（UNIQUE(instrument,bar,open_time)、confirm CHECK 0/1、价格/成交量 TEXT、open_time INTEGER 毫秒、updated_at TEXT）与 sync_state 单行表（state CHECK、时间与错误字段），并种子 INSERT id=1 PENDING 行；唯一且版本化的建表入口。
- CREATE `src/main/resources/static/index.html`: 首屏即行情页：仅引用本地 /vendor/klinecharts.min.js、/app.js、/styles.css（零外链）；头部信息区（BTC / USDT、1m、最新收盘价、最近闭合 K 线时间、同步状态、最近刷新时间）、图表容器、无数据/降级/错误状态区。
- CREATE `src/main/resources/static/app.js`: 加载即拉取 /api/klines 与 /api/sync/health；KLineCharts 蜡烛图+VOL 成交量（timestamp 毫秒转秒）；setInterval 10 秒 applyNewData 刷新不整页重载；失败保留旧图并显示状态；空数据与首次加载提示；全部请求相对路径仅指向本应用。
- CREATE `src/main/resources/static/styles.css`: 桌面/移动响应式布局，信息区、状态区、图表不重叠；克制的 degraded 状态样式。
- CREATE `src/main/resources/static/vendor/klinecharts.min.js`: 构建期固定的 KLineCharts UMD 产物（版本锁定并记录于 README），运行时零 CDN。
- CREATE `src/test/java/com/example/okxkline/okx/CandleRowParserTest.java`: 纯单测：合法行、BigDecimal 精确保持、ts 毫秒语义、confirm 0/1；非法：字段数≠9、非数值、非正 ts、confirm 越界、空字段。
- CREATE `src/test/java/com/example/okxkline/okx/OkxMarketClientTest.java`: 经 StubOkxServer：正常 envelope、code≠0、非 2xx、429、非法 JSON、读超时（挂起不回包）；断言查询参数 instId=BTC-USDT&bar=1m&limit=300 与异常分类。
- CREATE `src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java`: 真实上下文（stub OKX+临时 SQLite+长 fixed-delay 隔离调度）：启动回填 TR-9（300 行 fixture，断言由启动流程触发的请求与 300 行升序入库）；倒序/乱序输入；重复同步幂等；confirm 0→1 原位更新；闭合行 confirm=1→1 更新被接受、confirm=1 遇 0 不回退不覆盖（TR-10）且无删除；陈旧响应不删较新行；非法 envelope/行整轮零写入+DEGRADED+无立即重试（请求计数静止）；嵌套 @TestConfiguration 注入第 N 行抛错的 mapper 代理验证事务回滚零写入。
- CREATE `src/test/java/com/example/okxkline/sync/SchedulerOverlapTest.java`: fixed-delay 约 1s + stub 响应约 5s：断言并发峰值=1、请求串行；另以两线程并发调 syncOnce 验证在飞守卫跳过。
- CREATE `src/test/java/com/example/okxkline/persistence/KlinePersistenceTest.java`: 临时 SQLite 文件库：MP BaseMapper.insert 重复键证明唯一约束生效、upsert 幂等；关闭上下文后以新上下文复用同一文件模拟重启，已闭合 K 线仍可查询。
- CREATE `src/test/java/com/example/okxkline/web/MarketControllerTest.java`: MockMvc+真实库：升序与 300 上限、limit 缺省与 0/301/abc→400 明确信息、health 字段完整性、同步失败后 klines 仍返回既有数据。
- CREATE `src/test/java/com/example/okxkline/web/ChartPageDomTest.java`: Playwright 加载随机端口应用（OKX 指向 stub）：断言图表 canvas 渲染消费 /api/klines、等待 10 秒周期请求且无主框架导航、全部网络请求仅命中本应用源（无 okx.com、无 CDN、无 stub 直连）。
- CREATE `src/test/java/com/example/okxkline/support/StubOkxServer.java`: 基于 JDK com.sun.net.httpserver 的契约一致 stub：可编程状态码/正文/延迟/挂起不回包；记录请求与并发计数；零新增依赖。
- CREATE `src/test/java/com/example/okxkline/smoke/OkxLiveSmokeIT.java`: 仅 -Plive-smoke 执行：直接构造 OkxMarketClient（默认 www.okx.com 配置）发起一次只读 GET，断言至少一根结构合法（9 字段、confirm∈{0,1}、开盘时间对齐分钟）的 BTC-USDT 1m K 线。
- CREATE `src/test/resources/fixtures/okx/candles-normal.json`: 冻结 300 行 BTC-USDT 1m 响应（ts 新→旧、分钟对齐，最新一根 confirm=0 其余 1），驱动启动回填与幂等用例。
- CREATE `src/test/resources/fixtures/okx/candles-reversed.json`: 冻结倒序/乱序小集合（含早于本地已有数据的键），驱动乱序与陈旧响应不删较新数据用例。
- CREATE `src/test/resources/fixtures/okx/candles-unconfirmed.json`: 冻结同一 open_time 的 confirm=0 与 confirm=1 两个响应版本，驱动未闭合 K 线原位更新用例。
- CREATE `src/test/resources/fixtures/okx/candles-malformed-row.json`: code=0 但含非法行（字段数/数值/confirm 越界其一）的冻结响应，驱动整轮拒绝零写入用例。
- CREATE `src/test/resources/fixtures/okx/envelope-error.json`: code≠0 的业务错误冻结响应（如限流），驱动 BUSINESS_ERROR 用例。



# Required Authored Context

The following verified inputs are mandatory. Respond to every active obligation; ADDRESSED does not close it. Use NOT_ADDRESSED honestly. Initial authors return [].

## Active obligations

[ ]

## Current review candidate

.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.contract.json

{
  "artifact_type" : "agent_output_contract",
  "schema_version" : 1,
  "workstream_id" : "ws-20260911T231749Z-GCTW",
  "run_id" : "run-1789169462819",
  "node_id" : "design.claude_design",
  "node_instance_id" : "node-design-claude_design-019",
  "handler_type" : "acpx.agent_run",
  "decision" : "READY_FOR_ARCH_REVIEW",
  "summary" : "围绕 confirm 语义的单语句幂等 upsert、fixedDelay 单飞调度与全离线测试矩阵的实现就绪设计，planned_files 与已批准 scope 逐项对齐。",
  "required_keys" : [ "decision", "summary" ],
  "allowed_decisions" : [ "READY_FOR_ARCH_REVIEW" ],
  "source_output_ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.json",
  "source_artifact_type" : "design_result",
  "generated_at" : "2026-09-11T23:40:46.716692Z",
  "control" : {
    "summary" : "围绕 confirm 语义的单语句幂等 upsert、fixedDelay 单飞调度与全离线测试矩阵的实现就绪设计，planned_files 与已批准 scope 逐项对齐。",
    "decision" : "READY_FOR_ARCH_REVIEW"
  },
  "control_source" : {
    "kind" : "strict_agent_result_envelope"
  },
  "revision_responses" : [ ],
  "lifecycle_status" : "READY",
  "checks" : [ "已通读已批准 TaskContract tc-ws-20260911T231749Z-GCTW-v1（human gate 016 APPROVE）、REQUIREMENT.md 与基线 README.md、.gitignore、scripts/verify-workspace.sh；当前为空基线（无 pom.xml、无 src/），交付物均为新建或对三个基线文件的窄修改。", "planned_files 与 scope.included 37 项（3 MODIFY + 34 CREATE）路径与操作逐字一致，无越权路径；REQUIREMENT.md、.git/、.agent/ 与工作区外路径不触碰。", "AC-1..AC-10 与 TR-1..TR-10 逐条映射到具体文件、fixture 与断言（见 evidence），约束 C-1..C-10 逐条满足。", "生命周期-正常完成：ApplicationReadyEvent 启动回填，每轮 获取→完整解析校验 envelope 与全部行→短事务逐行 upsert→recordSuccess(OK,lastSuccessAt)；/api/klines 与 /api/sync/health 即时反映已提交结果。", "生命周期-并发：单实例三重防重叠（@Scheduled fixedDelay 从上次结束计时 + spring.task.scheduling.pool.size=1 + AtomicBoolean 在飞守卫 try/finally 释放；启动回填与定时轮共用 syncOnce 同受守卫保护）；DB 层 Hikari maximum-pool-size=1 串行化；跨实例协调为契约非目标，不适用。", "生命周期-超时/提供方失败：TIMEOUT、HTTP_STATUS、RATE_LIMITED、BUSINESS_ERROR、MALFORMED_RESPONSE、MALFORMED_ROW、DATABASE 归一为该轮失败——解析期失败零写入，写库期失败事务回滚；置 DEGRADED 记有界摘要；无立即重试，唯一恢复路径是下一轮 fixedDelay；失败路径无 DELETE。", "生命周期-中断/崩溃：未提交事务由 SQLite journal/WAL 回滚，库中只存在完整轮次；对 OKX 仅只读 GET、无外部写副作用、无需补偿；崩溃时 sync_state 至多滞后一轮，下一轮自愈。", "生命周期-重启/恢复：Flyway 迁移幂等跳过；启动回填重跑为幂等 upsert；sync_state 持久化最近尝试/成功/失败；已闭合 K 线跨重启可查（KlinePersistenceTest 以同一文件新建 ApplicationContext 验证）。", "生命周期-回滚/冲突：行键冲突是 ON CONFLICT 正常路径而非错误；唯一约束兜底且经直插重复键用例证明不可绕过；DB 异常经 TransactionTemplate 整体回滚、失败轮零写入（注入式失败 mapper 代理验证）。", "cannot-bypass 测试映射：调度不重叠（SchedulerOverlapTest 并发峰值=1）；任何失败不删除数据（KlineSyncServiceTest 失败矩阵断言行数不减）；confirm 1→0 不可回退不可覆盖（TR-10b）；非法 limit 返回 400（MarketControllerTest）；浏览器不出站、无 CDN（ChartPageDomTest 全量网络断言）；smoke 不进默认 mvn test（surefire 排除 + 脚本）。", "不适用边界声明：缓存（未引入，本地读无缓存）、队列（无异步队列）、分布式锁（非目标）、对外系统的写副作用补偿（OKX 仅只读 GET）。", "未新增平台能力：无重试框架、无内存缓存、无额外线程池；失败后唯一恢复路径为下一轮调度；MyBatis-Plus mapper 是唯一持久化通道（无 JPA/JdbcTemplate/平行 repository，SyncStateMapper 亦是同一 SqlSessionFactory 下的 MyBatis 注解 mapper）。", "测试离线性由构造保证：自动化测试仅连本地 StubOkxServer 与冻结 fixture，生产代码默认 base-url 仅在显式 live smoke 中使用。" ],
  "evidence" : [ "架构分层：okx 层（OkxMarketClient+CandleRowParser：HTTP+envelope+行校验）→ sync 层（KlineSyncService 调度/事务/守卫 + SyncStateService 状态）→ mapper 层（MyBatis-Plus 唯一持久化通道）→ web 层（MarketController JSON API + 同源静态前端）；浏览器仅访问本应用，唯一出站流量是服务端到 OKX 的只读 GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300。", "AC-6 核心语义收敛为 KlineMapper 单条 upsert SQL：INSERT ... ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 各行情字段=excluded.对应字段, confirm=excluded.confirm, updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0——0→0/0→1/1→1 均取最近一次成功校验响应值（含闭合行价格与成交量更新），唯一被禁止的 1→0 因 WHERE 不触发而整行保持原状；全链路无 DELETE；新旧判定只用行内声明的 confirm，不读价格大小/方向，不假设未声明的版本号，且本地晚于响应最晚 open_time 的行因根本不在冲突键内而原样保留。", "解析先于写入：每轮先完整解析校验 envelope（HTTP 2xx、JSON 合法、code=='0'、data 为数组）与全部行（任一非法即抛分类异常、零 DB 写），随后 TransactionTemplate 短事务内循环 mapper.upsertOne（事务仅包 DB 写、绝不包 HTTP 调用）；同一响应重复 open_time 由循环 upsert 确定性后写覆盖。", "调度设计：@Scheduled(fixedDelayString 与 initialDelayString 均取 okx.sync.fixed-delay，默认 15s) + 启动回填经 ApplicationReadyEvent；fixedDelay 语义（上次结束才计时）+ 单线程调度器 + AtomicBoolean 守卫三层防重叠；okx.sync.enabled=false 时两个入口直接返回，无调度副作用。", "状态机：sync_state 单行（V1 迁移种子 PENDING 行 id=1）；状态集合 PENDING/OK/DEGRADED/DISABLED 仅由轮次结果的分类枚举驱动；last_error_summary 为≤200 字符白名单摘要（HTTP 只记状态码、业务错误只记 code+截断 msg、其余记异常类别），响应正文绝不入库/入日志；错误文本仅是展示元数据，不参与状态判定。", "decimal-safe 链路：OKX 十进制字符串 → BigDecimal（parser）→ KlineEntity String(toPlainString) → SQLite TEXT → 读取经 BigDecimal 构造 → API 以 Jackson WRITE_BIGDECIMAL_AS_PLAIN 输出 JSON 数值；全程无 float/double/REAL；实体用 String 承载 TEXT 列是存储编码选择，规避 xerial ResultSet.getBigDecimal 对 TEXT 列的不确定行为，且不引入未授权的 TypeHandler 文件。", "SQLite 并发：Hikari maximum-pool-size=1 串行化读写 + WAL + busy_timeout=5000 + 短事务，缓解单写者 BUSY（契约 Risk Area 4）；读路径为本地毫秒级查询，不引入缓存。", "版本化初始化：建表唯一入口 db/migration/V1__init_kline_schema.sql（Flyway）——kline 表含 UNIQUE(instrument,bar,open_time) 与 confirm CHECK(0/1)、价格/成交量 TEXT、open_time INTEGER 毫秒；sync_state 表含 state CHECK 与时间/错误字段；业务代码零 DDL。", "API 契约：GET /api/klines?limit=N（缺省 300；非正整数或>300 → 400 与明确错误信息；升序、最多 300、行含 openTime/o/h/l/c/vol/volCcy/volCcyQuote/confirmed）；GET /api/sync/health（state/lastAttemptAt/lastSuccessAt/lastErrorCategory/lastErrorSummary）；GlobalExceptionHandler 统一 400/500 JSON，不泄漏内部细节。", "前端：index.html+app.js+styles.css+vendor/klinecharts.min.js 全部同源打包零 CDN；加载即拉取 /api/klines 与 /api/sync/health，KLineCharts 渲染蜡烛+VOL 成交量（timestamp 毫秒转秒）；setInterval 10 秒 applyNewData 不整页重载；degraded/后端失败保留旧图+克制状态条；无数据与首次加载提示；最新收盘价取最后一根（可能未闭合、滞后一个同步周期，README 明示），最近闭合 K 线时间取最后一根 confirmed；桌面/移动视口不重叠。", "测试矩阵映射：TR-1→OkxMarketClientTest+KlineSyncServiceTest；TR-2→KlinePersistenceTest；TR-3→MarketControllerTest；TR-4→SchedulerOverlapTest；TR-5→CandleRowParserTest；TR-6→ChartPageDomTest；TR-7→OkxLiveSmokeIT+-Plive-smoke+scripts/live-smoke.sh；TR-8→全量本地 stub+冻结 fixture，Playwright 浏览器构建期获取并 README 记录；TR-9/TR-10→KlineSyncServiceTest 专用用例；429/非 2xx/非法 JSON/超时由 StubOkxServer 内联正文与挂起策略构造。", "smoke 隔离：默认 surefire 排除 **/smoke/**（叠加 *IT 命名双保险）；live-smoke profile 以 combine.self=override 清空排除并仅 include OkxLiveSmokeIT；OkxMarketClient 为构造式无 Spring 注解依赖，可被 smoke 直接 new 以直连 www.okx.com。", "兼容矩阵首日验证（契约 Risk Area 1）：实现首日验证 spring-boot 4.1.0 + mybatis-plus-spring-boot4-starter 3.5.17 + sqlite-jdbc + flyway（SQLite 支持归属 flyway-core 还是附加模块）的坐标解析与最小上下文装配；如需 flyway-database-sqlite 等坐标仅添加于已授权 pom.xml。", "基线文件修改点：verify-workspace.sh 仅将 test ! -e pom.xml / test ! -d src 翻转为存在性断言，保留 Java 25、清洁树与只读 OKX 探测；.gitignore 仅补 *.db-journal 与 data/；README 重写覆盖 AC-8 全部条目。" ],
  "missing_evidence" : [ ],
  "must_fix" : [ ],
  "open_risks" : [ "Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的坐标解析与装配需实现首日以最小上下文验证（契约 Risk Area 1）；若 Flyway SQLite 需附加模块坐标，仅修改已授权 pom.xml。", "Hikari data-source-properties 传递 xerial pragma（journal_mode/busy_timeout）的键名绑定需首日验证；备选为 JDBC URL 参数或 yml 显式键，不影响语义。", "Playwright for Java 浏览器二进制需构建期获取或预置本地路径（TR-8/README 记录）；离线构建环境缺二进制时 ChartPageDomTest 无法执行，属环境准备项而非设计缺口。", "live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 mvn test。", "vendored KLineCharts 具体版本在实现时锁定（9.x UMD）并写入 README，避免后续无意识升级引入行为漂移。" ],
  "verification_summary" : "本阶段仅产出实现就绪设计：已核对 TaskContract、REQUIREMENT.md 与基线仓库文件，planned_files 与批准 scope 完全一致；未执行任何代码实现、构建或测试运行。",
  "design" : {
    "planned_files" : [ {
      "path" : ".gitignore",
      "responsibility" : "补充 SQLite 运行期产物忽略（*.db-journal、data/ 目录），与既有 *.db/*.db-wal/*.db-shm 共同覆盖默认数据库文件及辅助文件。",
      "operation" : "MODIFY"
    }, {
      "path" : "README.md",
      "responsibility" : "重写为交付文档：架构、配置表（okx.sync.* 与 OKX_KLINE_SQLITE_PATH 环境变量）、SQLite 默认路径、启动、离线 mvn test、live smoke 命令、API 契约、数据新鲜度语义（confirm=0/1、闭合行可被后续合法响应修正、最新价可能滞后一个轮询周期）与已知限制。",
      "operation" : "MODIFY"
    }, {
      "path" : "pom.xml",
      "responsibility" : "Spring Boot 4.1.0 parent + Java 25；依赖 spring-boot-starter-web、com.baomidou:mybatis-plus-spring-boot4-starter:3.5.17、org.flywaydb:flyway-core、org.xerial:sqlite-jdbc；测试依赖 spring-boot-starter-test 与 com.microsoft.playwright:playwright；surefire 默认排除 **/smoke/**，live-smoke profile 覆盖排除并仅执行 OkxLiveSmokeIT。",
      "operation" : "CREATE"
    }, {
      "path" : "scripts/live-smoke.sh",
      "responsibility" : "显式 opt-in 包装：mvn -Plive-smoke test，仅触发直连 OKX 官方公开接口的只读 smoke，不进入默认测试。",
      "operation" : "CREATE"
    }, {
      "path" : "scripts/verify-workspace.sh",
      "responsibility" : "将基线断言 test ! -e pom.xml、test ! -d src 翻转为 test -f pom.xml、test -d src；保留 Java 25 校验、清洁树校验与只读 OKX 探测。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/com/example/okxkline/OkxKlineApplication.java",
      "responsibility" : "@SpringBootApplication 启动类 + @MapperScan(com.example.okxkline.mapper)；main 中仅为配置的 SQLite 路径创建父目录（初始化准备，不含任何建表逻辑）。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/config/OkxSyncProperties.java",
      "responsibility" : "@ConfigurationProperties(okx.sync)：base-url、connect-timeout、read-timeout(Duration)、enabled、fixed-delay(Duration)，经宽松绑定支持环境变量覆盖；limit 固定常量 300，不配置化。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/domain/Kline.java",
      "responsibility" : "纯领域 record：instrument、bar、openTime(long 毫秒)、open/high/low/close/volume/volumeCcy/volumeCcyQuote(BigDecimal)、confirmed(boolean)；服务层与 API 的 decimal-safe 权威载体。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxMarketClient.java",
      "responsibility" : "构造式注入 OkxSyncProperties，基于 RestClient+JDK HttpClient 按 base-url/超时构建；GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300；负责 HTTP 状态、JSON envelope（code=='0'、data 数组）校验并委托 CandleRowParser，返回 List<Kline>；失败抛出带分类枚举（TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW）与脱敏摘要的 OkxCallException；无 Spring 注解依赖，可被 live smoke 直接构造。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/CandleRowParser.java",
      "responsibility" : "纯静态行解析器：校验 9 字段、数值可解析 BigDecimal、ts 为正整数毫秒、confirm∈{0,1}；仅做格式校验，明确不做价格大小/方向等行情语义校验；输出 domain Kline。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/entity/KlineEntity.java",
      "responsibility" : "MyBatis-Plus @TableName(kline) 实体；价格/成交量以 String 承载 TEXT 列（存储编码），confirm 为 Integer 0/1，openTime 为 Long；提供与 domain Kline 的双向转换（toPlainString/BigDecimal 构造），全链路无 float/double。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/mapper/KlineMapper.java",
      "responsibility" : "extends BaseMapper<KlineEntity>；核心单条 @Insert upsert：ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 全部行情字段=excluded.对应字段、confirm=excluded.confirm、updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0；另有 @Select 以子查询取最近 N 行并按 open_time 升序返回；无任何删除语句。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/mapper/SyncStateMapper.java",
      "responsibility" : "MyBatis 注解 mapper：读取 id=1 单行状态；按轮次结果 UPDATE state/last_attempt_at/last_success_at/last_error_category/last_error_summary；无删除。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/KlineSyncService.java",
      "responsibility" : "同步引擎：ApplicationReadyEvent 启动回填 + @Scheduled(fixedDelayString 与 initialDelayString 取 okx.sync.fixed-delay) 轮询；AtomicBoolean 在飞守卫；syncOnce 先 recordAttempt，再完整获取+校验（解析期失败零写入），随后 TransactionTemplate 短事务内逐行 upsert（事务仅包 DB 写、不包 HTTP），成功 recordSuccess、失败按分类 recordFailure 并等待下一轮（无立即重试）；日志仅记状态/耗时/行数/错误分类，不打响应正文。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/SyncStateService.java",
      "responsibility" : "同步生命周期 owner：读写 sync_state 单行；状态 PENDING/OK/DEGRADED/DISABLED 仅由轮次结果分类枚举驱动（错误文本只是≤200 字符有界展示摘要，绝不参与状态判定）；暴露嵌套 SyncHealthView 供 API。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/MarketController.java",
      "responsibility" : "GET /api/klines?limit=（缺省 300；非正整数或>300 抛 InvalidLimitException→400）：经 mapper 取最近 N 行升序返回 domain Kline；GET /api/sync/health 返回状态视图；仅读本应用 SQLite。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/GlobalExceptionHandler.java",
      "responsibility" : "@RestControllerAdvice：InvalidLimitException 与参数类型错误→400 明确客户端错误 JSON；未捕获异常→500 通用信息，不泄漏内部细节。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/application.yml",
      "responsibility" : "声明式配置：datasource url jdbc:sqlite:${OKX_KLINE_SQLITE_PATH:./data/okx-kline.db}、Hikari maximum-pool-size=1、journal_mode=WAL、busy_timeout=5000；flyway classpath:db/migration；jackson write-bigdecimal-as-plain；spring.task.scheduling.pool.size=1；okx.sync 默认值（www.okx.com、connect 5s、read 10s、enabled=true、fixed-delay 15s）。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/db/migration/V1__init_kline_schema.sql",
      "responsibility" : "Flyway V1：kline 表（UNIQUE(instrument,bar,open_time)、confirm CHECK 0/1、价格/成交量 TEXT、open_time INTEGER 毫秒、updated_at TEXT）与 sync_state 单行表（state CHECK、时间与错误字段），并种子 INSERT id=1 PENDING 行；唯一且版本化的建表入口。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/index.html",
      "responsibility" : "首屏即行情页：仅引用本地 /vendor/klinecharts.min.js、/app.js、/styles.css（零外链）；头部信息区（BTC / USDT、1m、最新收盘价、最近闭合 K 线时间、同步状态、最近刷新时间）、图表容器、无数据/降级/错误状态区。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/app.js",
      "responsibility" : "加载即拉取 /api/klines 与 /api/sync/health；KLineCharts 蜡烛图+VOL 成交量（timestamp 毫秒转秒）；setInterval 10 秒 applyNewData 刷新不整页重载；失败保留旧图并显示状态；空数据与首次加载提示；全部请求相对路径仅指向本应用。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/styles.css",
      "responsibility" : "桌面/移动响应式布局，信息区、状态区、图表不重叠；克制的 degraded 状态样式。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/vendor/klinecharts.min.js",
      "responsibility" : "构建期固定的 KLineCharts UMD 产物（版本锁定并记录于 README），运行时零 CDN。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/CandleRowParserTest.java",
      "responsibility" : "纯单测：合法行、BigDecimal 精确保持、ts 毫秒语义、confirm 0/1；非法：字段数≠9、非数值、非正 ts、confirm 越界、空字段。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/OkxMarketClientTest.java",
      "responsibility" : "经 StubOkxServer：正常 envelope、code≠0、非 2xx、429、非法 JSON、读超时（挂起不回包）；断言查询参数 instId=BTC-USDT&bar=1m&limit=300 与异常分类。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java",
      "responsibility" : "真实上下文（stub OKX+临时 SQLite+长 fixed-delay 隔离调度）：启动回填 TR-9（300 行 fixture，断言由启动流程触发的请求与 300 行升序入库）；倒序/乱序输入；重复同步幂等；confirm 0→1 原位更新；闭合行 confirm=1→1 更新被接受、confirm=1 遇 0 不回退不覆盖（TR-10）且无删除；陈旧响应不删较新行；非法 envelope/行整轮零写入+DEGRADED+无立即重试（请求计数静止）；嵌套 @TestConfiguration 注入第 N 行抛错的 mapper 代理验证事务回滚零写入。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/SchedulerOverlapTest.java",
      "responsibility" : "fixed-delay 约 1s + stub 响应约 5s：断言并发峰值=1、请求串行；另以两线程并发调 syncOnce 验证在飞守卫跳过。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/persistence/KlinePersistenceTest.java",
      "responsibility" : "临时 SQLite 文件库：MP BaseMapper.insert 重复键证明唯一约束生效、upsert 幂等；关闭上下文后以新上下文复用同一文件模拟重启，已闭合 K 线仍可查询。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/MarketControllerTest.java",
      "responsibility" : "MockMvc+真实库：升序与 300 上限、limit 缺省与 0/301/abc→400 明确信息、health 字段完整性、同步失败后 klines 仍返回既有数据。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/ChartPageDomTest.java",
      "responsibility" : "Playwright 加载随机端口应用（OKX 指向 stub）：断言图表 canvas 渲染消费 /api/klines、等待 10 秒周期请求且无主框架导航、全部网络请求仅命中本应用源（无 okx.com、无 CDN、无 stub 直连）。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/support/StubOkxServer.java",
      "responsibility" : "基于 JDK com.sun.net.httpserver 的契约一致 stub：可编程状态码/正文/延迟/挂起不回包；记录请求与并发计数；零新增依赖。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/smoke/OkxLiveSmokeIT.java",
      "responsibility" : "仅 -Plive-smoke 执行：直接构造 OkxMarketClient（默认 www.okx.com 配置）发起一次只读 GET，断言至少一根结构合法（9 字段、confirm∈{0,1}、开盘时间对齐分钟）的 BTC-USDT 1m K 线。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-normal.json",
      "responsibility" : "冻结 300 行 BTC-USDT 1m 响应（ts 新→旧、分钟对齐，最新一根 confirm=0 其余 1），驱动启动回填与幂等用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-reversed.json",
      "responsibility" : "冻结倒序/乱序小集合（含早于本地已有数据的键），驱动乱序与陈旧响应不删较新数据用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-unconfirmed.json",
      "responsibility" : "冻结同一 open_time 的 confirm=0 与 confirm=1 两个响应版本，驱动未闭合 K 线原位更新用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-malformed-row.json",
      "responsibility" : "code=0 但含非法行（字段数/数值/confirm 越界其一）的冻结响应，驱动整轮拒绝零写入用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/envelope-error.json",
      "responsibility" : "code≠0 的业务错误冻结响应（如限流），驱动 BUSINESS_ERROR 用例。",
      "operation" : "CREATE"
    } ]
  },
  "stage_outcome" : "READY",
  "stage_outcome_source" : "declared_status",
  "evidence_state" : {
    "blocking" : false,
    "evidence_count" : 14,
    "missing_evidence_count" : 0,
    "must_fix_count" : 0,
    "acceptance_note_count" : 0,
    "open_risk_count" : 5
  },
  "authored_context" : {
    "sha256" : "540f6ad30b33cf2c1abafa7de9cfafc31ad264a733e3ba6ee8be4004bcec5d17",
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/prompts/design-claude.md.manifest.json"
  }
}
