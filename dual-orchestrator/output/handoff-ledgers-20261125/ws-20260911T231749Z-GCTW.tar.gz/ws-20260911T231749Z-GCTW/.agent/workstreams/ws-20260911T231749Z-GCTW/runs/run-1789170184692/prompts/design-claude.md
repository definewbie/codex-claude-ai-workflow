## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/okx-btc-k-line-demo-agent-runs/ws-20260911T231749Z-GCTW
- Run all shell commands from the effective workspace above.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.

## Structured Artifact Field Semantics

- `must_fix` and `missing_evidence` mean unresolved blockers; keep them empty for a ready design.
- Put resolved review comments in `checks` or `evidence`, not `must_fix`.
- `design.planned_files` declares intended changes only; exact paths and operations must be authorized by the approved TaskContract.

# Claude Design

Workstream: ws-20260911T231749Z-GCTW
Node: design.claude_design
Template: design-claude
Ledger: .agent/workstreams/ws-20260911T231749Z-GCTW

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.

You are Claude acting as the primary architect and implementer. Use the user request, prior intake artifacts, Codex review, and human gate decision in the ledger.

Do not implement code in this stage. Produce an implementation-ready design that is narrow, testable, and avoids unrelated refactors.

Declare the complete planned file set in `result.design.planned_files`, for initial and replacement designs alike.
Copy exact canonical paths and operations from the approved TaskContract scope; prose cannot authorize other paths.
Each entry assigns a responsibility, not an actual file change. CREATE files need not exist yet.
The declared set may be a subset of approved scope, but must cover every change this design proposes.

Revision discipline:

- When the context contains a prior `NEEDS_REVISION`, return a complete replacement design, not a delta or addendum.
- Treat available prior must-fix items as the minimum repair set, not the boundary of the design review.
- Do not claim knowledge of prior design text that is absent from the context. Reconstruct a coherent complete design from the TaskContract, current review evidence, and available iteration reasons.
- When adding or changing state, an index, lock, transaction, queue, cache, external side effect, or compensation, cover every applicable lifecycle boundary in `checks` or `evidence`: normal completion, concurrency, timeout/provider failure, interruption/crash, restart/recovery, rollback/conflict, and a cannot-bypass test. State why a boundary is not applicable instead of inventing requirements.
- Prefer deleting unnecessary mechanisms or simplifying the state model. Do not add platform capability merely to close one finding.

## User Request

# OKX BTC 分钟级 K 线 Web 应用需求

## 目标

构建一个本地 Web 应用，通过 OKX 官方公开行情 REST API 获取 BTC-USDT 现货分钟级 K 线，将数据持久化到 SQLite，并展示可定时刷新的 K 线图。

本应用只读取公开行情，不得下单、访问账户、提供投资建议或抓取 OKX 网页。

## 强制技术栈

- Java 25。
- Spring Boot 4.1.0。
- Maven。
- MyBatis-Plus 3.5.17，必须使用 `mybatis-plus-spring-boot4-starter`。
- SQLite 是唯一应用数据库。
- 使用成熟的 K 线图表库，生产资源必须随应用本地打包，不得依赖运行时 CDN。

不得用 JPA、JdbcTemplate、其他 ORM 或自行编写的平行 repository 基础设施替代 MyBatis-Plus。

## OKX 行情契约

- 数据源只能是 OKX 官方公开 Market Data REST API，不得抓取 HTML 页面。
- 交易品种固定为 BTC-USDT 现货。
- K 线周期固定为 `1m`。
- 接口为 `GET /api/v5/market/candles`。
- 首次启动拉取并保存最近 300 根 K 线。
- 响应行格式为 `[ts,o,h,l,c,vol,volCcy,volCcyQuote,confirm]`。
- `ts` 是 K 线开盘时间的 Unix 毫秒时间戳。
- `confirm=0` 表示当前 K 线尚未闭合，后续允许更新。
- `confirm=1` 表示 K 线已经闭合。
- OKX 可能按时间倒序返回数据，后一次请求也可能命中较旧缓存。应用不得假设响应严格单调，也不得因旧响应删除本地较新的 K 线。
- OKX base URL、连接/读取超时、调度开关和刷新周期必须支持外部配置。
- 调用公开行情不得要求 API Key 或 OKX 账户。
- 生产应用和显式 live smoke 必须直接调用 OKX 官方 API，不得通过测试桩、代理业务服务或抓取服务替代。

## 数据持久化

- 通过 MyBatis-Plus 将 K 线保存到 SQLite。
- 数据库必须对 `(instrument, bar, open_time)` 建立唯一约束。
- 重复同步必须幂等。
- 未闭合 K 线应原位更新。
- 已闭合 K 线在应用重启后仍可查询。
- 价格和成交量不得以二进制浮点数作为权威值，Java 与 SQLite 均采用 decimal-safe 表示。
- 保存足够的同步状态，以展示最近一次尝试、最近一次成功和最近失败；错误文本不得反向成为生命周期状态 owner。
- 数据库初始化必须确定且版本化，不得在业务代码中临时拼接建表流程。

## 定时同步

- 启用同步时，应用启动后执行一次初始回填。
- 默认每 15 秒轮询一次 OKX，周期可配置。
- 每轮必须先完整解析并校验 OKX envelope，再写数据库。
- 同一响应中的合法 K 线在一个事务内完成 upsert。
- HTTP 超时、非 2xx、OKX 业务错误、限流、非法 JSON、非法行或数据库异常不得删除已有 K 线。
- 不得进行无界立即重试；失败后记录 degraded 状态，等待下一轮调度。
- 单应用实例内不得出现重叠调度执行。
- 日志只记录必要运行元数据，失败时不得打印完整 OKX 响应正文。

## 后端 API

提供稳定 JSON API：

1. 查询最近最多 300 根已保存 K 线，按开盘时间升序返回。
2. 查询同步健康状态，包括当前状态、最近尝试时间、最近成功时间和有界安全的失败摘要。

非法 limit 必须返回明确的客户端错误。浏览器只能调用本应用后端，不得直接请求 OKX。

## Web 体验

- 首屏直接展示可用的行情界面，而不是营销落地页。
- 展示真实蜡烛 K 线和成交量。
- 展示 `BTC / USDT`、`1m`、最新收盘价、最近闭合 K 线时间、同步状态和最近成功刷新时间。
- 浏览器默认每 10 秒从后端刷新数据，不整页重载。
- 同步 degraded 时保留最后可用图表，并显示克制但清晰的状态。
- 正确处理首次加载、无数据、数据降级和后端失败状态。
- 当前桌面和移动端视口均应可用，文字、图表和操作不得重叠。
- 不得把模拟价格冒充为 OKX 实时行情。

## 验证要求

- 生产实现只能直连 OKX 官方公开 API。
- `mvn test` 不得依赖公网 OKX 的可用性；自动化测试使用本地、契约一致的 HTTP stub 和冻结 fixture，专门验证正常响应及公网无法稳定制造的超时、429、乱序、陈旧缓存与畸形响应。
- 测试必须覆盖首次回填、倒序输入、重复同步、未闭合 K 线更新、闭合 K 线持久化、陈旧响应、非法 envelope、非法行、超时、非 2xx、OKX 业务错误和调度不重叠。
- 使用临时 SQLite 数据库验证唯一约束与重启后持久化。
- 覆盖后端 API 排序、limit 校验、健康状态，以及同步失败后保留已有数据。
- 提供浏览器级或 DOM 级验证，证明图表消费本应用后端数据、定时刷新且不从浏览器调用 OKX。
- Java 25 下执行 `mvn test` 必须通过，并且测试执行期间无需访问公开 OKX API。
- 提供显式 opt-in live smoke 命令，直接向 OKX 官方接口发起一次只读请求，并验证至少一根结构合法的 BTC-USDT 1m K 线；该命令不得进入默认 `mvn test`。
- README 必须记录架构、配置、SQLite 路径、启动、测试、live smoke、API、数据新鲜度语义和限制。

## 不在范围内

- 交易、账户访问、认证、API Key、余额或任何私有 OKX API。
- 投资建议、告警、策略、技术指标或预测。
- WebSocket 行情。
- 多交易品种或多周期切换。
- 分布式调度或多实例协调。
- 用户账户或管理后台。
- 通用交易所抽象或行情平台。
- 运行时 CDN 依赖。



## Context Package

### Direct Input Artifacts

- .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.stderr.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.transcript.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.json

```json
{
  "workstreamId" : "ws-20260911T231749Z-GCTW",
  "runId" : "run-1789170046878",
  "nodeId" : "design.codex_arch_review",
  "nodeInstanceId" : "node-design-codex_arch_review-021",
  "stageOutcome" : "NEEDS_REVISION",
  "lifecycleStatus" : "NEEDS_REVISION",
  "decision" : "NEEDS_REVISION",
  "summary" : "主体分层与范围合理，但同步状态提交、禁用状态、前端数据适配及安全摘要仍有设计缺口。",
  "sourceArtifactType" : "agent_output_contract",
  "sourceOutputRef" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.json",
  "blocking" : true,
  "checks" : [ "审查完整当前设计及 37 项 planned_files，职责总体覆盖已批准范围，无需增加路径。", "检查正常完成、并发、提供方失败、数据库异常、中断崩溃、重启恢复、事务回滚及不可绕过测试。", "确认条件 upsert 保留 AC-6 的更新语义，HTTP 位于写事务之外，唯一约束与版本化初始化职责明确。", "检查状态事实的所有者、API 消费路径、提交前约束和故障测试；未将计划中的测试当成已执行证据。", "检查后端字段、图表适配、刷新状态及数据新鲜度说明的一致性。" ],
  "evidence" : [ "KlineSyncService 将行情 upsert 放入 TransactionTemplate，随后单独 recordSuccess；设计同时声称写库失败整轮回滚、失败轮零写入。", "SyncStateService 仅通过同一 SQLite 读写状态，但未说明 recordAttempt、recordSuccess 或 recordFailure 自身失败时的处理；下一轮自愈不能解释当前健康结果。", "两个同步入口在 enabled=false 时直接返回，而迁移种子状态为 PENDING；未声明进入 DISABLED 或重启重新启用时的转换。", "API 说明列出 o/h/l/c/vol 等字段，MarketController 却直接返回字段为 open/high/low/close/volume 的 domain Kline，未声明序列化映射。", "app.js 明确计划将毫秒转换为秒，但未提供所选 KLineCharts 版本的时间单位依据；当前浏览器测试描述未明确核对实际图表时间与 OHLCV。", "失败摘要方案包含外部业务错误 code 与截断 msg；长度限制不能单独证明摘要已脱敏或符合白名单。", "README 和前端说明将行情滞后描述为一个轮询周期，但需求明确允许陈旧缓存与连续同步失败。" ],
  "mustFix" : [ "AR-1：明确行情提交与成功状态的事务边界。优先让行情 upsert 和成功状态在同一短事务提交，避免 recordSuccess 失败后把已提交行情描述为失败轮零写入。另明确尝试记录、失败记录自身遇到数据库异常时的有界处理、健康接口结果及守卫释放；数据库不可写时不得声称已持久化 DEGRADED。补充状态写入失败、提交失败与重启读取的故障测试。", "AR-2：由 SyncStateService 明确拥有启动时 enabled 配置对应的状态转换。禁用时不得继续返回旧 OK 或种子 PENDING；重新启用时不得沿用旧 DISABLED。保留历史尝试、成功和失败信息，并测试首次禁用、成功后禁用重启及重新启用，确认禁用期间零 OKX 请求。", "AR-3：统一 API 的公开字段与 domain Kline 序列化结果，并明确 app.js 的 OHLCV 和时间适配。核实固定图表版本的 timestamp 单位后决定是否转换；ChartPageDomTest 须通过真实 API 响应核对图表实际消费的时间、价格、成交量及后续刷新结果，不能仅证明 canvas 存在与请求发生。", "AR-4：将失败摘要收敛为固定分类与受控字段，或定义可验证的外部文本清理规则；仅截断业务 msg 不足以支持安全摘要声明。补充包含控制字符和敏感样式文本的错误响应测试，验证健康 JSON、页面和日志不暴露未经处理的内容。", "AR-5：修正 README 与前端的新鲜度说明，不得承诺最多滞后一个轮询周期。明确最近成功同步时间不等于行情最新时间，陈旧缓存和连续失败可能导致更长滞后；展示继续使用真实行情时间与最近成功时间。" ],
  "contractObligations" : [ ],
  "missingEvidence" : [ "所选 KLineCharts 版本的数据字段与 timestamp 单位依据，以及从实际后端 JSON 到图表输入的明确映射。" ],
  "acceptanceNotes" : [ "以上修订可在现有授权文件内完成，不要求分布式协调、补偿平台或额外数据库。", "依赖兼容性、浏览器二进制和真实 API 验证仍属于已明确保留的实施验证事项，本次不据此新增阻塞。", "未修改文件、执行测试或进行外部查询；本次依据完整提供的设计进行静态审查。" ],
  "openRisks" : [ ],
  "changedFiles" : [ ],
  "verificationSummary" : "已审查完整设计；发现五项需修订的问题及一项图表接口证据缺口，尚不能认定实现就绪。",
  "completedWork" : [ ],
  "importantDecisions" : [ ],
  "recommendedNextStage" : "",
  "suggestedNextPrompt" : "",
  "control" : {
    "summary" : "主体分层与范围合理，但同步状态提交、禁用状态、前端数据适配及安全摘要仍有设计缺口。",
    "decision" : "NEEDS_REVISION"
  },
  "failure" : {
    "categoryHint" : "架构边界与投影一致性",
    "verificationRemediation" : "NONE",
    "contractGaps" : [ ],
    "outOfScopeFiles" : [ ],
    "missingTests" : [ "同步状态写入或提交失败时的数据、健康结果、守卫释放及重启行为。", "禁用与重新启用的启动状态转换及禁用期间零请求。", "真实后端 JSON 到图表时间和 OHLCV 的适配断言。", "不可信错误文本的安全摘要与日志验证。" ],
    "contextGaps" : [ "固定 KLineCharts 版本的输入字段和时间单位依据未提供。" ],
    "reason" : "当前设计未完整定义数据库故障下的状态事实，并存在禁用状态、前后端数据契约、安全摘要和新鲜度说明的不一致。"
  },
  "rereadReasons" : [ ],
  "reviewSubject" : null,
  "taskContractProposal" : null,
  "repositoryFactBinding" : null,
  "proposalDerivation" : null,
  "planArtifact" : null,
  "design" : null,
  "authoredRevisionResponses" : null,
  "authoredContext" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/prompts/design-codex-review.md.manifest.json",
    "sha256" : "1043d3fb4c5ef92940e5c488d2fce88c3b6ec9bf48a334581a629b47bfc446ab"
  }
}
```

- .agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-codex_arch_review-021-run-1789170046878/binding.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json
  (validated typed evidence already projected)

- .agent/workstreams/ws-20260911T231749Z-GCTW/context/agent-governance-node-design-claude_design-024-run-1789170184692.md

```text
# Agent Run Governance Context

- Workstream: ws-20260911T231749Z-GCTW
- Target Node: design.claude_design
- Agent Node Instance: node-design-claude_design-024
- Run Id: run-1789170184692
- Generated At: 2026-09-11T23:43:04.782298Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-claude_design-024-run-1789170184692/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-claude_design-024-run-1789170184692/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-claude_design-024-run-1789170184692/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-claude_design-024-run-1789170184692/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - pom.xml
  - scripts/live-smoke.sh
- Expected edit files: (none planned)
```

Context use rule:

- If the package contains `Working Memory`, use it before reading repository files.
- Re-read files only when the memory is missing, stale, or insufficient for this design decision.
- If the Context Package contains a Read Reuse Contract, follow that contract exactly. Do not invent read-reuse fields when the contract does not declare them.

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_ARCH_REVIEW]




`result.revision_responses` is required: return [] when there are no active authored obligations. Otherwise cover every active obligation_id from Required Authored Context exactly once; do not add unknown IDs or omit unresolved obligations. Each entry has exactly obligation_id, disposition (ADDRESSED or NOT_ADDRESSED), and non-empty evidence. Use NOT_ADDRESSED when unresolved; ADDRESSED is a claim for review, not an approval or closure. Preserve all previously required behavior and the approved contract while making this revision.Each `result.revision_responses` item is a closed object with exactly these fields: [obligation_id, disposition, evidence]. No other keys are permitted.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20260911T231749Z-GCTW",
  "run_id" : "run-1789170184692",
  "node_id" : "design.claude_design",
  "result" : {
    "artifact_type" : "design_result",
    "decision" : "READY_FOR_ARCH_REVIEW",
    "summary" : "one short sentence",
    "lifecycle_status" : "READY",
    "checks" : [ "read the approved contract" ],
    "evidence" : [ "design evidence" ],
    "missing_evidence" : [ ],
    "must_fix" : [ ],
    "open_risks" : [ ],
    "verification_summary" : "Design only; no implementation performed.",
    "design" : {
      "planned_files" : [ {
        "path" : "repo/relative/new.ext",
        "operation" : "CREATE",
        "responsibility" : "responsibility assigned within the approved scope"
      } ]
    },
    "revision_responses" : [ ]
  }
}


# Required Authored Context

The following verified inputs are mandatory. Respond to every active obligation; ADDRESSED does not close it. Use NOT_ADDRESSED honestly. Initial authors return [].

## Revision parent

.agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.contract.json

{
  "artifact_type" : "agent_output_contract",
  "schema_version" : 1,
  "workstream_id" : "ws-20260911T231749Z-GCTW",
  "run_id" : "run-1789169462819",
  "node_id" : "design.claude_design",
  "node_instance_id" : "node-design-claude_design-019",
  "handler_type" : "acpx.agent_run",
  "decision" : "READY_FOR_ARCH_REVIEW",
  "summary" : "围绕 confirm 语义的单语句幂等 upsert、fixedDelay 单飞调度与全离线测试矩阵的实现就绪设计，planned_files 与已批准 scope 逐项对齐。",
  "required_keys" : [ "decision", "summary" ],
  "allowed_decisions" : [ "READY_FOR_ARCH_REVIEW" ],
  "source_output_ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/outputs/design-claude.json",
  "source_artifact_type" : "design_result",
  "generated_at" : "2026-09-11T23:40:46.716692Z",
  "control" : {
    "summary" : "围绕 confirm 语义的单语句幂等 upsert、fixedDelay 单飞调度与全离线测试矩阵的实现就绪设计，planned_files 与已批准 scope 逐项对齐。",
    "decision" : "READY_FOR_ARCH_REVIEW"
  },
  "control_source" : {
    "kind" : "strict_agent_result_envelope"
  },
  "revision_responses" : [ ],
  "lifecycle_status" : "READY",
  "checks" : [ "已通读已批准 TaskContract tc-ws-20260911T231749Z-GCTW-v1（human gate 016 APPROVE）、REQUIREMENT.md 与基线 README.md、.gitignore、scripts/verify-workspace.sh；当前为空基线（无 pom.xml、无 src/），交付物均为新建或对三个基线文件的窄修改。", "planned_files 与 scope.included 37 项（3 MODIFY + 34 CREATE）路径与操作逐字一致，无越权路径；REQUIREMENT.md、.git/、.agent/ 与工作区外路径不触碰。", "AC-1..AC-10 与 TR-1..TR-10 逐条映射到具体文件、fixture 与断言（见 evidence），约束 C-1..C-10 逐条满足。", "生命周期-正常完成：ApplicationReadyEvent 启动回填，每轮 获取→完整解析校验 envelope 与全部行→短事务逐行 upsert→recordSuccess(OK,lastSuccessAt)；/api/klines 与 /api/sync/health 即时反映已提交结果。", "生命周期-并发：单实例三重防重叠（@Scheduled fixedDelay 从上次结束计时 + spring.task.scheduling.pool.size=1 + AtomicBoolean 在飞守卫 try/finally 释放；启动回填与定时轮共用 syncOnce 同受守卫保护）；DB 层 Hikari maximum-pool-size=1 串行化；跨实例协调为契约非目标，不适用。", "生命周期-超时/提供方失败：TIMEOUT、HTTP_STATUS、RATE_LIMITED、BUSINESS_ERROR、MALFORMED_RESPONSE、MALFORMED_ROW、DATABASE 归一为该轮失败——解析期失败零写入，写库期失败事务回滚；置 DEGRADED 记有界摘要；无立即重试，唯一恢复路径是下一轮 fixedDelay；失败路径无 DELETE。", "生命周期-中断/崩溃：未提交事务由 SQLite journal/WAL 回滚，库中只存在完整轮次；对 OKX 仅只读 GET、无外部写副作用、无需补偿；崩溃时 sync_state 至多滞后一轮，下一轮自愈。", "生命周期-重启/恢复：Flyway 迁移幂等跳过；启动回填重跑为幂等 upsert；sync_state 持久化最近尝试/成功/失败；已闭合 K 线跨重启可查（KlinePersistenceTest 以同一文件新建 ApplicationContext 验证）。", "生命周期-回滚/冲突：行键冲突是 ON CONFLICT 正常路径而非错误；唯一约束兜底且经直插重复键用例证明不可绕过；DB 异常经 TransactionTemplate 整体回滚、失败轮零写入（注入式失败 mapper 代理验证）。", "cannot-bypass 测试映射：调度不重叠（SchedulerOverlapTest 并发峰值=1）；任何失败不删除数据（KlineSyncServiceTest 失败矩阵断言行数不减）；confirm 1→0 不可回退不可覆盖（TR-10b）；非法 limit 返回 400（MarketControllerTest）；浏览器不出站、无 CDN（ChartPageDomTest 全量网络断言）；smoke 不进默认 mvn test（surefire 排除 + 脚本）。", "不适用边界声明：缓存（未引入，本地读无缓存）、队列（无异步队列）、分布式锁（非目标）、对外系统的写副作用补偿（OKX 仅只读 GET）。", "未新增平台能力：无重试框架、无内存缓存、无额外线程池；失败后唯一恢复路径为下一轮调度；MyBatis-Plus mapper 是唯一持久化通道（无 JPA/JdbcTemplate/平行 repository，SyncStateMapper 亦是同一 SqlSessionFactory 下的 MyBatis 注解 mapper）。", "测试离线性由构造保证：自动化测试仅连本地 StubOkxServer 与冻结 fixture，生产代码默认 base-url 仅在显式 live smoke 中使用。" ],
  "evidence" : [ "架构分层：okx 层（OkxMarketClient+CandleRowParser：HTTP+envelope+行校验）→ sync 层（KlineSyncService 调度/事务/守卫 + SyncStateService 状态）→ mapper 层（MyBatis-Plus 唯一持久化通道）→ web 层（MarketController JSON API + 同源静态前端）；浏览器仅访问本应用，唯一出站流量是服务端到 OKX 的只读 GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300。", "AC-6 核心语义收敛为 KlineMapper 单条 upsert SQL：INSERT ... ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 各行情字段=excluded.对应字段, confirm=excluded.confirm, updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0——0→0/0→1/1→1 均取最近一次成功校验响应值（含闭合行价格与成交量更新），唯一被禁止的 1→0 因 WHERE 不触发而整行保持原状；全链路无 DELETE；新旧判定只用行内声明的 confirm，不读价格大小/方向，不假设未声明的版本号，且本地晚于响应最晚 open_time 的行因根本不在冲突键内而原样保留。", "解析先于写入：每轮先完整解析校验 envelope（HTTP 2xx、JSON 合法、code=='0'、data 为数组）与全部行（任一非法即抛分类异常、零 DB 写），随后 TransactionTemplate 短事务内循环 mapper.upsertOne（事务仅包 DB 写、绝不包 HTTP 调用）；同一响应重复 open_time 由循环 upsert 确定性后写覆盖。", "调度设计：@Scheduled(fixedDelayString 与 initialDelayString 均取 okx.sync.fixed-delay，默认 15s) + 启动回填经 ApplicationReadyEvent；fixedDelay 语义（上次结束才计时）+ 单线程调度器 + AtomicBoolean 守卫三层防重叠；okx.sync.enabled=false 时两个入口直接返回，无调度副作用。", "状态机：sync_state 单行（V1 迁移种子 PENDING 行 id=1）；状态集合 PENDING/OK/DEGRADED/DISABLED 仅由轮次结果的分类枚举驱动；last_error_summary 为≤200 字符白名单摘要（HTTP 只记状态码、业务错误只记 code+截断 msg、其余记异常类别），响应正文绝不入库/入日志；错误文本仅是展示元数据，不参与状态判定。", "decimal-safe 链路：OKX 十进制字符串 → BigDecimal（parser）→ KlineEntity String(toPlainString) → SQLite TEXT → 读取经 BigDecimal 构造 → API 以 Jackson WRITE_BIGDECIMAL_AS_PLAIN 输出 JSON 数值；全程无 float/double/REAL；实体用 String 承载 TEXT 列是存储编码选择，规避 xerial ResultSet.getBigDecimal 对 TEXT 列的不确定行为，且不引入未授权的 TypeHandler 文件。", "SQLite 并发：Hikari maximum-pool-size=1 串行化读写 + WAL + busy_timeout=5000 + 短事务，缓解单写者 BUSY（契约 Risk Area 4）；读路径为本地毫秒级查询，不引入缓存。", "版本化初始化：建表唯一入口 db/migration/V1__init_kline_schema.sql（Flyway）——kline 表含 UNIQUE(instrument,bar,open_time) 与 confirm CHECK(0/1)、价格/成交量 TEXT、open_time INTEGER 毫秒；sync_state 表含 state CHECK 与时间/错误字段；业务代码零 DDL。", "API 契约：GET /api/klines?limit=N（缺省 300；非正整数或>300 → 400 与明确错误信息；升序、最多 300、行含 openTime/o/h/l/c/vol/volCcy/volCcyQuote/confirmed）；GET /api/sync/health（state/lastAttemptAt/lastSuccessAt/lastErrorCategory/lastErrorSummary）；GlobalExceptionHandler 统一 400/500 JSON，不泄漏内部细节。", "前端：index.html+app.js+styles.css+vendor/klinecharts.min.js 全部同源打包零 CDN；加载即拉取 /api/klines 与 /api/sync/health，KLineCharts 渲染蜡烛+VOL 成交量（timestamp 毫秒转秒）；setInterval 10 秒 applyNewData 不整页重载；degraded/后端失败保留旧图+克制状态条；无数据与首次加载提示；最新收盘价取最后一根（可能未闭合、滞后一个同步周期，README 明示），最近闭合 K 线时间取最后一根 confirmed；桌面/移动视口不重叠。", "测试矩阵映射：TR-1→OkxMarketClientTest+KlineSyncServiceTest；TR-2→KlinePersistenceTest；TR-3→MarketControllerTest；TR-4→SchedulerOverlapTest；TR-5→CandleRowParserTest；TR-6→ChartPageDomTest；TR-7→OkxLiveSmokeIT+-Plive-smoke+scripts/live-smoke.sh；TR-8→全量本地 stub+冻结 fixture，Playwright 浏览器构建期获取并 README 记录；TR-9/TR-10→KlineSyncServiceTest 专用用例；429/非 2xx/非法 JSON/超时由 StubOkxServer 内联正文与挂起策略构造。", "smoke 隔离：默认 surefire 排除 **/smoke/**（叠加 *IT 命名双保险）；live-smoke profile 以 combine.self=override 清空排除并仅 include OkxLiveSmokeIT；OkxMarketClient 为构造式无 Spring 注解依赖，可被 smoke 直接 new 以直连 www.okx.com。", "兼容矩阵首日验证（契约 Risk Area 1）：实现首日验证 spring-boot 4.1.0 + mybatis-plus-spring-boot4-starter 3.5.17 + sqlite-jdbc + flyway（SQLite 支持归属 flyway-core 还是附加模块）的坐标解析与最小上下文装配；如需 flyway-database-sqlite 等坐标仅添加于已授权 pom.xml。", "基线文件修改点：verify-workspace.sh 仅将 test ! -e pom.xml / test ! -d src 翻转为存在性断言，保留 Java 25、清洁树与只读 OKX 探测；.gitignore 仅补 *.db-journal 与 data/；README 重写覆盖 AC-8 全部条目。" ],
  "missing_evidence" : [ ],
  "must_fix" : [ ],
  "open_risks" : [ "Spring Boot 4.1.0 与 mybatis-plus-spring-boot4-starter 3.5.17、xerial sqlite-jdbc、Flyway 的坐标解析与装配需实现首日以最小上下文验证（契约 Risk Area 1）；若 Flyway SQLite 需附加模块坐标，仅修改已授权 pom.xml。", "Hikari data-source-properties 传递 xerial pragma（journal_mode/busy_timeout）的键名绑定需首日验证；备选为 JDBC URL 参数或 yml 显式键，不影响语义。", "Playwright for Java 浏览器二进制需构建期获取或预置本地路径（TR-8/README 记录）；离线构建环境缺二进制时 ChartPageDomTest 无法执行，属环境准备项而非设计缺口。", "live smoke 依赖公网 OKX 可用性与限流策略，可能偶发非确定性失败；仅影响显式 opt-in 命令，不影响默认 mvn test。", "vendored KLineCharts 具体版本在实现时锁定（9.x UMD）并写入 README，避免后续无意识升级引入行为漂移。" ],
  "verification_summary" : "本阶段仅产出实现就绪设计：已核对 TaskContract、REQUIREMENT.md 与基线仓库文件，planned_files 与批准 scope 完全一致；未执行任何代码实现、构建或测试运行。",
  "design" : {
    "planned_files" : [ {
      "path" : ".gitignore",
      "responsibility" : "补充 SQLite 运行期产物忽略（*.db-journal、data/ 目录），与既有 *.db/*.db-wal/*.db-shm 共同覆盖默认数据库文件及辅助文件。",
      "operation" : "MODIFY"
    }, {
      "path" : "README.md",
      "responsibility" : "重写为交付文档：架构、配置表（okx.sync.* 与 OKX_KLINE_SQLITE_PATH 环境变量）、SQLite 默认路径、启动、离线 mvn test、live smoke 命令、API 契约、数据新鲜度语义（confirm=0/1、闭合行可被后续合法响应修正、最新价可能滞后一个轮询周期）与已知限制。",
      "operation" : "MODIFY"
    }, {
      "path" : "pom.xml",
      "responsibility" : "Spring Boot 4.1.0 parent + Java 25；依赖 spring-boot-starter-web、com.baomidou:mybatis-plus-spring-boot4-starter:3.5.17、org.flywaydb:flyway-core、org.xerial:sqlite-jdbc；测试依赖 spring-boot-starter-test 与 com.microsoft.playwright:playwright；surefire 默认排除 **/smoke/**，live-smoke profile 覆盖排除并仅执行 OkxLiveSmokeIT。",
      "operation" : "CREATE"
    }, {
      "path" : "scripts/live-smoke.sh",
      "responsibility" : "显式 opt-in 包装：mvn -Plive-smoke test，仅触发直连 OKX 官方公开接口的只读 smoke，不进入默认测试。",
      "operation" : "CREATE"
    }, {
      "path" : "scripts/verify-workspace.sh",
      "responsibility" : "将基线断言 test ! -e pom.xml、test ! -d src 翻转为 test -f pom.xml、test -d src；保留 Java 25 校验、清洁树校验与只读 OKX 探测。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/com/example/okxkline/OkxKlineApplication.java",
      "responsibility" : "@SpringBootApplication 启动类 + @MapperScan(com.example.okxkline.mapper)；main 中仅为配置的 SQLite 路径创建父目录（初始化准备，不含任何建表逻辑）。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/config/OkxSyncProperties.java",
      "responsibility" : "@ConfigurationProperties(okx.sync)：base-url、connect-timeout、read-timeout(Duration)、enabled、fixed-delay(Duration)，经宽松绑定支持环境变量覆盖；limit 固定常量 300，不配置化。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/domain/Kline.java",
      "responsibility" : "纯领域 record：instrument、bar、openTime(long 毫秒)、open/high/low/close/volume/volumeCcy/volumeCcyQuote(BigDecimal)、confirmed(boolean)；服务层与 API 的 decimal-safe 权威载体。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/OkxMarketClient.java",
      "responsibility" : "构造式注入 OkxSyncProperties，基于 RestClient+JDK HttpClient 按 base-url/超时构建；GET /api/v5/market/candles?instId=BTC-USDT&bar=1m&limit=300；负责 HTTP 状态、JSON envelope（code=='0'、data 数组）校验并委托 CandleRowParser，返回 List<Kline>；失败抛出带分类枚举（TIMEOUT/HTTP_STATUS/RATE_LIMITED/BUSINESS_ERROR/MALFORMED_RESPONSE/MALFORMED_ROW）与脱敏摘要的 OkxCallException；无 Spring 注解依赖，可被 live smoke 直接构造。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/okx/CandleRowParser.java",
      "responsibility" : "纯静态行解析器：校验 9 字段、数值可解析 BigDecimal、ts 为正整数毫秒、confirm∈{0,1}；仅做格式校验，明确不做价格大小/方向等行情语义校验；输出 domain Kline。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/entity/KlineEntity.java",
      "responsibility" : "MyBatis-Plus @TableName(kline) 实体；价格/成交量以 String 承载 TEXT 列（存储编码），confirm 为 Integer 0/1，openTime 为 Long；提供与 domain Kline 的双向转换（toPlainString/BigDecimal 构造），全链路无 float/double。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/mapper/KlineMapper.java",
      "responsibility" : "extends BaseMapper<KlineEntity>；核心单条 @Insert upsert：ON CONFLICT(instrument,bar,open_time) DO UPDATE SET 全部行情字段=excluded.对应字段、confirm=excluded.confirm、updated_at=excluded.updated_at WHERE excluded.confirm=1 OR kline.confirm=0；另有 @Select 以子查询取最近 N 行并按 open_time 升序返回；无任何删除语句。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/mapper/SyncStateMapper.java",
      "responsibility" : "MyBatis 注解 mapper：读取 id=1 单行状态；按轮次结果 UPDATE state/last_attempt_at/last_success_at/last_error_category/last_error_summary；无删除。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/KlineSyncService.java",
      "responsibility" : "同步引擎：ApplicationReadyEvent 启动回填 + @Scheduled(fixedDelayString 与 initialDelayString 取 okx.sync.fixed-delay) 轮询；AtomicBoolean 在飞守卫；syncOnce 先 recordAttempt，再完整获取+校验（解析期失败零写入），随后 TransactionTemplate 短事务内逐行 upsert（事务仅包 DB 写、不包 HTTP），成功 recordSuccess、失败按分类 recordFailure 并等待下一轮（无立即重试）；日志仅记状态/耗时/行数/错误分类，不打响应正文。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/sync/SyncStateService.java",
      "responsibility" : "同步生命周期 owner：读写 sync_state 单行；状态 PENDING/OK/DEGRADED/DISABLED 仅由轮次结果分类枚举驱动（错误文本只是≤200 字符有界展示摘要，绝不参与状态判定）；暴露嵌套 SyncHealthView 供 API。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/MarketController.java",
      "responsibility" : "GET /api/klines?limit=（缺省 300；非正整数或>300 抛 InvalidLimitException→400）：经 mapper 取最近 N 行升序返回 domain Kline；GET /api/sync/health 返回状态视图；仅读本应用 SQLite。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/java/com/example/okxkline/web/GlobalExceptionHandler.java",
      "responsibility" : "@RestControllerAdvice：InvalidLimitException 与参数类型错误→400 明确客户端错误 JSON；未捕获异常→500 通用信息，不泄漏内部细节。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/application.yml",
      "responsibility" : "声明式配置：datasource url jdbc:sqlite:${OKX_KLINE_SQLITE_PATH:./data/okx-kline.db}、Hikari maximum-pool-size=1、journal_mode=WAL、busy_timeout=5000；flyway classpath:db/migration；jackson write-bigdecimal-as-plain；spring.task.scheduling.pool.size=1；okx.sync 默认值（www.okx.com、connect 5s、read 10s、enabled=true、fixed-delay 15s）。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/db/migration/V1__init_kline_schema.sql",
      "responsibility" : "Flyway V1：kline 表（UNIQUE(instrument,bar,open_time)、confirm CHECK 0/1、价格/成交量 TEXT、open_time INTEGER 毫秒、updated_at TEXT）与 sync_state 单行表（state CHECK、时间与错误字段），并种子 INSERT id=1 PENDING 行；唯一且版本化的建表入口。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/index.html",
      "responsibility" : "首屏即行情页：仅引用本地 /vendor/klinecharts.min.js、/app.js、/styles.css（零外链）；头部信息区（BTC / USDT、1m、最新收盘价、最近闭合 K 线时间、同步状态、最近刷新时间）、图表容器、无数据/降级/错误状态区。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/app.js",
      "responsibility" : "加载即拉取 /api/klines 与 /api/sync/health；KLineCharts 蜡烛图+VOL 成交量（timestamp 毫秒转秒）；setInterval 10 秒 applyNewData 刷新不整页重载；失败保留旧图并显示状态；空数据与首次加载提示；全部请求相对路径仅指向本应用。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/styles.css",
      "responsibility" : "桌面/移动响应式布局，信息区、状态区、图表不重叠；克制的 degraded 状态样式。",
      "operation" : "CREATE"
    }, {
      "path" : "src/main/resources/static/vendor/klinecharts.min.js",
      "responsibility" : "构建期固定的 KLineCharts UMD 产物（版本锁定并记录于 README），运行时零 CDN。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/CandleRowParserTest.java",
      "responsibility" : "纯单测：合法行、BigDecimal 精确保持、ts 毫秒语义、confirm 0/1；非法：字段数≠9、非数值、非正 ts、confirm 越界、空字段。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/okx/OkxMarketClientTest.java",
      "responsibility" : "经 StubOkxServer：正常 envelope、code≠0、非 2xx、429、非法 JSON、读超时（挂起不回包）；断言查询参数 instId=BTC-USDT&bar=1m&limit=300 与异常分类。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/KlineSyncServiceTest.java",
      "responsibility" : "真实上下文（stub OKX+临时 SQLite+长 fixed-delay 隔离调度）：启动回填 TR-9（300 行 fixture，断言由启动流程触发的请求与 300 行升序入库）；倒序/乱序输入；重复同步幂等；confirm 0→1 原位更新；闭合行 confirm=1→1 更新被接受、confirm=1 遇 0 不回退不覆盖（TR-10）且无删除；陈旧响应不删较新行；非法 envelope/行整轮零写入+DEGRADED+无立即重试（请求计数静止）；嵌套 @TestConfiguration 注入第 N 行抛错的 mapper 代理验证事务回滚零写入。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/sync/SchedulerOverlapTest.java",
      "responsibility" : "fixed-delay 约 1s + stub 响应约 5s：断言并发峰值=1、请求串行；另以两线程并发调 syncOnce 验证在飞守卫跳过。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/persistence/KlinePersistenceTest.java",
      "responsibility" : "临时 SQLite 文件库：MP BaseMapper.insert 重复键证明唯一约束生效、upsert 幂等；关闭上下文后以新上下文复用同一文件模拟重启，已闭合 K 线仍可查询。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/MarketControllerTest.java",
      "responsibility" : "MockMvc+真实库：升序与 300 上限、limit 缺省与 0/301/abc→400 明确信息、health 字段完整性、同步失败后 klines 仍返回既有数据。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/web/ChartPageDomTest.java",
      "responsibility" : "Playwright 加载随机端口应用（OKX 指向 stub）：断言图表 canvas 渲染消费 /api/klines、等待 10 秒周期请求且无主框架导航、全部网络请求仅命中本应用源（无 okx.com、无 CDN、无 stub 直连）。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/support/StubOkxServer.java",
      "responsibility" : "基于 JDK com.sun.net.httpserver 的契约一致 stub：可编程状态码/正文/延迟/挂起不回包；记录请求与并发计数；零新增依赖。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/java/com/example/okxkline/smoke/OkxLiveSmokeIT.java",
      "responsibility" : "仅 -Plive-smoke 执行：直接构造 OkxMarketClient（默认 www.okx.com 配置）发起一次只读 GET，断言至少一根结构合法（9 字段、confirm∈{0,1}、开盘时间对齐分钟）的 BTC-USDT 1m K 线。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-normal.json",
      "responsibility" : "冻结 300 行 BTC-USDT 1m 响应（ts 新→旧、分钟对齐，最新一根 confirm=0 其余 1），驱动启动回填与幂等用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-reversed.json",
      "responsibility" : "冻结倒序/乱序小集合（含早于本地已有数据的键），驱动乱序与陈旧响应不删较新数据用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-unconfirmed.json",
      "responsibility" : "冻结同一 open_time 的 confirm=0 与 confirm=1 两个响应版本，驱动未闭合 K 线原位更新用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/candles-malformed-row.json",
      "responsibility" : "code=0 但含非法行（字段数/数值/confirm 越界其一）的冻结响应，驱动整轮拒绝零写入用例。",
      "operation" : "CREATE"
    }, {
      "path" : "src/test/resources/fixtures/okx/envelope-error.json",
      "responsibility" : "code≠0 的业务错误冻结响应（如限流），驱动 BUSINESS_ERROR 用例。",
      "operation" : "CREATE"
    } ]
  },
  "stage_outcome" : "READY",
  "stage_outcome_source" : "declared_status",
  "evidence_state" : {
    "blocking" : false,
    "evidence_count" : 14,
    "missing_evidence_count" : 0,
    "must_fix_count" : 0,
    "acceptance_note_count" : 0,
    "open_risk_count" : 5
  },
  "authored_context" : {
    "sha256" : "540f6ad30b33cf2c1abafa7de9cfafc31ad264a733e3ba6ee8be4004bcec5d17",
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789169462819/prompts/design-claude.md.manifest.json"
  }
}


## Active obligations

[ {
  "id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:0",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json",
    "sha256" : "4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210"
  },
  "text" : "AR-1：明确行情提交与成功状态的事务边界。优先让行情 upsert 和成功状态在同一短事务提交，避免 recordSuccess 失败后把已提交行情描述为失败轮零写入。另明确尝试记录、失败记录自身遇到数据库异常时的有界处理、健康接口结果及守卫释放；数据库不可写时不得声称已持久化 DEGRADED。补充状态写入失败、提交失败与重启读取的故障测试。"
}, {
  "id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:1",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json",
    "sha256" : "4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210"
  },
  "text" : "AR-2：由 SyncStateService 明确拥有启动时 enabled 配置对应的状态转换。禁用时不得继续返回旧 OK 或种子 PENDING；重新启用时不得沿用旧 DISABLED。保留历史尝试、成功和失败信息，并测试首次禁用、成功后禁用重启及重新启用，确认禁用期间零 OKX 请求。"
}, {
  "id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:2",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json",
    "sha256" : "4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210"
  },
  "text" : "AR-3：统一 API 的公开字段与 domain Kline 序列化结果，并明确 app.js 的 OHLCV 和时间适配。核实固定图表版本的 timestamp 单位后决定是否转换；ChartPageDomTest 须通过真实 API 响应核对图表实际消费的时间、价格、成交量及后续刷新结果，不能仅证明 canvas 存在与请求发生。"
}, {
  "id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:3",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json",
    "sha256" : "4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210"
  },
  "text" : "AR-4：将失败摘要收敛为固定分类与受控字段，或定义可验证的外部文本清理规则；仅截断业务 msg 不足以支持安全摘要声明。补充包含控制字符和敏感样式文本的错误响应测试，验证健康 JSON、页面和日志不暴露未经处理的内容。"
}, {
  "id" : "sha256:4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210#must_fix:4",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/runs/run-1789170046878/outputs/design-codex-review.contract.json",
    "sha256" : "4bea5bad54ccaf0660f1980bc23e591a0836984ea6de734028d668261aae7210"
  },
  "text" : "AR-5：修正 README 与前端的新鲜度说明，不得承诺最多滞后一个轮询周期。明确最近成功同步时间不等于行情最新时间，陈旧缓存和连续失败可能导致更长滞后；展示继续使用真实行情时间与最近成功时间。"
}, {
  "id" : "sha256:a93bafaa80b5336b0cf7d6b463798e868a9d0bb03e4fd24c8b28fc537b542305#human-note:0",
  "source" : {
    "ref" : ".agent/workstreams/ws-20260911T231749Z-GCTW/gates/gate-node-gate-human_design_approval-023.json",
    "sha256" : "a93bafaa80b5336b0cf7d6b463798e868a9d0bb03e4fd24c8b28fc537b542305"
  },
  "text" : "接受AR-1至AR-5，保持当前批准TaskContract和37项路径不变，一次性同步checks/evidence/planned_files/测试描述。AR-1：删除每轮解析前recordAttempt写库；获锁后attemptAt仅在内存，HTTP获取及整个envelope和所有行校验完成后，在同一短事务内提交整批upsert与attempt/success/OK状态。失败回滚后再用独立短事务记录attempt/DEGRADED；状态写入本身失败时仅有界报告，不谎称持久化成功，finally释放守卫。补完整故障断言。AR-2：明确SyncStateService的启动enabled/disabled转换，保留历史时间，禁用零请求，覆盖禁用/重启/重新启用。AR-3：统一实际JSON字段与图表OHLCV映射，依据固定图表版本的真实接口确定timestamp单位，不臆测毫秒转秒；浏览器测试核对真实API数据、图表实际数据与刷新，不以canvas存在替代。AR-4：错误摘要使用固定分类与受控字段，不透传或仅截断外部msg；覆盖控制字符与敏感样式响应。AR-5：删除最多滞后一轮的承诺，分别展示行情时间与最近成功时间。其余已闭合的confirm更新规则、schema、scope保持不变，不新增框架、文件或平台。"
} ]
