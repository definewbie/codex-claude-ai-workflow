# Agent Run Governance Context

- Workstream: ws-20260911T231749Z-GCTW
- Target Node: design.claude_design
- Agent Node Instance: node-design-claude_design-024
- Run Id: run-1789170184692
- Generated At: 2026-09-11T23:43:04.782298Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-claude_design-024-run-1789170184692/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-claude_design-024-run-1789170184692/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-claude_design-024-run-1789170184692/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20260911T231749Z-GCTW/artifacts/context-governance/occurrences/node-design-claude_design-024-run-1789170184692/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .gitignore
  - README.md
  - pom.xml
  - scripts/live-smoke.sh
- Expected edit files: (none planned)
