# OKX BTC K 线演示应用

这是一个专门用于 fresh Dual real-case 的未实现基线仓库。

产品需求以 `REQUIREMENT.md` 为权威来源。实现必须由唯一 fresh workstream 完成，并严格使用 Java 25、Spring Boot 4.1.0、MyBatis-Plus 3.5.17 和 SQLite。

冻结基线中没有产品代码或构建文件。生产应用与显式 live smoke 必须直接调用 OKX 官方公开 API；只有确定性自动化测试可以使用本地协议桩模拟超时、限流、乱序和畸形响应。

