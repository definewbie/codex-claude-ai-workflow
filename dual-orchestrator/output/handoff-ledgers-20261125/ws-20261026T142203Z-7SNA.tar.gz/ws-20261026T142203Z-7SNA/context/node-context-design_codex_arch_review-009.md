# Context Package

- Workstream: ws-20261026T142203Z-7SNA
- Builder Node: context.design_codex_arch_review
- Target Node: design.codex_arch_review
- Generated At: 2026-10-26T15:49:16.519025Z
- Profile: architecture_review
- Total: 2.4k / 5.0k tokens

## Context Governance

| Section | Level | Degraded | Original | Current |
|---|---|---|---|---|
| input_artifacts | full | no | 424 | 424 |
| review_evidence | full | no | 203 | 203 |
| human_feedback | full | no | 39 | 39 |
| iteration_history | full | no | 54 | 54 |
| recent_agent_outputs | full | no | 266 | 266 |
| ledger_pointers | pointer_only | yes | 217 | 173 |
| required_architecture_review_subject | full | no | 1.3k | 1.3k |

Degraded sections have full data at their original paths listed below.

## State & Evidence Boundary

This package separates deterministic harness facts from agent proposals.

### Trusted Harness Facts

- TaskContract: READY_FOR_REVIEW - 在既有 Java 项目 assess-income phase-one 的 90 天历史情景评估中新增可解释指标：在相同 90 天窗口、投入资金、对冲空头名义金额和固定已知成本口径下，资金费净收入追平简单赚币所需的整个 90 天累计资金费率阈值，由 PhaseOneAssessmentService 计算、PhaseOneAssessment record 承载、CLI 只读展示，并保留证据不足时的不可用语义。 (.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.json)
- Git Evidence: not generated yet

### Human Decisions

- Requirement Resolution: APPROVE by human_gate (.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/contract-resolution.json)

### Agent Proposed States

- design.claude_design: decision=READY_FOR_ARCH_REVIEW, stageOutcome=READY, evidenceState={blocking=false, evidence_count=8, missing_evidence_count=0, must_fix_count=0, acceptance_note_count=0, open_risk_count=2} (/Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.contract.json)

### Pending Contract/Evidence Gaps

- No contract failure diagnostics recorded

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Repo map: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-009/repo-map.json
- Repository fact binding: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-009/binding.json
- Tracked inventory: count=0; head=; sha256=

- File relevance plan: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-009/file-relevance-plan.json
- Stage scope policy: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-009/stage-scope-policy.json
- Workstream memory: .agent/workstreams/ws-20261026T142203Z-7SNA/memory/workstream-memory.json
- Working set: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-009/working-set.json
- File summaries: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-009/file-summaries.json
- Read reuse contract: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-009/read-reuse-contract.json
- Agent capability catalog: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-009/agent-capability-catalog.json
- Governance report: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-design_codex_arch_review-009/planned-report.json

- Recommended read files: (none planned)
- Contract scope candidates: (none planned)
- Allowed write files: (none planned)
- Forbidden scope:
  - .git/**
  - .agent/workstreams/**/workflow/**
  - .agent/workstreams/**/nodes/**
  - business source writes
- Already inspected files:
  - README.md
  - src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java
  - src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java
  - src/main/java/app/cryptoincome/assessment/domain/SmartArbitrageCosts.java
  - src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java
  - src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java
  - src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java
  - src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java
- Read reuse contract: the following files were already inspected and their recorded sha is still trusted. Reuse the summary first; re-read only if you need exact current contents for editing or verification.
  - CLAUDE.md: headings: CLAUDE.md; Project Status; What This Project Is; Implemented Tech Stack; Architecture Rules (from the design docs — these are constraints, not suggestions) | relevant: Phase 1's first data slice is implemented and peer-review hardening is complete: OKX public funding-rate history is val…; A local, read-only personal tool for managing ~200,000 USDT of crypto income via existing OKX produ…
  - README.md: headings: AI Crypto Income Assistant（ai-crypto-arbitrage）; 程序当前能做什么; 程序不做什么; 快速开始; CLI 命令与退出码
  - docs/09-Phase-1-Test-Runbook.md: headings: 第一期测试手册; 1. 测试目标与边界; 2. 固定测试口径; 3. 准备环境并运行自动化测试; 4. 回补 90 天资金费率
  - docs/README.md: headings: AI Crypto Income Assistant; 目标; 三条原则; 赚钱第一; 工程第二 | relevant: 管理约 **200,000 USDT**，通过 OKX 已有产品（智能套利、简单赚币、现货网格等），在可接受风险下争取 **10%–20% 长期年化净收益**。; `mvn -version` 输出中的 Java 必须是 JDK 25。仅安装 JDK 但 Maven 仍指向旧 Java 时，项目无法按当前基线编译。; 测试会通过 Testcontainers 启动独立的 MySQL 8.4，不会使用或清空上面启动的本地数据库。首次运行需要下载 Maven 依赖和 Docker image，因此时间会稍长。; sync-market latest --instrument BTC-USDT-SWAP --limit 100 --request-key…
  - src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java: Previously read source file (5990 bytes).
  - src/main/java/app/cryptoincome/assessment/domain/EvidenceStatus.java: Previously read source file (161 bytes).
  - src/main/java/app/cryptoincome/assessment/domain/FundingHistoryEvidence.java: Previously read source file (426 bytes).
  - src/main/java/app/cryptoincome/assessment/domain/OpeningCost.java: Previously read source file (1287 bytes).
  Do not re-read these files unless this stage needs exact current contents; this target artifact does not declare a reread reason field, so the harness will judge re-reads from changed_files, invalidation, and allowed-reread policy.
Read recommendations are context only. GOAL design/plan files are proposals; edits require approved EXECUTION scope and Git evidence.

## Input Artifacts

### .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.stderr.log

(execution diagnostic omitted from context)

### .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.transcript.log

(execution transcript omitted from context; inspect raw file at /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.transcript.log)

### .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.json

- Contract: design.claude_design
- Decision: READY_FOR_ARCH_REVIEW
- Summary: 在 PhaseOneAssessmentService 既有充分证据分支内新增与增量比较同可用条件的“90 天累计资金费率追平阈值”typed 字段，CLI 只读展示并附中文使用说明与配套测试。
- Open Risks: CLI 展示值依赖 DECIMAL128 除法结果，测试以“标签+6 位小数百分比”的正则/包含断言为准，不在 CLI 测试中重算数值，避免展示口径二次实现。; TR-4 完整基线回归含 Testcontainers MySQL，执行阶段需 Docker 可用，并以 Maven Surefire 报告作为程序化通过依据；该验证属后续执行节点，本设计阶段未运行。
- Verification: 仅设计阶段：完成代码与合同核对及样例手工验算，未实现代码、未运行测试。
- Contract Sidecar: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.contract.json
- Raw Output: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.json

### .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-008-run-1793027503466/binding.json

(routed artifact has no typed context projection; content omitted)

## Review Evidence Brief

TaskContract projection: qualified_projection

No cumulative review verdict recorded. Review the complete current subject against the contract baseline.

- Relevant memory (reuse, do not re-read): CLAUDE.md; README.md; docs/09-Phase-1-Test-Runbook.md; docs/README.md; src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java

Derive the complete current blocker set from the review subject and acceptance criteria; re-read a file only with a reason (edit/verify/sha-changed/stage-gap).
Evidence: memory .agent/workstreams/ws-20261026T142203Z-7SNA/memory/workstream-memory.json; diff .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/git-evidence/diff.patch; changed .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/git-evidence/changed-files.txt.

## Human Feedback

### gate.human_requirement_review

- Action: approved
- Finished At: 2026-10-26T15:10:44.352864Z

```text
用户当前批准GOAL需求；实现权限及交付另行批准。
```

## Iteration History

### iter-001

- Parent: (none)
- Trigger: workflow_started
- Target Node: context.intake_claude_brainstorm
- Created At: 2026-10-26T14:22:03.577440Z

```text
Initial workflow iteration.
```

## Recent Agent Outputs

### /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.contract.json

- Contract: design.claude_design
- Decision: READY_FOR_ARCH_REVIEW
- Summary: 在 PhaseOneAssessmentService 既有充分证据分支内新增与增量比较同可用条件的“90 天累计资金费率追平阈值”typed 字段，CLI 只读展示并附中文使用说明与配套测试。
- Open Risks: CLI 展示值依赖 DECIMAL128 除法结果，测试以“标签+6 位小数百分比”的正则/包含断言为准，不在 CLI 测试中重算数值，避免展示口径二次实现。; TR-4 完整基线回归含 Testcontainers MySQL，执行阶段需 Docker 可用，并以 Maven Surefire 报告作为程序化通过依据；该验证属后续执行节点，本设计阶段未运行。
- Verification: 仅设计阶段：完成代码与合同核对及样例手工验算，未实现代码、未运行测试。
- Contract Sidecar: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.contract.json
- Raw Output: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.json

## Ledger Pointers

- Events: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/events.jsonl
- Workflow current: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws

[adaptively compressed; section degraded to stay within ~125 tokens; full source remains in ledger under /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA]

## Required Architecture Review Subject

- Contract: design.claude_design
- Decision: READY_FOR_ARCH_REVIEW
- Summary: 在 PhaseOneAssessmentService 既有充分证据分支内新增与增量比较同可用条件的“90 天累计资金费率追平阈值”typed 字段，CLI 只读展示并附中文使用说明与配套测试。
**Checks:**
- 已读取经人工门批准的 Task Contract（APPROVE），设计严格对齐 AC-1 至 AC-5、TR-1 至 TR-4、约束与排除项，不触碰采集、迁移、持仓、调度、组合策略、Web 页面与 Dual 生产代码。
- 计算口径核对：阈值 =(simpleEarnIncome + costs.knownTotal())/hedgedShortNotional，与既有增量路径共用同一分子口径，不重复计费；该值是与 fundingHistory.holdingReturn 同单位的整个 90 天累计费率，任何位置都不做 APR 化、按结算次数或假定 8 小时间隔换算。
- 独立验算 AC-2 样例：20000×0.0365×90/365=180；阈值=(180+20)/10000=0.02；累计费率 0.019/0.020/0.021 时资金费收入 190/200/210，扣除成本 20 后净收入 170/180/190，既有同口径增量恰为 -10/0/+10 USDT，0.02 为精确终止小数。
- 可用性语义核对：阈值仅在 blockers 与 unknowns 均为空的既有充分证据分支（条款已确认、窗口内有已实现结算、成本完整、terminal-policy=exit-to-usdt）计算，其余分支一律 Optional.empty，与 estimatedFundingOnlyNetIncome/incrementalIncomeVsSimpleEarn 完全一致，沿既有 blockers/unknowns 说明原因，不填 0、不猜数。
- 零或非法名义金额复用 PhaseOneAssessmentRequest 既有校验（hedgedShortNotional.signum()<=0 抛 IllegalArgumentException，发生在读取事实之前），不新增校验路径。
- 精度规则显式：分子为既有 DECIMAL128 计算的 simpleEarnIncome 加精确 knownTotal，除法使用与服务既有一致的 MathContext.DECIMAL128（34 位有效数字，非终止小数安全）；record 存原始未舍入值，CLI 仅展示层用既有 percent()（×100、6 位小数、HALF_UP）格式化，舍入值绝不回流影响建议。
- 构造点核查：全仓库仅 PhaseOneAssessmentService 构造 PhaseOneAssessment record；DecisionWorkbenchController 只经服务评估并按访问器消费（smartView），新增组件对 Web 只读路径无影响、无需修改。
- 生命周期边界适用性声明：本设计仅新增一次 assess() 调用内的纯派生不可变值，无索引、锁、事务、队列、缓存、外部副作用或补偿，评估保持只读、不创建 analysis_run；并发、超时、中断、重启、回滚与防绕过边界均不适用且不因本变更改变。
- 回归边界：既有建议逻辑、首次小额验证上限 5000 USDT、成本与未知项语义、退出码与限制提示全部保持不变；CLI 既有断言基于 contains，追加限制子句不破坏现有测试。

**Evidence:**
- src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java:42-50（simpleEarnIncome/knownCost 既有口径）与 :79-101（三分支证据判定；阈值计算落在 :87-91 的 else 分支，与 netIncome/incremental 同时置值）。
- src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java:7-21：新组件 Optional<BigDecimal> breakEvenCumulativeFundingRate 拟插入 incrementalIncomeVsSimpleEarn 之后、evidenceStatus 之前。
- src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java:38-40 既有 hedgedShortNotional>0 校验；SmartArbitrageCosts.java:29-50 knownTotal()/unknowns() 决定分子口径与不可用原因。
- src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java:160-163（净收益/增量“无法精确计算”展示惯例）、:183（限制行）、:305-307（percent() 格式化）：新阈值行置于增量行之后，未可用时打印“无法精确计算”，理由已由上方未知项/阻断项行给出；限制行追加一句“阈值是同口径历史追平点，不是年化或预测”。
- src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java 与 src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java：现有 fixture 结构（service()/request()/completeCosts()/completeArguments()）可直接扩展承载 TR-1/TR-2/TR-3。
- docs/README.md 编号惯例 01–14，新说明文档沿用为 docs/15-Funding-Rate-Break-Even-Threshold.md（与合同 Risk Areas 建议一致）。
- 数学不变量（测试锚点）：hedgedShortNotional×阈值 = simpleEarnIncome+knownTotal，故累计费率恰等于阈值时既有增量精确为 0（仅终止小数样例精确成立；除不尽场景按 DECIMAL128 后 setScale(6,HALF_UP) 断言）。
- 合同依据：.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.md（AC/TR/约束/风险区）与 contract-resolution.md（human_gate APPROVE，2026-10-26T15:11:09Z）。

- Open Risks: CLI 展示值依赖 DECIMAL128 除法结果，测试以“标签+6 位小数百分比”的正则/包含断言为准，不在 CLI 测试中重算数值，避免展示口径二次实现。; TR-4 完整基线回归含 Testcontainers MySQL，执行阶段需 Docker 可用，并以 Maven Surefire 报告作为程序化通过依据；该验证属后续执行节点，本设计阶段未运行。
- Verification: 仅设计阶段：完成代码与合同核对及样例手工验算，未实现代码、未运行测试。
- Contract Sidecar: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.contract.json
- Raw Output: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.json

### Declared Planned Files

- MODIFY `src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java`: 在 incrementalIncomeVsSimpleEarn 之后新增组件 Optional<BigDecimal> breakEvenCumulativeFundingRate（90 天累计资金费率追平阈值，未舍入 DECIMAL128 原值），仅承载 typed 结果，不引入新校验或逻辑。
- MODIFY `src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java`: 在既有无阻断且无未知项的充分证据分支计算 simpleEarnIncome.add(knownCost).divide(hedgedShortNotional, CALCULATION_CONTEXT) 并置入新字段；其余分支保持 Optional.empty；建议、上限、blockers/unknowns 语义完全不变。
- MODIFY `src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java`: 只读展示新字段：在“相对简单赚币增量”行后新增一行“90天累计资金费率阈值=<percent 或 无法精确计算>”，并在末尾限制行追加“同口径历史追平点，非年化、非预测”子句；不重算、不影响建议与退出码。
- MODIFY `src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java`: TR-1/TR-2：独立样例（对照收益 180、阈值 0.02，累计费率 0.019/0.020/0.021 对应增量 -10/0/+10，断言基于 BigDecimal 原值）；零已知成本（0.018）、零 APR（0.002）、负资金费率仍可用、除不尽精度（如名义 3000 得 0.066667）；成本缺失/条款未确认/无历史结算/期末保持开放时阈值为空且沿 blockers/unknowns；零与负名义金额在读取事实前被既有校验拒绝。
- MODIFY `src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java`: TR-3：完整证据时输出含“90天累计资金费率阈值=”及 6 位小数百分比数值；证据不足时输出“90天累计资金费率阈值=无法精确计算”且不打印数值；既有建议文案、首次实盘上限、退出码与限制提示断言保留不回归。
- CREATE `docs/15-Funding-Rate-Break-Even-Threshold.md`: 简体中文使用说明：定义与公式、AC-2 样例与 0.019/0.020/0.021 边界表、可用与不可用条件、BigDecimal/DECIMAL128 精度与仅展示层舍入规则、历史情景限制（非预测、非建议、区间完整性未证明），并指向 docs/09 测试手册。



# Required Authored Context

The following verified inputs are mandatory. Respond to every active obligation; ADDRESSED does not close it. Use NOT_ADDRESSED honestly. Initial authors return [].

## Active obligations

[ ]

## Current review candidate

.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.contract.json

{
  "artifact_type" : "agent_output_contract",
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793027503466",
  "node_id" : "design.claude_design",
  "node_instance_id" : "node-design-claude_design-008",
  "handler_type" : "acpx.agent_run",
  "decision" : "READY_FOR_ARCH_REVIEW",
  "summary" : "在 PhaseOneAssessmentService 既有充分证据分支内新增与增量比较同可用条件的“90 天累计资金费率追平阈值”typed 字段，CLI 只读展示并附中文使用说明与配套测试。",
  "required_keys" : [ "summary", "decision" ],
  "allowed_decisions" : [ "READY_FOR_ARCH_REVIEW" ],
  "source_output_ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.json",
  "source_artifact_type" : "design_result",
  "generated_at" : "2026-10-26T15:18:00.473186Z",
  "control" : {
    "summary" : "在 PhaseOneAssessmentService 既有充分证据分支内新增与增量比较同可用条件的“90 天累计资金费率追平阈值”typed 字段，CLI 只读展示并附中文使用说明与配套测试。",
    "decision" : "READY_FOR_ARCH_REVIEW"
  },
  "control_source" : {
    "kind" : "strict_agent_result_envelope"
  },
  "revision_responses" : [ ],
  "lifecycle_status" : "READY",
  "checks" : [ "已读取经人工门批准的 Task Contract（APPROVE），设计严格对齐 AC-1 至 AC-5、TR-1 至 TR-4、约束与排除项，不触碰采集、迁移、持仓、调度、组合策略、Web 页面与 Dual 生产代码。", "计算口径核对：阈值 =(simpleEarnIncome + costs.knownTotal())/hedgedShortNotional，与既有增量路径共用同一分子口径，不重复计费；该值是与 fundingHistory.holdingReturn 同单位的整个 90 天累计费率，任何位置都不做 APR 化、按结算次数或假定 8 小时间隔换算。", "独立验算 AC-2 样例：20000×0.0365×90/365=180；阈值=(180+20)/10000=0.02；累计费率 0.019/0.020/0.021 时资金费收入 190/200/210，扣除成本 20 后净收入 170/180/190，既有同口径增量恰为 -10/0/+10 USDT，0.02 为精确终止小数。", "可用性语义核对：阈值仅在 blockers 与 unknowns 均为空的既有充分证据分支（条款已确认、窗口内有已实现结算、成本完整、terminal-policy=exit-to-usdt）计算，其余分支一律 Optional.empty，与 estimatedFundingOnlyNetIncome/incrementalIncomeVsSimpleEarn 完全一致，沿既有 blockers/unknowns 说明原因，不填 0、不猜数。", "零或非法名义金额复用 PhaseOneAssessmentRequest 既有校验（hedgedShortNotional.signum()<=0 抛 IllegalArgumentException，发生在读取事实之前），不新增校验路径。", "精度规则显式：分子为既有 DECIMAL128 计算的 simpleEarnIncome 加精确 knownTotal，除法使用与服务既有一致的 MathContext.DECIMAL128（34 位有效数字，非终止小数安全）；record 存原始未舍入值，CLI 仅展示层用既有 percent()（×100、6 位小数、HALF_UP）格式化，舍入值绝不回流影响建议。", "构造点核查：全仓库仅 PhaseOneAssessmentService 构造 PhaseOneAssessment record；DecisionWorkbenchController 只经服务评估并按访问器消费（smartView），新增组件对 Web 只读路径无影响、无需修改。", "生命周期边界适用性声明：本设计仅新增一次 assess() 调用内的纯派生不可变值，无索引、锁、事务、队列、缓存、外部副作用或补偿，评估保持只读、不创建 analysis_run；并发、超时、中断、重启、回滚与防绕过边界均不适用且不因本变更改变。", "回归边界：既有建议逻辑、首次小额验证上限 5000 USDT、成本与未知项语义、退出码与限制提示全部保持不变；CLI 既有断言基于 contains，追加限制子句不破坏现有测试。" ],
  "evidence" : [ "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java:42-50（simpleEarnIncome/knownCost 既有口径）与 :79-101（三分支证据判定；阈值计算落在 :87-91 的 else 分支，与 netIncome/incremental 同时置值）。", "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java:7-21：新组件 Optional<BigDecimal> breakEvenCumulativeFundingRate 拟插入 incrementalIncomeVsSimpleEarn 之后、evidenceStatus 之前。", "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java:38-40 既有 hedgedShortNotional>0 校验；SmartArbitrageCosts.java:29-50 knownTotal()/unknowns() 决定分子口径与不可用原因。", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java:160-163（净收益/增量“无法精确计算”展示惯例）、:183（限制行）、:305-307（percent() 格式化）：新阈值行置于增量行之后，未可用时打印“无法精确计算”，理由已由上方未知项/阻断项行给出；限制行追加一句“阈值是同口径历史追平点，不是年化或预测”。", "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java 与 src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java：现有 fixture 结构（service()/request()/completeCosts()/completeArguments()）可直接扩展承载 TR-1/TR-2/TR-3。", "docs/README.md 编号惯例 01–14，新说明文档沿用为 docs/15-Funding-Rate-Break-Even-Threshold.md（与合同 Risk Areas 建议一致）。", "数学不变量（测试锚点）：hedgedShortNotional×阈值 = simpleEarnIncome+knownTotal，故累计费率恰等于阈值时既有增量精确为 0（仅终止小数样例精确成立；除不尽场景按 DECIMAL128 后 setScale(6,HALF_UP) 断言）。", "合同依据：.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.md（AC/TR/约束/风险区）与 contract-resolution.md（human_gate APPROVE，2026-10-26T15:11:09Z）。" ],
  "missing_evidence" : [ ],
  "must_fix" : [ ],
  "open_risks" : [ "CLI 展示值依赖 DECIMAL128 除法结果，测试以“标签+6 位小数百分比”的正则/包含断言为准，不在 CLI 测试中重算数值，避免展示口径二次实现。", "TR-4 完整基线回归含 Testcontainers MySQL，执行阶段需 Docker 可用，并以 Maven Surefire 报告作为程序化通过依据；该验证属后续执行节点，本设计阶段未运行。" ],
  "verification_summary" : "仅设计阶段：完成代码与合同核对及样例手工验算，未实现代码、未运行测试。",
  "design" : {
    "planned_files" : [ {
      "path" : "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java",
      "operation" : "MODIFY",
      "responsibility" : "在 incrementalIncomeVsSimpleEarn 之后新增组件 Optional<BigDecimal> breakEvenCumulativeFundingRate（90 天累计资金费率追平阈值，未舍入 DECIMAL128 原值），仅承载 typed 结果，不引入新校验或逻辑。"
    }, {
      "path" : "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java",
      "operation" : "MODIFY",
      "responsibility" : "在既有无阻断且无未知项的充分证据分支计算 simpleEarnIncome.add(knownCost).divide(hedgedShortNotional, CALCULATION_CONTEXT) 并置入新字段；其余分支保持 Optional.empty；建议、上限、blockers/unknowns 语义完全不变。"
    }, {
      "path" : "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java",
      "operation" : "MODIFY",
      "responsibility" : "只读展示新字段：在“相对简单赚币增量”行后新增一行“90天累计资金费率阈值=<percent 或 无法精确计算>”，并在末尾限制行追加“同口径历史追平点，非年化、非预测”子句；不重算、不影响建议与退出码。"
    }, {
      "path" : "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java",
      "operation" : "MODIFY",
      "responsibility" : "TR-1/TR-2：独立样例（对照收益 180、阈值 0.02，累计费率 0.019/0.020/0.021 对应增量 -10/0/+10，断言基于 BigDecimal 原值）；零已知成本（0.018）、零 APR（0.002）、负资金费率仍可用、除不尽精度（如名义 3000 得 0.066667）；成本缺失/条款未确认/无历史结算/期末保持开放时阈值为空且沿 blockers/unknowns；零与负名义金额在读取事实前被既有校验拒绝。"
    }, {
      "path" : "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java",
      "operation" : "MODIFY",
      "responsibility" : "TR-3：完整证据时输出含“90天累计资金费率阈值=”及 6 位小数百分比数值；证据不足时输出“90天累计资金费率阈值=无法精确计算”且不打印数值；既有建议文案、首次实盘上限、退出码与限制提示断言保留不回归。"
    }, {
      "path" : "docs/15-Funding-Rate-Break-Even-Threshold.md",
      "operation" : "CREATE",
      "responsibility" : "简体中文使用说明：定义与公式、AC-2 样例与 0.019/0.020/0.021 边界表、可用与不可用条件、BigDecimal/DECIMAL128 精度与仅展示层舍入规则、历史情景限制（非预测、非建议、区间完整性未证明），并指向 docs/09 测试手册。"
    } ]
  },
  "stage_outcome" : "READY",
  "stage_outcome_source" : "declared_status",
  "evidence_state" : {
    "blocking" : false,
    "evidence_count" : 8,
    "missing_evidence_count" : 0,
    "must_fix_count" : 0,
    "acceptance_note_count" : 0,
    "open_risk_count" : 2
  },
  "authored_context" : {
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/prompts/design-claude.md.manifest.json",
    "sha256" : "4e876bab472e2aac7035c2cb7c961472d4555700afdb2fc4672c24136e724489"
  }
}
