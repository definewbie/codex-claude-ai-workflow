# Agent Run Governance Context

- Workstream: ws-20261026T142203Z-7SNA
- Target Node: design.claude_design
- Agent Node Instance: node-design-claude_design-012
- Run Id: run-1793029979831
- Generated At: 2026-10-26T15:52:59.956651Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-012-run-1793029979831/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-012-run-1793029979831/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-012-run-1793029979831/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-012-run-1793029979831/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
## Verification readiness declarations

These are operator declarations of prerequisites, not execution results, successful tests or grants. Bind exact refs only where criterion, method, executor and environment match. If prerequisites are missing, describe the missing items without inventing references.

[ ]

