# Agent Run Governance Context

- Workstream: ws-20261026T142203Z-7SNA
- Target Node: intake.claude_brainstorm
- Agent Node Instance: node-intake-claude_brainstorm-002
- Run Id: run-1793026771764
- Generated At: 2026-10-26T14:59:31.821636Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1793026771764/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1793026771764/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1793026771764/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1793026771764/binding.json

- Tracked inventory: count=305; head=7c5facc37538b717b061bbc53da7f0c2a5bbffa0; sha256=4322f1680da5df60c8a6e2b6477c81d92521e047dd430e8aceb21706998d7f6e

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .env.example
  - .gitignore
  - CLAUDE.md
  - README.md
- Expected edit files: (none planned)
