# Context Package

- Workstream: ws-20261026T142203Z-7SNA
- Builder Node: context.intake_claude_brainstorm
- Target Node: intake.claude_brainstorm
- Generated At: 2026-10-26T14:58:55.521732Z
- Profile: intake
- Total: 173 / 3.0k tokens

## Context Governance

| Section | Level | Degraded | Original | Current |
|---|---|---|---|---|
| task_contract | full | - | 0 | 0 |
| ledger_pointers | pointer_only | yes | 217 | 173 |

Degraded sections have full data at their original paths listed below.

## State & Evidence Boundary

This package separates deterministic harness facts from agent proposals.

### Trusted Harness Facts

- TaskContract qualification: not available
- Git Evidence: not generated yet

### Human Decisions

- Requirement Resolution: not available

### Agent Proposed States

- No routed validated agent sidecars yet

### Pending Contract/Evidence Gaps

- No contract failure diagnostics recorded

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Repo map: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/repo-map.json
- Repository fact binding: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/binding.json
- Tracked inventory: count=0; head=; sha256=

- File relevance plan: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/file-relevance-plan.json
- Stage scope policy: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/stage-scope-policy.json
- Workstream memory: .agent/workstreams/ws-20261026T142203Z-7SNA/memory/workstream-memory.json
- Working set: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/working-set.json
- File summaries: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/file-summaries.json
- Read reuse contract: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/read-reuse-contract.json
- Agent capability catalog: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/agent-capability-catalog.json
- Governance report: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/planned-report.json

- Recommended read files: (none planned)
- Contract scope candidates: (none planned)
- Allowed write files: (none planned)
- Forbidden scope:
  - .git/**
  - .agent/workstreams/**/workflow/**
  - .agent/workstreams/**/nodes/**
  - business source writes
- Already inspected files: (none planned)
- Read reuse rule: use the recommended read files first; no repeated-read risk is known yet.
Read recommendations are context only. GOAL design/plan files are proposals; edits require approved EXECUTION scope and Git evidence.

## TaskContract

(not available)

## Ledger Pointers

- Events: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/events.jsonl
- Workflow current: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws

[adaptively compressed; section degraded to stay within ~125 tokens; full source remains in ledger under /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA]

