# Task Contract

## Objective

在既有 Java 项目 assess-income phase-one 的 90 天历史情景评估中新增可解释指标：在相同 90 天窗口、投入资金、对冲空头名义金额和固定已知成本口径下，资金费净收入追平简单赚币所需的整个 90 天累计资金费率阈值，由 PhaseOneAssessmentService 计算、PhaseOneAssessment record 承载、CLI 只读展示，并保留证据不足时的不可用语义。

## Scope

**Excluded:**
- 不修改交易/账户、采集（sync-market/sync-product）、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置
- 不接入任何新外部服务，不做未来费率预测或交易建议
- 不做整个项目的公式重构，不新增平台、规则 DSL 或兼容机制

## Acceptance Criteria

- [ ] AC-1: 计算口径：阈值 =（既有简单赚币 90 天收入 + 同口径完整已知成本）/ 对冲空头名义金额；该值是整个 90 天窗口的累计资金费率，不是 APR，不得按每次结算或假定 8 小时间隔换算；成本沿用 SmartArbitrageCosts.knownTotal() 既有口径，不重复计费；计算使用 BigDecimal 且精度规则明确（与既有服务的 DECIMAL128 计算上下文一致，除法精度显式声明）。
- [ ] AC-2: 独立样例与边界：共同资金 20,000 USDT、简单赚币 APR 0.0365、90 天、完整成本 20 USDT、对冲名义 10,000 USDT 时，对照收益为 180 USDT、阈值为 0.02（2%）；累计费率分别为 0.019、0.020、0.021 时，现有同口径增量分别为 -10、0、10 USDT；测试同时覆盖零已知成本、零 APR、负资金费率以及不能整除的精度场景；不得用舍入后的 CLI 数字重新决定现有建议。
- [ ] AC-3: 证据不足：只在现有评估允许同口径精确净收入比较时提供数值；成本缺失、简单赚币条款未确认、窗口内无历史结算或期末保持策略开放时数值不可用，并沿既有阻断项/未知项说明原因，不得填 0、猜数或给出可行动的精确阈值；非法或零名义金额沿 PhaseOneAssessmentRequest 既有输入校验拒绝（hedgedShortNotional 必须大于 0）。
- [ ] AC-4: 唯一生产与展示：现有评估服务产生 typed 结果（阈值作为 PhaseOneAssessment 的字段），CLI 只消费该结果，清楚标注“90 天累计资金费率阈值”及不可用情况，不自行重算；补充一份简明中文使用说明，包含上述样例和限制；既有建议、首次小额验证上限（5,000 USDT）、成本和风险语义不变。
- [ ] AC-5: 回归与交付：在固定隔离基线（当前分支 codex/w09-okx-break-even-20261026 @ 7c5facc）上实现；相关服务/CLI 测试、既有非容器回归和 Gate 要求的完整基线回归保留并通过，执行测试有程序工具观察和报告依据（如 Maven Surefire 报告），不能只以模型“已通过”正文作数；独立验收完成后，仍需当前交付批准、精确候选应用、人工或另行明确委派的 commit、原 finalize，才能称完整 E2E 完成。

## Test Requirements

- TR-1: PhaseOneAssessmentServiceTest 增加阈值单元测试：验证 AC-2 样例（对照收益 180 USDT、阈值 0.02）与累计费率 0.019/0.020/0.021 对应既有同口径增量 -10/0/+10 USDT，并覆盖零已知成本、零 APR、负资金费率和除不尽的精度场景；断言基于 BigDecimal 原值而非 CLI 舍入输出。
- TR-2: PhaseOneAssessmentServiceTest 增加不可用与校验测试：成本缺失、条款未确认、无历史结算、期末保持策略开放时阈值为空且原因沿既有 blockers/unknowns 输出；非法或零对冲名义金额在读取事实前被既有请求校验拒绝。
- TR-3: AssessIncomeCliRunnerTest 增加展示测试：完整证据时输出含“90 天累计资金费率阈值”标签及数值，证据不足时输出不可用说明且不打印数值；既有建议文案、首次实盘上限、退出码与限制提示不回归。
- TR-4: 在固定隔离基线上运行既有非容器回归和 Gate 要求的完整基线回归（mvn 测试），以 Maven/Surefire 等程序工具生成的报告作为通过依据，并保留完整基线通过事实。

## Constraints

- 继续使用现有 Java、BigDecimal、PhaseOneAssessmentService 评估服务和 assess-income CLI，不接入任何新外部服务或数据源。
- 阈值是整个 90 天窗口的累计资金费率，禁止换算成 APR 或按每次结算/假定 8 小时间隔折算；资金费间隔遵循实际 fundingTime。
- 成本口径沿用 SmartArbitrageCosts.knownTotal() 既有实现，不重复计费、不改变未知成本按 UNKNOWN 处理的语义；阈值的可用条件与既有增量比较的可用条件一致。
- 单一生产来源：阈值只在 PhaseOneAssessmentService 内计算并作为 typed 字段返回；CLI 是薄适配层，只打印该结果，不重算、不用舍入值影响建议。
- 资金费事实表、数据库迁移、同步/回补、组合策略与 Web 输出保持不动（只读）；新增说明文档为中文，沿用 docs 目录编号惯例。
- 精度规则显式：服务层计算与既有 CALCULATION_CONTEXT（MathContext.DECIMAL128）一致且除法上下文明确，展示层沿用 CLI 既有格式化惯例并标注为累计费率而非年化。

## Non-Goals

- 不做未来资金费率预测、完整套利收益保证或交易建议；阈值仅用于历史情景比较，既有未覆盖风险与历史完整性限制继续保留。
- 不修改交易/账户、采集、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置。
- 不把收益阈值推广为整个项目的公式重构，不新增平台、规则 DSL 或兼容机制。
- 不改变既有建议逻辑、首次小额验证上限（5,000 USDT）、成本与风险/限制提示语义。
- 发现实现依赖超出上述范围（如需要改迁移、Web 或组合代码）时停止并提交取舍，不擅自扩大实现。

## Risk Areas

- 阈值展示格式（小数位/百分比）需要在设计评审确定，避免被误读为 APR 或单次费率；服务层核心值保持 DECIMAL128 不预先舍入。
- 为 PhaseOneAssessment record 新增字段会改变构造签名，当前构造点仅在 PhaseOneAssessmentService，需在执行时确认无其他调用点遗漏。
- 新说明文档建议命名 docs/15-Funding-Rate-Break-Even-Threshold.md（沿用 docs 01–14 编号惯例），最终路径以 EXECUTION 批准的精确 scope 为准。

## Evidence References

- src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java
- src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java
- src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java
- src/main/java/app/cryptoincome/assessment/domain/SmartArbitrageCosts.java
- src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java
- src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java
- src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java
- docs/09-Phase-1-Test-Runbook.md

## Nonessential Operation Declarations

- None

## Source

- **Created by:** contract.compile
- **Raw request:** .agent/workstreams/ws-20261026T142203Z-7SNA/requirement.md

