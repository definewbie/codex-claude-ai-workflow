## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree
- Run all shell commands from the effective workspace above.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.

## Structured Artifact Field Semantics

- `must_fix` and `missing_evidence` mean unresolved blockers; keep them empty for a ready design.
- Put resolved review comments in `checks` or `evidence`, not `must_fix`.
- Under GOAL, `design.planned_files` contains proposals, not authorization; use canonical paths and operations respecting its exclusions. Exact implementation scope requires later EXECUTION approval.
- Under EXECUTION, declared paths and operations must remain within its approved scope. Design or plan review does not grant additional write authority.

# Claude Design

Workstream: ws-20261026T142203Z-7SNA
Node: design.claude_design
Template: design-claude
Ledger: .agent/workstreams/ws-20261026T142203Z-7SNA

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.

You are Claude acting as the primary architect and implementer. Use the user request, prior intake artifacts, Codex review, and human gate decision in the ledger.

Do not implement code in this stage. Produce an implementation-ready design that is narrow, testable, and avoids unrelated refactors.

Declare the complete planned file set in `result.design.planned_files`, for initial and replacement designs alike.
Under GOAL, these are proposals, not authorization: propose exact canonical paths and operations consistent with the approved objective and exclusions. GOAL does not contain an approved implementation file set.
Under EXECUTION, proposed paths and operations must remain within its approved scope; a change outside it requires new approval before implementation.
Each entry assigns a responsibility, not an actual file change. CREATE files need not exist yet.
The declared set must cover every change this design proposes. Independent design and plan review precede exact EXECUTION scope approval; neither review nor prose authorizes repository changes.

Revision discipline:

- When the context contains a prior `NEEDS_REVISION`, return a complete replacement design, not a delta or addendum.
- Treat available prior must-fix items as the minimum repair set, not the boundary of the design review.
- Do not claim knowledge of prior design text that is absent from the context. Reconstruct a coherent complete design from the TaskContract, current review evidence, and available iteration reasons.
- When adding or changing state, an index, lock, transaction, queue, cache, external side effect, or compensation, cover every applicable lifecycle boundary in `checks` or `evidence`: normal completion, concurrency, timeout/provider failure, interruption/crash, restart/recovery, rollback/conflict, and a cannot-bypass test. State why a boundary is not applicable instead of inventing requirements.
- Prefer deleting unnecessary mechanisms or simplifying the state model. Do not add platform capability merely to close one finding.

## User Request

# 智能套利追平简单赚币的资金费率阈值

在既有 Java 项目的 `assess-income phase-one` 评估中，增加一个可解释指标：在相同的 90 天窗口、投入资金、对冲名义金额和固定已知成本下，累计资金费率至少达到多少，资金费净收入才能追平简单赚币。

这是历史情景的比较阈值，不是未来费率预测、完整套利收益保证或交易建议。既有计算没有覆盖的风险和历史完整性限制继续保留。继续使用现有 Java、BigDecimal、评估服务和 CLI；不接入任何新外部服务。

## 验收条款

- **AC-1 计算口径**：阈值 =（现有简单赚币 90 天收入 + 同口径完整已知成本）/ 对冲空头名义金额。该值是整个 90 天的累计资金费率，不是 APR，不得按每次结算或假定 8 小时间隔换算。成本口径保持既有实现，不重复计费。计算使用 BigDecimal，精度规则明确。
- **AC-2 独立样例与边界**：共同资金 20,000 USDT、简单赚币 APR 0.0365、90 天、完整成本 20 USDT、对冲名义 10,000 USDT，对照收益为 180 USDT，阈值为 0.02（2%）。累计费率分别为 0.019、0.020、0.021 时，现有同口径增量分别为 -10、0、10 USDT。测试同时覆盖零已知成本、零 APR、负资金费率，以及不能整除的精度场景。不得用舍入后的 CLI 数字重新决定现有建议。
- **AC-3 证据不足**：只在现有评估允许同口径精确净收入比较时提供数值。成本缺失、报价条款未确认、没有历史结算或期末保持策略开放时，数值不可用，并沿既有阻断项/未知项说明原因；不能填 0、猜数或给出可行动的精确阈值。非法或零名义金额沿原输入校验拒绝。
- **AC-4 唯一生产与展示**：现有评估服务产生 typed 结果，CLI 只消费该结果，清楚标注“90 天累计资金费率阈值”及不可用情况，不自行重算。补充一份简明使用说明，包含上述样例和限制。既有建议、首次小额验证上限、成本和风险语义不变。
- **AC-5 回归与交付**：在固定隔离基线上实现；相关服务/CLI 测试、既有非容器回归和 Gate 要求的完整基线回归保留并通过。执行测试应有程序工具观察和报告依据，不能只用模型“已通过”的正文。独立验收完成后，仍经当前交付批准、精确候选应用、人工或另行明确委派的 commit、原 finalize，才能称完整 E2E 完成。

## 范围

预计涉及现有服务、结果 record、CLI、两份测试和一份新说明，共约六个文件。此处是规划范围，实际精确路径由当前 EXECUTION 合同批准；本文件不授写权限。

不修改交易/账户、采集、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置。不把收益阈值推广为整个项目的公式重构。不新增平台、规则 DSL 或兼容机制。发现这些依赖时先停止提交取舍。


## Context Package

### Direct Input Artifacts

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029770286/outputs/design-codex-review.stderr.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029770286/outputs/design-codex-review.transcript.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029770286/outputs/design-codex-review.json

```json
{
  "workstreamId" : "ws-20261026T142203Z-7SNA",
  "runId" : "run-1793029770286",
  "nodeId" : "design.codex_arch_review",
  "nodeInstanceId" : "node-design-codex_arch_review-010",
  "stageOutcome" : "NEEDS_REVISION",
  "lifecycleStatus" : "NEEDS_REVISION",
  "decision" : "NEEDS_REVISION",
  "summary" : "六文件方案的计算口径与职责划分合理，但精度断言和展示舍入不影响建议的验证设计尚未满足合同。",
  "sourceArtifactType" : "agent_output_contract",
  "sourceOutputRef" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029770286/outputs/design-codex-review.json",
  "blocking" : true,
  "checks" : [ "已先审阅 Review Evidence Brief，再核对完整设计及六项 Declared Planned Files；针对精度与建议边界定向核验原始合同、服务及 CLI 代码。", "范围审查通过：服务计算、record 承载、CLI 展示、两份测试和一份说明覆盖所需职责；当前 GOAL 文件清单属于提案，不代表 EXECUTION 写入授权。", "公式审查通过：复用 simpleEarnIncome 和 knownTotal，以对冲空头名义金额为分母，不重复计费、不年化、不按结算间隔换算；独立样例的 180、0.02 和 -10/0/10 均成立。", "边界审查：WARN。权威派生结果由 PhaseOneAssessmentService 负责，PhaseOneAssessment 承载，CLI 只消费；本次不新增持久实例或执行状态，也不迁移既有事实来源。", "端到端不变量审查：Declared by 为 AC-1 至 AC-4；Consumed by 为 CLI；Enforced before 为服务在产生数值前检查 blockers/unknowns；Failure route 为 Optional.empty 加既有原因；Proven by 尚为拟议测试，精度与舍入隔离的 Cannot-bypass test 存在下述缺口。", "生命周期审查：正常完成和证据不足分支均已覆盖设计；未引入共享可变状态、索引、锁、事务、队列、缓存或外部写入，因此并发、超时、崩溃、重启、回滚和补偿无需新增机制。但计算结果到 CLI 的防绕过验证仍适用，不能一并声明不适用。", "未发现需要增加平台、兼容机制或扩大六文件范围的理由；修订应仅加强现有测试设计和边界说明。" ],
  "evidence" : [ ".agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.md：AC-1 要求 DECIMAL128；TR-1 要求断言基于 BigDecimal 原值；AC-2 禁止用 CLI 舍入值重新决定建议。", ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.contract.json：除不尽场景明确计划在 setScale(6, HALF_UP) 后断言，示例为 0.066667；CLI 测试主要检查标签与六位小数格式。", "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java：当前以完整精度 delta.signum() 决定建议，仅在 blockers 和 unknowns 均为空时提供净收入及增量。", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java:301：money() 按两位小数展示；:305 的 percent() 乘以 100 后按六位小数展示。这些展示结果可能掩盖正负微小增量。" ],
  "mustFix" : [ "R1（AC-1、AC-2、TR-1）：修改除不尽场景的测试设计，直接断言 record 中 BigDecimal 原值符合独立确定的 DECIMAL128 预期，不先 setScale(6)。当前断言会让服务提前舍入为 0.066667 的错误实现通过，无法守住设计承诺的计算精度。六位展示断言应留在 CLI 测试；文档将“未舍入原值”准确表述为“按 DECIMAL128 计算、未按展示精度进一步舍入的值”。", "R2（AC-2、AC-4）：补充展示舍入不能改变建议的具体测试，并修正“防绕过边界不适用”的声明。可在 AC-2 参数下使用累计费率 0.0199999999 和 0.0200000001：两者百分比均显示为 2.000000%，原始增量却分别为 -0.000001 和 0.000001，必须保留不同的既有建议及相应首次验证上限语义。同时将独立样例的 CLI 断言固定为阈值 2.000000%，不能仅匹配任意六位小数百分比。上述补充均可落在已声明的两份测试文件内。" ],
  "contractObligations" : [ ],
  "missingEvidence" : [ ],
  "acceptanceNotes" : [ "证据不足时返回空值并沿用既有 blockers/unknowns 的方案可接受；历史区间完整性限制继续保留，不要求新增历史完整性判定机制。", "本次是设计审查，未实现代码、未执行测试，不将未来测试计划描述为已验证或已闭环。", "完整回归、程序化测试报告、独立验收、交付批准、精确候选应用、人工或明确委派的 commit 和原 finalize 仍属于后续交付要求；本次审查不替代这些步骤。" ],
  "openRisks" : [ ],
  "changedFiles" : [ ],
  "verificationSummary" : "已完成合同与完整设计审查，并通过只读工具核验关键代码；发现两项测试设计阻断，未修改任何文件，未运行测试。",
  "completedWork" : [ ],
  "importantDecisions" : [ ],
  "recommendedNextStage" : "",
  "suggestedNextPrompt" : "",
  "control" : {
    "decision" : "NEEDS_REVISION",
    "summary" : "六文件方案的计算口径与职责划分合理，但精度断言和展示舍入不影响建议的验证设计尚未满足合同。"
  },
  "failure" : {
    "categoryHint" : "设计验证不足",
    "verificationRemediation" : "NONE",
    "contractGaps" : [ "除不尽场景的断言未守住 TR-1 所要求的 BigDecimal 原值精度。", "缺少 AC-2 所要求的展示舍入不影响建议的针对性验证。" ],
    "outOfScopeFiles" : [ ],
    "missingTests" : [ "直接验证 DECIMAL128 原值的除不尽场景。", "展示费率相同但原始增量异号时，建议和首次验证上限保持原语义的场景。", "独立样例阈值精确展示为 2.000000% 的断言。" ],
    "contextGaps" : [ ],
    "reason" : "当前测试方案可能放过服务提前舍入或建议依赖展示值的错误实现，需要在进入实现前补全验证设计。"
  },
  "rereadReasons" : [ ],
  "reviewSubject" : null,
  "taskContractProposal" : null,
  "repositoryFactBinding" : null,
  "proposalDerivation" : null,
  "planArtifact" : null,
  "design" : null,
  "authoredRevisionResponses" : null,
  "authoredContext" : {
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029770286/prompts/design-codex-review.md.manifest.json",
    "sha256" : "84b3dfcd8332b741d3a6ecbaf21a25194a2ea609f2a138fac6e194b885d21928"
  },
  "verificationChecks" : [ ]
}
```

- .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-codex_arch_review-010-run-1793029770286/binding.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029770286/outputs/design-codex-review.contract.json
  (validated typed evidence already projected)

- .agent/workstreams/ws-20261026T142203Z-7SNA/context/agent-governance-node-design-claude_design-012-run-1793029979831.md

```text
# Agent Run Governance Context

- Workstream: ws-20261026T142203Z-7SNA
- Target Node: design.claude_design
- Agent Node Instance: node-design-claude_design-012
- Run Id: run-1793029979831
- Generated At: 2026-10-26T15:52:59.956651Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-012-run-1793029979831/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-012-run-1793029979831/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-012-run-1793029979831/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-012-run-1793029979831/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
## Verification readiness declarations

These are operator declarations of prerequisites, not execution results, successful tests or grants. Bind exact refs only where criterion, method, executor and environment match. If prerequisites are missing, describe the missing items without inventing references.

[ ]
```

Context use rule:

- If the package contains `Working Memory`, use it before reading repository files.
- Re-read files only when the memory is missing, stale, or insufficient for this design decision.
- If the Context Package contains a Read Reuse Contract, follow that contract exactly. Do not invent read-reuse fields when the contract does not declare them.

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_ARCH_REVIEW]




`result.revision_responses` is required: return [] when there are no active authored obligations. Otherwise cover every active obligation_id from Required Authored Context exactly once; do not add unknown IDs or omit unresolved obligations. Each entry has exactly obligation_id, disposition (ADDRESSED or NOT_ADDRESSED), and non-empty evidence. Use NOT_ADDRESSED when unresolved; ADDRESSED is a claim for review, not an approval or closure. Preserve all previously required behavior and the approved contract while making this revision.Each `result.revision_responses` item is a closed object with exactly these fields: [obligation_id, disposition, evidence]. No other keys are permitted.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793029979831",
  "node_id" : "design.claude_design",
  "result" : {
    "artifact_type" : "design_result",
    "decision" : "READY_FOR_ARCH_REVIEW",
    "summary" : "one short sentence",
    "lifecycle_status" : "READY",
    "checks" : [ "read the approved contract" ],
    "evidence" : [ "design evidence" ],
    "missing_evidence" : [ ],
    "must_fix" : [ ],
    "open_risks" : [ ],
    "verification_summary" : "Design only; no implementation performed.",
    "design" : {
      "planned_files" : [ {
        "path" : "repo/relative/new.ext",
        "operation" : "CREATE",
        "responsibility" : "proposed responsibility respecting the approved objective and exclusions"
      } ]
    },
    "revision_responses" : [ ]
  }
}


# Required Authored Context

The following verified inputs are mandatory. Respond to every active obligation; ADDRESSED does not close it. Use NOT_ADDRESSED honestly. Initial authors return [].

## Revision parent

.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.contract.json

{
  "artifact_type" : "agent_output_contract",
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793027503466",
  "node_id" : "design.claude_design",
  "node_instance_id" : "node-design-claude_design-008",
  "handler_type" : "acpx.agent_run",
  "decision" : "READY_FOR_ARCH_REVIEW",
  "summary" : "在 PhaseOneAssessmentService 既有充分证据分支内新增与增量比较同可用条件的“90 天累计资金费率追平阈值”typed 字段，CLI 只读展示并附中文使用说明与配套测试。",
  "required_keys" : [ "summary", "decision" ],
  "allowed_decisions" : [ "READY_FOR_ARCH_REVIEW" ],
  "source_output_ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/outputs/design-claude.json",
  "source_artifact_type" : "design_result",
  "generated_at" : "2026-10-26T15:18:00.473186Z",
  "control" : {
    "summary" : "在 PhaseOneAssessmentService 既有充分证据分支内新增与增量比较同可用条件的“90 天累计资金费率追平阈值”typed 字段，CLI 只读展示并附中文使用说明与配套测试。",
    "decision" : "READY_FOR_ARCH_REVIEW"
  },
  "control_source" : {
    "kind" : "strict_agent_result_envelope"
  },
  "revision_responses" : [ ],
  "lifecycle_status" : "READY",
  "checks" : [ "已读取经人工门批准的 Task Contract（APPROVE），设计严格对齐 AC-1 至 AC-5、TR-1 至 TR-4、约束与排除项，不触碰采集、迁移、持仓、调度、组合策略、Web 页面与 Dual 生产代码。", "计算口径核对：阈值 =(simpleEarnIncome + costs.knownTotal())/hedgedShortNotional，与既有增量路径共用同一分子口径，不重复计费；该值是与 fundingHistory.holdingReturn 同单位的整个 90 天累计费率，任何位置都不做 APR 化、按结算次数或假定 8 小时间隔换算。", "独立验算 AC-2 样例：20000×0.0365×90/365=180；阈值=(180+20)/10000=0.02；累计费率 0.019/0.020/0.021 时资金费收入 190/200/210，扣除成本 20 后净收入 170/180/190，既有同口径增量恰为 -10/0/+10 USDT，0.02 为精确终止小数。", "可用性语义核对：阈值仅在 blockers 与 unknowns 均为空的既有充分证据分支（条款已确认、窗口内有已实现结算、成本完整、terminal-policy=exit-to-usdt）计算，其余分支一律 Optional.empty，与 estimatedFundingOnlyNetIncome/incrementalIncomeVsSimpleEarn 完全一致，沿既有 blockers/unknowns 说明原因，不填 0、不猜数。", "零或非法名义金额复用 PhaseOneAssessmentRequest 既有校验（hedgedShortNotional.signum()<=0 抛 IllegalArgumentException，发生在读取事实之前），不新增校验路径。", "精度规则显式：分子为既有 DECIMAL128 计算的 simpleEarnIncome 加精确 knownTotal，除法使用与服务既有一致的 MathContext.DECIMAL128（34 位有效数字，非终止小数安全）；record 存原始未舍入值，CLI 仅展示层用既有 percent()（×100、6 位小数、HALF_UP）格式化，舍入值绝不回流影响建议。", "构造点核查：全仓库仅 PhaseOneAssessmentService 构造 PhaseOneAssessment record；DecisionWorkbenchController 只经服务评估并按访问器消费（smartView），新增组件对 Web 只读路径无影响、无需修改。", "生命周期边界适用性声明：本设计仅新增一次 assess() 调用内的纯派生不可变值，无索引、锁、事务、队列、缓存、外部副作用或补偿，评估保持只读、不创建 analysis_run；并发、超时、中断、重启、回滚与防绕过边界均不适用且不因本变更改变。", "回归边界：既有建议逻辑、首次小额验证上限 5000 USDT、成本与未知项语义、退出码与限制提示全部保持不变；CLI 既有断言基于 contains，追加限制子句不破坏现有测试。" ],
  "evidence" : [ "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java:42-50（simpleEarnIncome/knownCost 既有口径）与 :79-101（三分支证据判定；阈值计算落在 :87-91 的 else 分支，与 netIncome/incremental 同时置值）。", "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java:7-21：新组件 Optional<BigDecimal> breakEvenCumulativeFundingRate 拟插入 incrementalIncomeVsSimpleEarn 之后、evidenceStatus 之前。", "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java:38-40 既有 hedgedShortNotional>0 校验；SmartArbitrageCosts.java:29-50 knownTotal()/unknowns() 决定分子口径与不可用原因。", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java:160-163（净收益/增量“无法精确计算”展示惯例）、:183（限制行）、:305-307（percent() 格式化）：新阈值行置于增量行之后，未可用时打印“无法精确计算”，理由已由上方未知项/阻断项行给出；限制行追加一句“阈值是同口径历史追平点，不是年化或预测”。", "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java 与 src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java：现有 fixture 结构（service()/request()/completeCosts()/completeArguments()）可直接扩展承载 TR-1/TR-2/TR-3。", "docs/README.md 编号惯例 01–14，新说明文档沿用为 docs/15-Funding-Rate-Break-Even-Threshold.md（与合同 Risk Areas 建议一致）。", "数学不变量（测试锚点）：hedgedShortNotional×阈值 = simpleEarnIncome+knownTotal，故累计费率恰等于阈值时既有增量精确为 0（仅终止小数样例精确成立；除不尽场景按 DECIMAL128 后 setScale(6,HALF_UP) 断言）。", "合同依据：.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.md（AC/TR/约束/风险区）与 contract-resolution.md（human_gate APPROVE，2026-10-26T15:11:09Z）。" ],
  "missing_evidence" : [ ],
  "must_fix" : [ ],
  "open_risks" : [ "CLI 展示值依赖 DECIMAL128 除法结果，测试以“标签+6 位小数百分比”的正则/包含断言为准，不在 CLI 测试中重算数值，避免展示口径二次实现。", "TR-4 完整基线回归含 Testcontainers MySQL，执行阶段需 Docker 可用，并以 Maven Surefire 报告作为程序化通过依据；该验证属后续执行节点，本设计阶段未运行。" ],
  "verification_summary" : "仅设计阶段：完成代码与合同核对及样例手工验算，未实现代码、未运行测试。",
  "design" : {
    "planned_files" : [ {
      "path" : "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java",
      "operation" : "MODIFY",
      "responsibility" : "在 incrementalIncomeVsSimpleEarn 之后新增组件 Optional<BigDecimal> breakEvenCumulativeFundingRate（90 天累计资金费率追平阈值，未舍入 DECIMAL128 原值），仅承载 typed 结果，不引入新校验或逻辑。"
    }, {
      "path" : "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java",
      "operation" : "MODIFY",
      "responsibility" : "在既有无阻断且无未知项的充分证据分支计算 simpleEarnIncome.add(knownCost).divide(hedgedShortNotional, CALCULATION_CONTEXT) 并置入新字段；其余分支保持 Optional.empty；建议、上限、blockers/unknowns 语义完全不变。"
    }, {
      "path" : "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java",
      "operation" : "MODIFY",
      "responsibility" : "只读展示新字段：在“相对简单赚币增量”行后新增一行“90天累计资金费率阈值=<percent 或 无法精确计算>”，并在末尾限制行追加“同口径历史追平点，非年化、非预测”子句；不重算、不影响建议与退出码。"
    }, {
      "path" : "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java",
      "operation" : "MODIFY",
      "responsibility" : "TR-1/TR-2：独立样例（对照收益 180、阈值 0.02，累计费率 0.019/0.020/0.021 对应增量 -10/0/+10，断言基于 BigDecimal 原值）；零已知成本（0.018）、零 APR（0.002）、负资金费率仍可用、除不尽精度（如名义 3000 得 0.066667）；成本缺失/条款未确认/无历史结算/期末保持开放时阈值为空且沿 blockers/unknowns；零与负名义金额在读取事实前被既有校验拒绝。"
    }, {
      "path" : "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java",
      "operation" : "MODIFY",
      "responsibility" : "TR-3：完整证据时输出含“90天累计资金费率阈值=”及 6 位小数百分比数值；证据不足时输出“90天累计资金费率阈值=无法精确计算”且不打印数值；既有建议文案、首次实盘上限、退出码与限制提示断言保留不回归。"
    }, {
      "path" : "docs/15-Funding-Rate-Break-Even-Threshold.md",
      "operation" : "CREATE",
      "responsibility" : "简体中文使用说明：定义与公式、AC-2 样例与 0.019/0.020/0.021 边界表、可用与不可用条件、BigDecimal/DECIMAL128 精度与仅展示层舍入规则、历史情景限制（非预测、非建议、区间完整性未证明），并指向 docs/09 测试手册。"
    } ]
  },
  "stage_outcome" : "READY",
  "stage_outcome_source" : "declared_status",
  "evidence_state" : {
    "blocking" : false,
    "evidence_count" : 8,
    "missing_evidence_count" : 0,
    "must_fix_count" : 0,
    "acceptance_note_count" : 0,
    "open_risk_count" : 2
  },
  "authored_context" : {
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793027503466/prompts/design-claude.md.manifest.json",
    "sha256" : "4e876bab472e2aac7035c2cb7c961472d4555700afdb2fc4672c24136e724489"
  }
}


## Active obligations

[ {
  "id" : "sha256:56fb3fc98b780b0a29e6ae48ad6a260eed9f54d9082e4f82f673e6a25781fe37#must_fix:0",
  "source" : {
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029770286/outputs/design-codex-review.contract.json",
    "sha256" : "56fb3fc98b780b0a29e6ae48ad6a260eed9f54d9082e4f82f673e6a25781fe37"
  },
  "text" : "R1（AC-1、AC-2、TR-1）：修改除不尽场景的测试设计，直接断言 record 中 BigDecimal 原值符合独立确定的 DECIMAL128 预期，不先 setScale(6)。当前断言会让服务提前舍入为 0.066667 的错误实现通过，无法守住设计承诺的计算精度。六位展示断言应留在 CLI 测试；文档将“未舍入原值”准确表述为“按 DECIMAL128 计算、未按展示精度进一步舍入的值”。"
}, {
  "id" : "sha256:56fb3fc98b780b0a29e6ae48ad6a260eed9f54d9082e4f82f673e6a25781fe37#must_fix:1",
  "source" : {
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029770286/outputs/design-codex-review.contract.json",
    "sha256" : "56fb3fc98b780b0a29e6ae48ad6a260eed9f54d9082e4f82f673e6a25781fe37"
  },
  "text" : "R2（AC-2、AC-4）：补充展示舍入不能改变建议的具体测试，并修正“防绕过边界不适用”的声明。可在 AC-2 参数下使用累计费率 0.0199999999 和 0.0200000001：两者百分比均显示为 2.000000%，原始增量却分别为 -0.000001 和 0.000001，必须保留不同的既有建议及相应首次验证上限语义。同时将独立样例的 CLI 断言固定为阈值 2.000000%，不能仅匹配任意六位小数百分比。上述补充均可落在已声明的两份测试文件内。"
} ]
