## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree
- Run all shell commands from the effective workspace above.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.

## Structured Artifact Field Semantics

- `must_fix`, `missing_evidence`, `open_risks`, and `failure.reason` mean unresolved blockers for the current decision.
- If the decision is positive, ready, or accepted, keep blocking fields empty: `blocking=false`, `must_fix=[]`, `missing_evidence=[]`, and `failure.reason=""`.
- Do not use `must_fix` to list review comments that you already resolved. Put resolved review comments in `checks`, `evidence`, or `acceptance_notes` instead.

# Codex Intake Product Review

Workstream: ws-20261026T142203Z-7SNA
Node: intake.codex_product_review
Template: intake-codex-product-review
Ledger: .agent/workstreams/ws-20261026T142203Z-7SNA

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.

You are Codex acting as an external reviewer. Review the intake artifact from product manager, architect, and final-user perspectives.

Do not modify files. Do not perform line-by-line code review. Focus on product completeness, architectural fit, missing assumptions, and whether the workflow can safely move forward.

Treat the typed `task_contract_proposal` result in the intake context as the candidate shared task contract. Review it by principles, not by formatting nitpicks.

The current node's `AgentResultEnvelope`, JSON-only output, and workflow-routing protocol are enforced independently by the orchestrator's Output Contract. Do not require the task proposal to duplicate those harness protocols, and do not return `NEEDS_REVISION` solely because they are absent from proposal fields.

## Contract Review Principles

# Contract Review Principles

- Intent fidelity: the proposal must preserve the user's original intent.
- Explicit-requirement coverage: every user-stated objective, scope boundary, behavior constraint, acceptance criterion, and verification requirement must appear in a binding proposal field; `risk_areas`, `open_questions`, and `evidence_refs` do not preserve requirements.
- Protocol ownership: harness output and routing protocols belong to the orchestrator's node Output Contract and must not be duplicated into the product task proposal.
- Semantic neutrality: the proposal must not broaden or narrow accepted input, output, scope, or observable behavior based on an unstated implementation preference or language-specific edge case.
- Typed scope authority: intake file entries are proposals, not authorization. GOAL approval fixes the objective, acceptance and exclusions, not an implementation file set. Design and plan review produce the candidate for later exact EXECUTION approval. Only the approved EXECUTION `scope.included` is the exhaustive authorization set for permitted repository changes; each entry names one exact repository-relative path and `CREATE` or `MODIFY`. It does not require every declared path to be changed. Acceptance criteria, constraints, risks, and other prose cannot authorize an undeclared path. Never request an illustrative or non-exhaustive EXECUTION scope. A scope gap must request concrete typed path-and-operation changes.
- Non-goal clarity: boundaries must prevent unrelated refactors and scope creep.
- Verifiability: acceptance criteria must be observable by self-test, reviewer inspection, or user acceptance.
- Evidence grounding: important claims should point to user request, repo files, or prior artifacts.
- Risk coverage: risk areas should expose product, architecture, user, and data-safety risks relevant to the task.
- Human boundary: ask for human input only for real product/risk decisions, not JSON formatting or process validation.

If the proposal is missing, polluted by ledger metadata, materially inconsistent with the user request, or too vague to guide implementation, return `NEEDS_REVISION`. If the task has real product ambiguity that an agent should not decide, return `NEEDS_REVISION` or `BLOCKED` with the specific question for the next gate.

## User Request

# 智能套利追平简单赚币的资金费率阈值

在既有 Java 项目的 `assess-income phase-one` 评估中，增加一个可解释指标：在相同的 90 天窗口、投入资金、对冲名义金额和固定已知成本下，累计资金费率至少达到多少，资金费净收入才能追平简单赚币。

这是历史情景的比较阈值，不是未来费率预测、完整套利收益保证或交易建议。既有计算没有覆盖的风险和历史完整性限制继续保留。继续使用现有 Java、BigDecimal、评估服务和 CLI；不接入任何新外部服务。

## 验收条款

- **AC-1 计算口径**：阈值 =（现有简单赚币 90 天收入 + 同口径完整已知成本）/ 对冲空头名义金额。该值是整个 90 天的累计资金费率，不是 APR，不得按每次结算或假定 8 小时间隔换算。成本口径保持既有实现，不重复计费。计算使用 BigDecimal，精度规则明确。
- **AC-2 独立样例与边界**：共同资金 20,000 USDT、简单赚币 APR 0.0365、90 天、完整成本 20 USDT、对冲名义 10,000 USDT，对照收益为 180 USDT，阈值为 0.02（2%）。累计费率分别为 0.019、0.020、0.021 时，现有同口径增量分别为 -10、0、10 USDT。测试同时覆盖零已知成本、零 APR、负资金费率，以及不能整除的精度场景。不得用舍入后的 CLI 数字重新决定现有建议。
- **AC-3 证据不足**：只在现有评估允许同口径精确净收入比较时提供数值。成本缺失、报价条款未确认、没有历史结算或期末保持策略开放时，数值不可用，并沿既有阻断项/未知项说明原因；不能填 0、猜数或给出可行动的精确阈值。非法或零名义金额沿原输入校验拒绝。
- **AC-4 唯一生产与展示**：现有评估服务产生 typed 结果，CLI 只消费该结果，清楚标注“90 天累计资金费率阈值”及不可用情况，不自行重算。补充一份简明使用说明，包含上述样例和限制。既有建议、首次小额验证上限、成本和风险语义不变。
- **AC-5 回归与交付**：在固定隔离基线上实现；相关服务/CLI 测试、既有非容器回归和 Gate 要求的完整基线回归保留并通过。执行测试应有程序工具观察和报告依据，不能只用模型“已通过”的正文。独立验收完成后，仍经当前交付批准、精确候选应用、人工或另行明确委派的 commit、原 finalize，才能称完整 E2E 完成。

## 范围

预计涉及现有服务、结果 record、CLI、两份测试和一份新说明，共约六个文件。此处是规划范围，实际精确路径由当前 EXECUTION 合同批准；本文件不授写权限。

不修改交易/账户、采集、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置。不把收益阈值推广为整个项目的公式重构。不新增平台、规则 DSL 或兼容机制。发现这些依赖时先停止提交取舍。


## Context Package

### Direct Input Artifacts

- .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/task-contract-proposals/node-intake-claude_brainstorm-002-a3f1b1e0eddc1272.ref.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/context/node-context-intake_codex_product_review-003.md

```text
# Context Package

- Workstream: ws-20261026T142203Z-7SNA
- Builder Node: context.intake_codex_product_review
- Target Node: intake.codex_product_review
- Generated At: 2026-10-26T15:03:13.909572Z
- Profile: product_review
- Total: 2.5k / 4.0k tokens

## Context Governance

| Section | Level | Degraded | Original | Current |
|---|---|---|---|---|
| input_artifacts | full | no | 445 | 445 |
| review_evidence | full | no | 215 | 215 |
| recent_agent_outputs | full | no | 225 | 225 |
| ledger_pointers | pointer_only | yes | 217 | 173 |
| required_review_subject | full | no | 1.5k | 1.5k |

Degraded sections have full data at their original paths listed below.

## State & Evidence Boundary

This package separates deterministic harness facts from agent proposals.

### Trusted Harness Facts

- TaskContract qualification: not available
- Git Evidence: not generated yet

### Human Decisions

- Requirement Resolution: not available

### Agent Proposed States

- intake.claude_brainstorm: decision=READY_FOR_PRODUCT_REVIEW, stageOutcome=READY, evidenceState={blocking=false, evidence_count=1, missing_evidence_count=0, must_fix_count=0, acceptance_note_count=0, open_risk_count=0} (/Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793026771764/outputs/intake-claude-brainstorm.contract.json)

### Pending Contract/Evidence Gaps

- No contract failure diagnostics recorded

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_codex_product_review-003/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_codex_product_review-003/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_codex_product_review-003/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_codex_product_review-003/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
## Input Artifacts

### .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793026771764/outputs/intake-claude-brainstorm.stderr.log

(execution diagnostic omitted from context)

### .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793026771764/outputs/intake-claude-brainstorm.transcript.log

(execution transcript omitted from context; inspect raw file at /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793026771764/outputs/intake-claude-brainstorm.transcript.log)

### .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793026771764/outputs/intake-claude-brainstorm.json

- Contract: intake.claude_brainstorm
- Decision: READY_FOR_PRODUCT_REVIEW
- Summary: 在既有 assess-income phase-one 评估中由服务层计算并 typed 输出追平简单赚币的 90 天累计资金费率阈值，CLI 只展示，配套独立样例测试与简明使用说明。
- Verification: task contract proposal validated
- Contract Sidecar: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793026771764/outputs/intake-claude-brainstorm.contract.json
- Raw Output: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793026771764/outputs/intake-claude-brainstorm.json

### .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1793026771764/binding.json

(routed artifact has no typed context projection; content omitted)

### .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/task-contract-proposals/node-intake-claude_brainstorm-002-a3f1b1e0eddc1272.ref.json

(routed artifact has no typed context projection; content omitted)

## Review Evidence Brief

TaskContract projection: unavailable

No cumulative review verdict recorded. Review the complete current subject against the contract baseline.

- Relevant memory (reuse, do not re-read): CLAUDE.md; README.md; docs/09-Phase-1-Test-Runbook.md; src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java; src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java

Derive the complete current blocker set from the review subject and acceptance criteria; re-read a file only with a reason (edit/verify/sha-changed/stage-gap).
Evidence: memory .agent/workstreams/ws-20261026T142203Z-7SNA/memory/workstream-memory.json; diff .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/git-evidence/diff.patch; changed .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/git-evidence/changed-files.txt.

## Recent Agent Outputs

### /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793026771764/outputs/intake-claude-brainstorm.contract.json

- Contract: intake.claude_brainstorm
- Decision: READY_FOR_PRODUCT_REVIEW
- Summary: 在既有 assess-income phase-one 评估中由服务层计算并 typed 输出追平简单赚币的 90 天累计资金费率阈值，CLI 只展示，配套独立样例测试与简明使用说明。
- Verification: task contract proposal validated
- Contract Sidecar: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793026771764/outputs/intake-claude-brainstorm.contract.json
- Raw Output: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793026771764/outputs/intake-claude-brainstorm.json

## Ledger Pointers

- Events: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/events.jsonl
- Workflow current: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws

[adaptively compressed; section degraded to stay within ~125 tokens; full source remains in ledger under /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA]

## Required Review Subject

- Proposal ID: node-intake-claude_brainstorm-002:a3f1b1e0eddc1272
- Proposal Reference: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/task-contract-proposals/node-intake-claude_brainstorm-002-a3f1b1e0eddc1272.ref.json
- Proposal SHA-256: a3f1b1e0eddc12720355d7db51b4b59b7c17ec61519b40009dc80154266cb772


```json
{
  "artifact_type" : "task_contract_proposal",
  "schema_version" : 3,
  "objective" : "在既有 Java 项目 assess-income phase-one 的 90 天历史情景评估中新增可解释指标：在相同 90 天窗口、投入资金、对冲空头名义金额和固定已知成本口径下，资金费净收入追平简单赚币所需的整个 90 天累计资金费率阈值，由 PhaseOneAssessmentService 计算、PhaseOneAssessment record 承载、CLI 只读展示，并保留证据不足时的不可用语义。",
  "scope" : {
    "included" : [ {
      "path" : "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java",
      "operation" : "MODIFY"
    }, {
      "path" : "docs/15-Funding-Rate-Break-Even-Threshold.md",
      "operation" : "CREATE"
    } ],
    "excluded" : [ "不修改交易/账户、采集（sync-market/sync-product）、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置", "不接入任何新外部服务，不做未来费率预测或交易建议", "不做整个项目的公式重构，不新增平台、规则 DSL 或兼容机制" ]
  },
  "acceptance_criteria" : [ {
    "id" : "AC-1",
    "text" : "计算口径：阈值 =（既有简单赚币 90 天收入 + 同口径完整已知成本）/ 对冲空头名义金额；该值是整个 90 天窗口的累计资金费率，不是 APR，不得按每次结算或假定 8 小时间隔换算；成本沿用 SmartArbitrageCosts.knownTotal() 既有口径，不重复计费；计算使用 BigDecimal 且精度规则明确（与既有服务的 DECIMAL128 计算上下文一致，除法精度显式声明）。"
  }, {
    "id" : "AC-2",
    "text" : "独立样例与边界：共同资金 20,000 USDT、简单赚币 APR 0.0365、90 天、完整成本 20 USDT、对冲名义 10,000 USDT 时，对照收益为 180 USDT、阈值为 0.02（2%）；累计费率分别为 0.019、0.020、0.021 时，现有同口径增量分别为 -10、0、10 USDT；测试同时覆盖零已知成本、零 APR、负资金费率以及不能整除的精度场景；不得用舍入后的 CLI 数字重新决定现有建议。"
  }, {
    "id" : "AC-3",
    "text" : "证据不足：只在现有评估允许同口径精确净收入比较时提供数值；成本缺失、简单赚币条款未确认、窗口内无历史结算或期末保持策略开放时数值不可用，并沿既有阻断项/未知项说明原因，不得填 0、猜数或给出可行动的精确阈值；非法或零名义金额沿 PhaseOneAssessmentRequest 既有输入校验拒绝（hedgedShortNotional 必须大于 0）。"
  }, {
    "id" : "AC-4",
    "text" : "唯一生产与展示：现有评估服务产生 typed 结果（阈值作为 PhaseOneAssessment 的字段），CLI 只消费该结果，清楚标注“90 天累计资金费率阈值”及不可用情况，不自行重算；补充一份简明中文使用说明，包含上述样例和限制；既有建议、首次小额验证上限（5,000 USDT）、成本和风险语义不变。"
  }, {
    "id" : "AC-5",
    "text" : "回归与交付：在固定隔离基线（当前分支 codex/w09-okx-break-even-20261026 @ 7c5facc）上实现；相关服务/CLI 测试、既有非容器回归和 Gate 要求的完整基线回归保留并通过，执行测试有程序工具观察和报告依据（如 Maven Surefire 报告），不能只以模型“已通过”正文作数；独立验收完成后，仍需当前交付批准、精确候选应用、人工或另行明确委派的 commit、原 finalize，才能称完整 E2E 完成。"
  } ],
  "test_requirements" : [ {
    "id" : "TR-1",
    "text" : "PhaseOneAssessmentServiceTest 增加阈值单元测试：验证 AC-2 样例（对照收益 180 USDT、阈值 0.02）与累计费率 0.019/0.020/0.021 对应既有同口径增量 -10/0/+10 USDT，并覆盖零已知成本、零 APR、负资金费率和除不尽的精度场景；断言基于 BigDecimal 原值而非 CLI 舍入输出。"
  }, {
    "id" : "TR-2",
    "text" : "PhaseOneAssessmentServiceTest 增加不可用与校验测试：成本缺失、条款未确认、无历史结算、期末保持策略开放时阈值为空且原因沿既有 blockers/unknowns 输出；非法或零对冲名义金额在读取事实前被既有请求校验拒绝。"
  }, {
    "id" : "TR-3",
    "text" : "AssessIncomeCliRunnerTest 增加展示测试：完整证据时输出含“90 天累计资金费率阈值”标签及数值，证据不足时输出不可用说明且不打印数值；既有建议文案、首次实盘上限、退出码与限制提示不回归。"
  }, {
    "id" : "TR-4",
    "text" : "在固定隔离基线上运行既有非容器回归和 Gate 要求的完整基线回归（mvn 测试），以 Maven/Surefire 等程序工具生成的报告作为通过依据，并保留完整基线通过事实。"
  } ],
  "constraints" : [ {
    "id" : "C-1",
    "text" : "继续使用现有 Java、BigDecimal、PhaseOneAssessmentService 评估服务和 assess-income CLI，不接入任何新外部服务或数据源。"
  }, {
    "id" : "C-2",
    "text" : "阈值是整个 90 天窗口的累计资金费率，禁止换算成 APR 或按每次结算/假定 8 小时间隔折算；资金费间隔遵循实际 fundingTime。"
  }, {
    "id" : "C-3",
    "text" : "成本口径沿用 SmartArbitrageCosts.knownTotal() 既有实现，不重复计费、不改变未知成本按 UNKNOWN 处理的语义；阈值的可用条件与既有增量比较的可用条件一致。"
  }, {
    "id" : "C-4",
    "text" : "单一生产来源：阈值只在 PhaseOneAssessmentService 内计算并作为 typed 字段返回；CLI 是薄适配层，只打印该结果，不重算、不用舍入值影响建议。"
  }, {
    "id" : "C-5",
    "text" : "资金费事实表、数据库迁移、同步/回补、组合策略与 Web 输出保持不动（只读）；新增说明文档为中文，沿用 docs 目录编号惯例。"
  }, {
    "id" : "C-6",
    "text" : "精度规则显式：服务层计算与既有 CALCULATION_CONTEXT（MathContext.DECIMAL128）一致且除法上下文明确，展示层沿用 CLI 既有格式化惯例并标注为累计费率而非年化。"
  } ],
  "non_goals" : [ {
    "id" : "NG-1",
    "text" : "不做未来资金费率预测、完整套利收益保证或交易建议；阈值仅用于历史情景比较，既有未覆盖风险与历史完整性限制继续保留。"
  }, {
    "id" : "NG-2",
    "text" : "不修改交易/账户、采集、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置。"
  }, {
    "id" : "NG-3",
    "text" : "不把收益阈值推广为整个项目的公式重构，不新增平台、规则 DSL 或兼容机制。"
  }, {
    "id" : "NG-4",
    "text" : "不改变既有建议逻辑、首次小额验证上限（5,000 USDT）、成本与风险/限制提示语义。"
  }, {
    "id" : "NG-5",
    "text" : "发现实现依赖超出上述范围（如需要改迁移、Web 或组合代码）时停止并提交取舍，不擅自扩大实现。"
  } ],
  "risk_areas" : [ {
    "id" : "R-1",
    "text" : "阈值展示格式（小数位/百分比）需要在设计评审确定，避免被误读为 APR 或单次费率；服务层核心值保持 DECIMAL128 不预先舍入。"
  }, {
    "id" : "R-2",
    "text" : "为 PhaseOneAssessment record 新增字段会改变构造签名，当前构造点仅在 PhaseOneAssessmentService，需在执行时确认无其他调用点遗漏。"
  }, {
    "id" : "R-3",
    "text" : "新说明文档建议命名 docs/15-Funding-Rate-Break-Even-Threshold.md（沿用 docs 01–14 编号惯例），最终路径以 EXECUTION 批准的精确 scope 为准。"
  } ],
  "evidence_refs" : [ "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java", "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java", "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java", "src/main/java/app/cryptoincome/assessment/domain/SmartArbitrageCosts.java", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java", "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java", "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java", "docs/09-Phase-1-Test-Runbook.md" ],
  "open_questions" : [ ],
  "revision_responses" : [ ]
}
```
```

- .agent/workstreams/ws-20261026T142203Z-7SNA/context/agent-governance-node-intake-codex_product_review-004-run-1793027022575.md

```text
# Agent Run Governance Context

- Workstream: ws-20261026T142203Z-7SNA
- Target Node: intake.codex_product_review
- Agent Node Instance: node-intake-codex_product_review-004
- Run Id: run-1793027022575
- Generated At: 2026-10-26T15:03:42.605070Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-codex_product_review-004-run-1793027022575/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-codex_product_review-004-run-1793027022575/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-codex_product_review-004-run-1793027022575/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-codex_product_review-004-run-1793027022575/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
```

Evidence use rule:

- If the package contains `Review Evidence Brief`, review that first.
- Use raw artifacts or repository reads only to spot-check high-risk claims or fill explicit evidence gaps.
- If the brief is insufficient, put concrete gaps in `missing_evidence` instead of broadening the review silently.

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [BLOCKED, NEEDS_REVISION, READY_FOR_PRODUCT_REVIEW]
Allowed `result.failure.verification_remediation` values for this node: [NONE]
For this node, `result.reread_reasons` must remain exactly `[]`.
For this node, `result.failure.verification_remediation` must remain `NONE`.
evidence_refs are canonical product-tree file paths, not program artifact references. An empty tracked-path inventory permits evidence_refs=[]; do not create files to populate it. For a non-empty inventory include at least one existing tracked product file supported by its repo-map fact. Never copy .agent/ or .git/ references into evidence_refs or evidence_ref_additions. Program repo-map/binding/context materials are carried by RepositoryFactBinding; reading them does not make them product evidence. For NEEDS_REVISION with non-empty `result.failure.contract_gaps`, `result.contract_obligations` must contain one object per contract obligation with stable string fields `id` and `text`. Otherwise it must be `[]`. Each `result.contract_obligations` item is a closed object with exactly these fields: [id, text]. No other keys are permitted.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793027022575",
  "node_id" : "intake.codex_product_review",
  "result" : {
    "artifact_type" : "agent_output_contract",
    "decision" : "<one allowed decision>",
    "summary" : "one short sentence",
    "lifecycle_status" : "READY",
    "blocking" : false,
    "checks" : [ "check or review performed" ],
    "evidence" : [ "specific evidence" ],
    "missing_evidence" : [ ],
    "must_fix" : [ ],
    "contract_obligations" : [ ],
    "acceptance_notes" : [ ],
    "open_risks" : [ ],
    "changed_files" : [ ],
    "verification_summary" : "short verification summary",
    "failure" : {
      "category_hint" : "",
      "verification_remediation" : "NONE",
      "contract_gaps" : [ ],
      "out_of_scope_files" : [ ],
      "missing_tests" : [ ],
      "context_gaps" : [ ],
      "reason" : ""
    },
    "reread_reasons" : [ ]
  }
}
