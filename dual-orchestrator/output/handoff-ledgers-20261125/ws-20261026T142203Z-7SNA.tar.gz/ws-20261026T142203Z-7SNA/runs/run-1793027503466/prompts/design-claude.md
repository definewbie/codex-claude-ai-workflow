## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree
- Run all shell commands from the effective workspace above.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.

## Structured Artifact Field Semantics

- `must_fix` and `missing_evidence` mean unresolved blockers; keep them empty for a ready design.
- Put resolved review comments in `checks` or `evidence`, not `must_fix`.
- Under GOAL, `design.planned_files` contains proposals, not authorization; use canonical paths and operations respecting its exclusions. Exact implementation scope requires later EXECUTION approval.
- Under EXECUTION, declared paths and operations must remain within its approved scope. Design or plan review does not grant additional write authority.

# Claude Design

Workstream: ws-20261026T142203Z-7SNA
Node: design.claude_design
Template: design-claude
Ledger: .agent/workstreams/ws-20261026T142203Z-7SNA

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.

You are Claude acting as the primary architect and implementer. Use the user request, prior intake artifacts, Codex review, and human gate decision in the ledger.

Do not implement code in this stage. Produce an implementation-ready design that is narrow, testable, and avoids unrelated refactors.

Declare the complete planned file set in `result.design.planned_files`, for initial and replacement designs alike.
Under GOAL, these are proposals, not authorization: propose exact canonical paths and operations consistent with the approved objective and exclusions. GOAL does not contain an approved implementation file set.
Under EXECUTION, proposed paths and operations must remain within its approved scope; a change outside it requires new approval before implementation.
Each entry assigns a responsibility, not an actual file change. CREATE files need not exist yet.
The declared set must cover every change this design proposes. Independent design and plan review precede exact EXECUTION scope approval; neither review nor prose authorizes repository changes.

Revision discipline:

- When the context contains a prior `NEEDS_REVISION`, return a complete replacement design, not a delta or addendum.
- Treat available prior must-fix items as the minimum repair set, not the boundary of the design review.
- Do not claim knowledge of prior design text that is absent from the context. Reconstruct a coherent complete design from the TaskContract, current review evidence, and available iteration reasons.
- When adding or changing state, an index, lock, transaction, queue, cache, external side effect, or compensation, cover every applicable lifecycle boundary in `checks` or `evidence`: normal completion, concurrency, timeout/provider failure, interruption/crash, restart/recovery, rollback/conflict, and a cannot-bypass test. State why a boundary is not applicable instead of inventing requirements.
- Prefer deleting unnecessary mechanisms or simplifying the state model. Do not add platform capability merely to close one finding.

## User Request

# 智能套利追平简单赚币的资金费率阈值

在既有 Java 项目的 `assess-income phase-one` 评估中，增加一个可解释指标：在相同的 90 天窗口、投入资金、对冲名义金额和固定已知成本下，累计资金费率至少达到多少，资金费净收入才能追平简单赚币。

这是历史情景的比较阈值，不是未来费率预测、完整套利收益保证或交易建议。既有计算没有覆盖的风险和历史完整性限制继续保留。继续使用现有 Java、BigDecimal、评估服务和 CLI；不接入任何新外部服务。

## 验收条款

- **AC-1 计算口径**：阈值 =（现有简单赚币 90 天收入 + 同口径完整已知成本）/ 对冲空头名义金额。该值是整个 90 天的累计资金费率，不是 APR，不得按每次结算或假定 8 小时间隔换算。成本口径保持既有实现，不重复计费。计算使用 BigDecimal，精度规则明确。
- **AC-2 独立样例与边界**：共同资金 20,000 USDT、简单赚币 APR 0.0365、90 天、完整成本 20 USDT、对冲名义 10,000 USDT，对照收益为 180 USDT，阈值为 0.02（2%）。累计费率分别为 0.019、0.020、0.021 时，现有同口径增量分别为 -10、0、10 USDT。测试同时覆盖零已知成本、零 APR、负资金费率，以及不能整除的精度场景。不得用舍入后的 CLI 数字重新决定现有建议。
- **AC-3 证据不足**：只在现有评估允许同口径精确净收入比较时提供数值。成本缺失、报价条款未确认、没有历史结算或期末保持策略开放时，数值不可用，并沿既有阻断项/未知项说明原因；不能填 0、猜数或给出可行动的精确阈值。非法或零名义金额沿原输入校验拒绝。
- **AC-4 唯一生产与展示**：现有评估服务产生 typed 结果，CLI 只消费该结果，清楚标注“90 天累计资金费率阈值”及不可用情况，不自行重算。补充一份简明使用说明，包含上述样例和限制。既有建议、首次小额验证上限、成本和风险语义不变。
- **AC-5 回归与交付**：在固定隔离基线上实现；相关服务/CLI 测试、既有非容器回归和 Gate 要求的完整基线回归保留并通过。执行测试应有程序工具观察和报告依据，不能只用模型“已通过”的正文。独立验收完成后，仍经当前交付批准、精确候选应用、人工或另行明确委派的 commit、原 finalize，才能称完整 E2E 完成。

## 范围

预计涉及现有服务、结果 record、CLI、两份测试和一份新说明，共约六个文件。此处是规划范围，实际精确路径由当前 EXECUTION 合同批准；本文件不授写权限。

不修改交易/账户、采集、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置。不把收益阈值推广为整个项目的公式重构。不新增平台、规则 DSL 或兼容机制。发现这些依赖时先停止提交取舍。


## Context Package

### Direct Input Artifacts

- .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.md
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/contract-resolution.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/contract-resolution.md
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/context/agent-governance-node-design-claude_design-008-run-1793027503466.md

```text
# Agent Run Governance Context

- Workstream: ws-20261026T142203Z-7SNA
- Target Node: design.claude_design
- Agent Node Instance: node-design-claude_design-008
- Run Id: run-1793027503466
- Generated At: 2026-10-26T15:11:43.557303Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: design
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-008-run-1793027503466/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-008-run-1793027503466/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-008-run-1793027503466/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-claude_design-008-run-1793027503466/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
## Verification readiness declarations

These are operator declarations of prerequisites, not execution results, successful tests or grants. Bind exact refs only where criterion, method, executor and environment match. If prerequisites are missing, describe the missing items without inventing references.

[ ]
```

Context use rule:

- If the package contains `Working Memory`, use it before reading repository files.
- Re-read files only when the memory is missing, stale, or insufficient for this design decision.
- If the Context Package contains a Read Reuse Contract, follow that contract exactly. Do not invent read-reuse fields when the contract does not declare them.

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_ARCH_REVIEW]




`result.revision_responses` is required: return [] when there are no active authored obligations. Otherwise cover every active obligation_id from Required Authored Context exactly once; do not add unknown IDs or omit unresolved obligations. Each entry has exactly obligation_id, disposition (ADDRESSED or NOT_ADDRESSED), and non-empty evidence. Use NOT_ADDRESSED when unresolved; ADDRESSED is a claim for review, not an approval or closure. Preserve all previously required behavior and the approved contract while making this revision.Each `result.revision_responses` item is a closed object with exactly these fields: [obligation_id, disposition, evidence]. No other keys are permitted.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793027503466",
  "node_id" : "design.claude_design",
  "result" : {
    "artifact_type" : "design_result",
    "decision" : "READY_FOR_ARCH_REVIEW",
    "summary" : "one short sentence",
    "lifecycle_status" : "READY",
    "checks" : [ "read the approved contract" ],
    "evidence" : [ "design evidence" ],
    "missing_evidence" : [ ],
    "must_fix" : [ ],
    "open_risks" : [ ],
    "verification_summary" : "Design only; no implementation performed.",
    "design" : {
      "planned_files" : [ {
        "path" : "repo/relative/new.ext",
        "operation" : "CREATE",
        "responsibility" : "proposed responsibility respecting the approved objective and exclusions"
      } ]
    },
    "revision_responses" : [ ]
  }
}


# Required Authored Context

The following verified inputs are mandatory. Respond to every active obligation; ADDRESSED does not close it. Use NOT_ADDRESSED honestly. Initial authors return [].

## Active obligations

[ ]
