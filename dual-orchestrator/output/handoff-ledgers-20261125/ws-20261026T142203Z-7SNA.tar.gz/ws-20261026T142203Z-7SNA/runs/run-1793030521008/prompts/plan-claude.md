## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree
- Run all shell commands from the effective workspace above.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.

## Structured Artifact Field Semantics

- `must_fix`, `missing_evidence`, `open_risks`, and `failure.reason` mean unresolved blockers for the current decision.
- If the decision is positive, ready, or accepted, keep blocking fields empty: `blocking=false`, `must_fix=[]`, `missing_evidence=[]`, and `failure.reason=""`.
- Do not use `must_fix` to list review comments that you already resolved. Put resolved review comments in `checks`, `evidence`, or `acceptance_notes` instead.

# Claude Implementation Plan

Workstream: ws-20261026T142203Z-7SNA
Node: plan.claude_plan
Template: plan-claude
Ledger: .agent/workstreams/ws-20261026T142203Z-7SNA

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.

You are Claude acting as the primary developer. Convert the independently reviewed design into a concrete implementation plan.

Do not implement code in this stage. Keep the plan small enough to execute and verify. Do not expand scope.

Under GOAL, planned files are proposals, not authorization: derive canonical paths from the reviewed design while respecting the approved objective and exclusions. Exact EXECUTION scope approval follows design and plan review. Under EXECUTION, the plan must remain within approved paths and operations; a change outside them requires new approval before implementation.

Planning-stage boundary:

- Do not execute the plan.
- Do not run build, typecheck, pytest, npm, npx, install, or other validation commands.
- Do not create, edit, or delete project files.
- You may inspect context and repository files using read/search tools only.
- Put commands that should be run later under `Validation Plan`; the self-test node owns execution and evidence collection.
- If a previous review asks for verification evidence, plan how the self-test node will produce it; do not produce the evidence here.

## User Request

# 智能套利追平简单赚币的资金费率阈值

在既有 Java 项目的 `assess-income phase-one` 评估中，增加一个可解释指标：在相同的 90 天窗口、投入资金、对冲名义金额和固定已知成本下，累计资金费率至少达到多少，资金费净收入才能追平简单赚币。

这是历史情景的比较阈值，不是未来费率预测、完整套利收益保证或交易建议。既有计算没有覆盖的风险和历史完整性限制继续保留。继续使用现有 Java、BigDecimal、评估服务和 CLI；不接入任何新外部服务。

## 验收条款

- **AC-1 计算口径**：阈值 =（现有简单赚币 90 天收入 + 同口径完整已知成本）/ 对冲空头名义金额。该值是整个 90 天的累计资金费率，不是 APR，不得按每次结算或假定 8 小时间隔换算。成本口径保持既有实现，不重复计费。计算使用 BigDecimal，精度规则明确。
- **AC-2 独立样例与边界**：共同资金 20,000 USDT、简单赚币 APR 0.0365、90 天、完整成本 20 USDT、对冲名义 10,000 USDT，对照收益为 180 USDT，阈值为 0.02（2%）。累计费率分别为 0.019、0.020、0.021 时，现有同口径增量分别为 -10、0、10 USDT。测试同时覆盖零已知成本、零 APR、负资金费率，以及不能整除的精度场景。不得用舍入后的 CLI 数字重新决定现有建议。
- **AC-3 证据不足**：只在现有评估允许同口径精确净收入比较时提供数值。成本缺失、报价条款未确认、没有历史结算或期末保持策略开放时，数值不可用，并沿既有阻断项/未知项说明原因；不能填 0、猜数或给出可行动的精确阈值。非法或零名义金额沿原输入校验拒绝。
- **AC-4 唯一生产与展示**：现有评估服务产生 typed 结果，CLI 只消费该结果，清楚标注“90 天累计资金费率阈值”及不可用情况，不自行重算。补充一份简明使用说明，包含上述样例和限制。既有建议、首次小额验证上限、成本和风险语义不变。
- **AC-5 回归与交付**：在固定隔离基线上实现；相关服务/CLI 测试、既有非容器回归和 Gate 要求的完整基线回归保留并通过。执行测试应有程序工具观察和报告依据，不能只用模型“已通过”的正文。独立验收完成后，仍经当前交付批准、精确候选应用、人工或另行明确委派的 commit、原 finalize，才能称完整 E2E 完成。

## 范围

预计涉及现有服务、结果 record、CLI、两份测试和一份新说明，共约六个文件。此处是规划范围，实际精确路径由当前 EXECUTION 合同批准；本文件不授写权限。

不修改交易/账户、采集、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置。不把收益阈值推广为整个项目的公式重构。不新增平台、规则 DSL 或兼容机制。发现这些依赖时先停止提交取舍。


## Context Package

### Direct Input Artifacts

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/outputs/design-codex-review.stderr.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/outputs/design-codex-review.transcript.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/outputs/design-codex-review.json

```json
{
  "workstreamId" : "ws-20261026T142203Z-7SNA",
  "runId" : "run-1793030419328",
  "nodeId" : "design.codex_arch_review",
  "nodeInstanceId" : "node-design-codex_arch_review-015",
  "stageOutcome" : "READY",
  "lifecycleStatus" : "READY",
  "decision" : "READY_FOR_ARCH_REVIEW",
  "summary" : "完整替换设计符合既定范围，R1、R2 的设计缺口均已解决，可进入后续计划与实现范围审批。",
  "sourceArtifactType" : "agent_output_contract",
  "sourceOutputRef" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/outputs/design-codex-review.json",
  "blocking" : false,
  "checks" : [ "已先审阅 Review Evidence Brief，再审查完整当前设计、六项 Declared Planned Files 和全部验收条款；复用上一轮已核验的合同及源码事实，无需重复读取。", "范围与职责审查通过：服务唯一计算、record 承载、CLI 只读展示，两份测试及一份说明覆盖必要职责；不需要增加状态模型、平台、兼容机制或扩大文件范围。", "AC-1 与 AC-2 审查通过：分子复用既有简单赚币收入和完整已知成本，分母为对冲空头名义金额，除法显式采用 DECIMAL128；指标保持整个 90 天累计费率口径。独立样例、零成本、零 APR、负费率及除不尽场景均有明确测试设计。", "R1（must_fix:0）设计修订验收通过：原值直接对比独立字面量 0.06666666666666666666666666666666667，并检查 precision()==34，不先 setScale；注释与文档已区分计算精度和展示舍入。", "R2（must_fix:1）设计修订验收通过：服务和 CLI 成对测试覆盖展示相同、原始增量异号时的不同建议及首次验证上限；独立样例固定断言阈值为 2.000000%；防绕过边界已明确适用。", "AC-3 审查通过：阈值与既有净收入及增量共享 blockers/unknowns 门槛；四类证据不足情况返回 Optional.empty 并保留原因；非法名义金额沿既有请求校验拒绝。", "边界审查：PASS（设计层面）。权威派生事实由 PhaseOneAssessmentService 负责，PhaseOneAssessment 承载，CLI 消费；不新增持久实例或执行状态。正常完成及不可用分支明确；并发、提供方失败、超时、中断、崩溃、恢复、回滚和补偿未因本变更引入新的处理责任。", "端到端不变量：Declared by 为 AC-1 至 AC-4；Consumed by 为 CLI；Enforced before 为服务在产生阈值前检查证据门槛；Failure route 为 Optional.empty 及既有原因。Proven by 和 Cannot-bypass test 已落实为原值断言、舍入边界成对测试及不可用场景的测试计划，尚待实现和执行。", "AC-4 与 AC-5 审查通过：既有建议、5000 USDT 上限、成本和风险语义保持不变；设计保留固定隔离基线、服务及 CLI 测试、非容器回归、完整基线回归和后续交付门要求。" ],
  "evidence" : [ ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/outputs/design-claude.contract.json：完整 design.planned_files 与 revision_responses 明确给出 R1、R2 的修订内容，并保持六文件范围。", ".agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.md：上一轮已核验的 AC-1 至 AC-5、TR-1 至 TR-4 及范围约束，本轮继续作为审查基线。", "独立数值核对：20000×0.0365×90÷365=180；(180+20)÷10000=0.02；0.019/0.020/0.021 对应增量 -10/0/10；0.0199999999/0.0200000001 对应增量 -0.000001/0.000001。", "上一轮已核验 PhaseOneAssessmentService 的 delta.signum() 建议分支，以及 AssessIncomeCliRunner 的 money()/percent() 格式化规则，与本轮成对测试预期一致。" ],
  "mustFix" : [ ],
  "contractObligations" : [ ],
  "missingEvidence" : [ ],
  "acceptanceNotes" : [ "本次关闭的是两项设计审查问题。候选文本中的“已由测试覆盖”和“闭环”仅可理解为测试方案已补全，不能据此宣称实现达到 ENFORCED 或 PROVEN。", "既有 runnerDependsOnApplicationServiceNotInfrastructureMapper 测试证明依赖方向，不能单独证明 CLI 没有重算；实现审查仍需核对新增展示行直接消费 typed 字段。", "CLI 格式断言的维护成本及完整回归所需 Docker 环境属于后续执行事项，不构成本轮设计阻断；测试通过必须由程序工具及报告证明。", "六文件清单仍是 GOAL 阶段提案，不授予写入权限。本次通过不替代 EXECUTION 范围批准、独立验收、交付批准、精确候选应用、人工或明确委派的 commit 及原 finalize。" ],
  "openRisks" : [ ],
  "changedFiles" : [ ],
  "verificationSummary" : "依据完整替换设计、已核验合同与源码事实完成设计复审；两项原设计阻断已解决。本轮未修改文件、未运行测试，不声明实现或完整 E2E 完成。",
  "completedWork" : [ ],
  "importantDecisions" : [ ],
  "recommendedNextStage" : "",
  "suggestedNextPrompt" : "",
  "control" : {
    "decision" : "READY_FOR_ARCH_REVIEW",
    "summary" : "完整替换设计符合既定范围，R1、R2 的设计缺口均已解决，可进入后续计划与实现范围审批。"
  },
  "failure" : {
    "categoryHint" : "",
    "verificationRemediation" : "NONE",
    "contractGaps" : [ ],
    "outOfScopeFiles" : [ ],
    "missingTests" : [ ],
    "contextGaps" : [ ],
    "reason" : ""
  },
  "rereadReasons" : [ ],
  "reviewSubject" : null,
  "taskContractProposal" : null,
  "repositoryFactBinding" : null,
  "proposalDerivation" : null,
  "planArtifact" : null,
  "design" : null,
  "authoredRevisionResponses" : null,
  "authoredContext" : {
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
    "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
  },
  "verificationChecks" : [ ]
}
```

- .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-design-codex_arch_review-015-run-1793030419328/binding.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/outputs/design-codex-review.contract.json
  (validated typed evidence already projected)

- .agent/workstreams/ws-20261026T142203Z-7SNA/context/agent-governance-node-plan-claude_plan-017-run-1793030521008.md

```text
# Agent Run Governance Context

- Workstream: ws-20261026T142203Z-7SNA
- Target Node: plan.claude_plan
- Agent Node Instance: node-plan-claude_plan-017
- Run Id: run-1793030521008
- Generated At: 2026-10-26T16:02:01.125483Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: plan
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-claude_plan-017-run-1793030521008/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-claude_plan-017-run-1793030521008/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-claude_plan-017-run-1793030521008/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-claude_plan-017-run-1793030521008/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
## Verification readiness declarations

These are operator declarations of prerequisites, not execution results, successful tests or grants. Bind exact refs only where criterion, method, executor and environment match. If prerequisites are missing, describe the missing items without inventing references.

[ ]
```

Context use rule:

- If the package contains `Working Memory`, use it before reading repository files.
- Re-read files only when the memory is missing, stale, or insufficient for planning.
- If the Context Package contains a Read Reuse Contract, follow that contract exactly. Do not invent read-reuse fields when the contract does not declare them.

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_PLAN_REVIEW]
Allowed `result.failure.verification_remediation` values for this node: [NONE]

For this node, `result.failure.verification_remediation` must remain `NONE`.

`result.revision_responses` is required: return [] when there are no active authored obligations. Otherwise cover every active obligation_id from Required Authored Context exactly once; do not add unknown IDs or omit unresolved obligations. Each entry has exactly obligation_id, disposition (ADDRESSED or NOT_ADDRESSED), and non-empty evidence. Use NOT_ADDRESSED when unresolved; ADDRESSED is a claim for review, not an approval or closure. Preserve all previously required behavior and the approved contract while making this revision.
edit_files must contain unique canonical proposed paths respecting the approved GOAL exclusions. Exact file operations require later EXECUTION approval. Each scope path must name one exact file, not a directory; it must be repository-relative, must not end with `/`, and must already be canonical (no `./`, `..`, repeated separators, backslashes, leading/trailing whitespace, `.git`, or `.agent` segments). A subset is allowed; reference_files do not authorize edits. Each `result.revision_responses` item is a closed object with exactly these fields: [obligation_id, disposition, evidence]. No other keys are permitted.
Each verification_binding must explicitly set actual_exit_required (boolean) and expected_exit_code (integer or null). Derive these from the approved acceptance requirements before execution; never weaken a required exit check. expected_exit_code requires actual_exit_required=true. Operator declarations cannot supply measured process exits.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793030521008",
  "node_id" : "plan.claude_plan",
  "result" : {
    "artifact_type" : "plan_result",
    "decision" : "READY_FOR_PLAN_REVIEW",
    "summary" : "one short sentence",
    "lifecycle_status" : "READY",
    "blocking" : false,
    "checks" : [ "read approved design and review context" ],
    "evidence" : [ "plan is scoped to the approved contract" ],
    "missing_evidence" : [ ],
    "must_fix" : [ ],
    "acceptance_notes" : [ ],
    "open_risks" : [ ],
    "changed_files" : [ ],
    "verification_summary" : "Planning only; implementation and verification happen later.",
    "failure" : {
      "category_hint" : "",
      "verification_remediation" : "NONE",
      "contract_gaps" : [ ],
      "out_of_scope_files" : [ ],
      "missing_tests" : [ ],
      "context_gaps" : [ ],
      "reason" : ""
    },
    "plan" : {
      "implementation_steps" : [ "ordered implementation step" ],
      "edit_files" : [ "path/to/file.ext" ],
      "reference_files" : [ ],
      "file_level_changes" : [ "path/to/file.ext: intended change" ],
      "validation_plan" : [ "verification command or check" ],
      "rollback_notes" : "rollback approach",
      "known_risks" : [ "None identified." ],
      "human_review_checklist" : [ "review item" ],
      "files" : [ {
        "path" : "path/to/file.ext",
        "operation" : "MODIFY"
      } ],
      "verification_bindings" : [ {
        "criterion_id" : "approved-criterion-id",
        "method" : "observable assertion and execution method",
        "executor" : "AGENT",
        "environment_refs" : [ {
          "ref" : "replace/with/actual-environment-ref",
          "sha256" : "0000000000000000000000000000000000000000000000000000000000000000"
        } ],
        "authority_refs" : [ ],
        "evidence_kind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
        "feasibility_refs" : [ {
          "ref" : "replace/with/actual-feasibility-ref",
          "sha256" : "0000000000000000000000000000000000000000000000000000000000000000"
        } ],
        "detail_owner" : "implement.claude_self_test_report",
        "actual_exit_required" : false,
        "expected_exit_code" : null
      } ],
      "authority_refs" : [ ]
    },
    "revision_responses" : [ ]
  }
}


# Required Authored Context

The following verified inputs are mandatory. Respond to every active obligation; ADDRESSED does not close it. Use NOT_ADDRESSED honestly. Initial authors return [].

## Reviewed design

.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/outputs/design-claude.contract.json

{
  "artifact_type" : "agent_output_contract",
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793029979831",
  "node_id" : "design.claude_design",
  "node_instance_id" : "node-design-claude_design-012",
  "handler_type" : "acpx.agent_run",
  "decision" : "READY_FOR_ARCH_REVIEW",
  "summary" : "替换版完整设计：沿用已获认可的六文件骨架，服务测试改为直接断言 DECIMAL128 原值，并新增展示舍入不改变建议的防绕过成对测试。",
  "required_keys" : [ "decision", "summary" ],
  "allowed_decisions" : [ "READY_FOR_ARCH_REVIEW" ],
  "source_output_ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/outputs/design-claude.json",
  "source_artifact_type" : "design_result",
  "generated_at" : "2026-10-26T15:59:37.574450Z",
  "control" : {
    "decision" : "READY_FOR_ARCH_REVIEW",
    "summary" : "替换版完整设计：沿用已获认可的六文件骨架，服务测试改为直接断言 DECIMAL128 原值，并新增展示舍入不改变建议的防绕过成对测试。"
  },
  "control_source" : {
    "kind" : "strict_agent_result_envelope"
  },
  "revision_responses" : [ {
    "evidence" : "替换设计中 PhaseOneAssessmentServiceTest 的除不尽场景（分子 200、名义 3000）改为直接断言 record 返回的 BigDecimal 原值：isEqualByComparingTo 测试内独立写定的 34 位有效数字字面量 0.06666666666666666666666666666666667，并加 precision()==34 断言；断言前禁止 setScale，期望值不得用服务公式重算，服务端提前舍入为 0.066667 的实现必然失败。setScale(6) 类六位展示断言只保留在 AssessIncomeCliRunnerTest；record javadoc 与 docs/15 的表述统一修正为“按 DECIMAL128 计算、未按展示精度进一步舍入的值”。",
    "disposition" : "ADDRESSED",
    "obligation_id" : "sha256:56fb3fc98b780b0a29e6ae48ad6a260eed9f54d9082e4f82f673e6a25781fe37#must_fix:0"
  }, {
    "evidence" : "两份已声明测试文件新增成对场景：AC-2 参数下累计费率 0.0199999999 与 0.0200000001 的 CLI 展示完全相同（持有收益率与阈值均为 2.000000%、增量均为 0.00 USDT、净收益均为 180.00 USDT），服务测试断言原始增量分别为 -0.000001/+0.000001 且建议分别为 PREFER_SIMPLE_EARN（maximumFirstLiveCapital 为空）与 MICRO_VALIDATE_ARBITRAGE（含 5000），CLI 测试断言两次输出分别含对应建议与首次实盘上限文案，证明展示舍入不能改变建议与首次验证上限语义；AC-2 独立样例的 CLI 断言固定为 contains(\"90天累计资金费率阈值=2.000000%\")。同时修正 lifecycle 声明：防绕过边界适用，由 R1 原值断言、R2 成对断言与既有 runnerDependsOnApplicationServiceNotInfrastructureMapper 测试共同覆盖，不再声明不适用。",
    "disposition" : "ADDRESSED",
    "obligation_id" : "sha256:56fb3fc98b780b0a29e6ae48ad6a260eed9f54d9082e4f82f673e6a25781fe37#must_fix:1"
  } ],
  "lifecycle_status" : "READY",
  "checks" : [ "本次为 NEEDS_REVISION 后的完整替换设计而非增量补丁：重读经人工门批准的 Task Contract 与 Codex 评审（run-1793029770286），以 R1/R2 两项 mustFix 为最小修复集重构验证设计；计算口径、职责划分与六文件范围沿用已获认可骨架，未新增平台、机制或文件。", "公式与精度（AC-1）：阈值 =(simpleEarnIncome + knownTotal)/hedgedShortNotional，分子复用既有 DECIMAL128 口径，除法用同一 CALCULATION_CONTEXT（MathContext.DECIMAL128，34 位有效数字）；结果是与 fundingHistory.holdingReturn 同单位的整个 90 天累计费率，任何位置不做 APR 化、不按结算次数或假定 8 小时间隔换算；成本即既有 knownTotal，不重复计费。", "R1 已落实：除不尽场景（分子 200、名义 3000）测试直接断言 record 原值 isEqualByComparingTo 独立写定的 34 位有效数字字面量并加 precision()==34 断言，断言前禁止 setScale，期望值不得用服务公式重算，服务端提前舍入为 0.066667 的实现必然失败；setScale(6) 类六位展示断言仅保留在 CLI 测试；record 注释与文档统一表述为“按 DECIMAL128 计算、未按展示精度进一步舍入的值”。", "R2 已落实：新增服务级与 CLI 级成对测试——AC-2 参数下累计费率 0.0199999999 与 0.0200000001 的百分比均显示 2.000000%、增量均显示 0.00 USDT、净收益均显示 180.00 USDT，但原始增量 -0.000001/+0.000001 必须分别保持 PREFER_SIMPLE_EARN（首次实盘上限为空）与 MICRO_VALIDATE_ARBITRAGE（上限 5000）语义；AC-2 独立样例的 CLI 断言固定为“90天累计资金费率阈值=2.000000%”，不再仅匹配任意六位小数百分比。", "可用性语义（AC-3）：阈值与 estimatedFundingOnlyNetIncome/incrementalIncomeVsSimpleEarn 同条件，仅在 blockers 与 unknowns 均为空的既有 else 分支计算，其余分支 Optional.empty 并沿既有阻断项/未知项文案说明原因，不填 0、不猜数；零或非法名义金额复用 PhaseOneAssessmentRequest 既有 signum()<=0 校验在读取事实前拒绝，不新增校验路径。", "生命周期边界（修订）：本设计只新增一次 assess() 调用内的纯派生不可变值，评估保持只读、不创建 analysis_run，无共享可变状态、索引、锁、事务、队列、缓存、外部副作用或补偿，故并发、超时/提供方失败、中断/崩溃、重启/恢复、回滚/冲突均不适用且不因本变更改变；防绕过边界适用且已由测试覆盖——R1 原值断言阻断服务端提前舍入，R2 成对断言阻断用展示值重新决定建议，既有 runnerDependsOnApplicationServiceNotInfrastructureMapper 测试钉住 CLI 仅依赖服务，CLI 对阈值只做 percent() 格式化、绝不重算。", "构造点与消费点核查：全仓库仅 PhaseOneAssessmentService.java:112 构造 PhaseOneAssessment record，CLI 与 DecisionWorkbenchController 只经服务评估并按访问器只读消费，新增组件对 Web 只读路径零影响、无需修改。", "回归边界（AC-4/AC-5）：建议判定仍用完整精度 delta.signum()、首次小额验证上限 5000、成本与未知项语义、退出码与限制提示全部不变；CLI 既有断言基于 contains，追加新行与新子句不破坏现有测试；实现、程序化测试执行、独立验收与交付流程属后续节点，本设计阶段不运行测试。" ],
  "evidence" : [ "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java:23（CALCULATION_CONTEXT=DECIMAL128）、:42-50（simpleEarnIncome/knownCost 既有口径）、:79-101（blockers/unknowns/充分证据三分支，阈值落在 :87-91 的 else 分支与 netIncome/incremental 同时置值）、:92（建议仍由完整精度 delta.signum() 决定）、:112-117（唯一 record 构造点，新增参数只改此处）。", "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java:12-13：新组件 Optional<BigDecimal> breakEvenCumulativeFundingRate 拟插入 incrementalIncomeVsSimpleEarn 之后、evidenceStatus 之前；src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java:38-40 既有 hedgedShortNotional>0 校验。", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java:160-163（净收益/增量“无法精确计算”展示惯例，阈值行沿用同款式置于增量行后）、:183（限制行）、:301-303 money()=setScale(2,HALF_UP)、:305-307 percent()=×100 后 setScale(6,HALF_UP)——±0.000001 增量均显示 0.00 USDT、179.999999 与 180.000001 均显示 180.00 USDT、0.0199999999 与 0.0200000001 的持有收益率均显示 2.000000%，这是 R2 成对测试的展示事实基础。", "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java:130-158 现有 service()/request()/completeCosts()/point() fixture 可扩展出 AC-2 参数构造器（capital 20000、APR 0.0365、名义 10000/3000、成本合计 20）；src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java:77-110 invoke()/completeArguments() 可加可参数化费率的私有重载，均不改生产代码。", "独立验算（测试锚点，均不经服务代码重复计算）：20000×0.0365×90/365=180；(180+20)/10000=0.02 精确终止小数；累计费率 0.019/0.020/0.021 对应资金费收入 190/200/210、净收入 170/180/190、既有增量 -10/0/+10；零已知成本阈值 180/10000=0.018、零 APR 阈值 20/10000=0.002；除不尽场景 200/3000 按 DECIMAL128 为 0.06666666666666666666666666666666667（34 位有效数字、precision=34，末位由后继 6 进位）。", "docs/README.md 现有编号 01–14，新说明沿用惯例为 docs/15-Funding-Rate-Break-Even-Threshold.md；合同依据 .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.md 与 run-1793029770286 的 design-codex-review.json 两项 mustFix。" ],
  "missing_evidence" : [ ],
  "must_fix" : [ ],
  "open_risks" : [ "CLI 边界测试断言“相对简单赚币增量=0.00 USDT”等展示字符串，钉住的是现有 money()/percent() 格式化行为；若未来展示格式调整需同步该断言，语义断言全部在服务测试的原值断言中，不受展示层影响。", "TR-4 完整基线回归含 Testcontainers MySQL，执行阶段需 Docker 可用，并以 Maven Surefire 报告作为程序化通过依据；该验证属后续执行节点，本设计阶段未实现、未运行测试。" ],
  "verification_summary" : "仅设计修订：完成合同、评审意见与代码核对及样例手工验算，未实现代码、未运行测试；两项 mustFix 均已在此替换设计内闭环。",
  "design" : {
    "planned_files" : [ {
      "path" : "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java",
      "responsibility" : "在 incrementalIncomeVsSimpleEarn 之后新增组件 Optional<BigDecimal> breakEvenCumulativeFundingRate，javadoc 明确其为“按 DECIMAL128 计算、未按展示精度进一步舍入的 90 天累计资金费率追平阈值”；仅承载 typed 结果，不引入新校验或逻辑。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java",
      "responsibility" : "在既有无阻断且无未知项的充分证据 else 分支计算 simpleEarnIncome.add(knownCost).divide(request.hedgedShortNotional(), CALCULATION_CONTEXT) 置入新字段，其余分支保持 Optional.empty；建议判定、首次实盘上限、blockers/unknowns 语义完全不变。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java",
      "responsibility" : "在“相对简单赚币增量”行后新增只读展示行“90天累计资金费率阈值=<percent(值)> 或 无法精确计算”，并在限制行追加“阈值是同口径历史追平点，非年化、非预测”子句；只消费 typed 结果不重算，不影响建议与退出码。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java",
      "responsibility" : "TR-1/TR-2 全量测试设计：新增 AC-2 参数 fixture（capital 20000、APR 0.0365、成本合计 20、名义可变）。(a) 独立样例：对照收益 180、阈值原值 isEqualByComparingTo(\"0.02\")，累计费率 0.019/0.020/0.021 断言原值增量 -10/0/+10 与建议 PREFER/PREFER/MICRO_VALIDATE；(b) R1 除不尽：名义 3000，直接断言 record 原值 isEqualByComparingTo 独立写定字面量 0.06666666666666666666666666666666667 且 precision()==34，断言前禁止 setScale、期望值不得用服务公式重算；(c) R2 防绕过：0.0199999999 与 0.0200000001 两评估阈值原值均为 0.02，原始增量分别为 -0.000001/+0.000001，建议分别为 PREFER_SIMPLE_EARN 且 maximumFirstLiveCapital 为空、MICRO_VALIDATE_ARBITRAGE 且含 5000；(d) 零已知成本阈值 0.018、零 APR 阈值 0.002、负资金费率（单点 -0.005）阈值仍可用且建议 PREFER_SIMPLE_EARN；(e) 成本缺失、条款未确认、无历史结算、期末保持开放时阈值为空且沿既有 blockers/unknowns 文案；(f) 零与负名义金额经既有校验在读取事实前抛 IllegalArgumentException。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java",
      "responsibility" : "TR-3 加 R2 展示验证：新增可参数化费率的私有 invoke 重载与 AC-2 参数 completeArguments 变体（capital 20000、APR 0.0365、成本合计 20、名义 10000）。(a) 完整证据单点 0.02：输出固定断言 contains(\"90天累计资金费率阈值=2.000000%\")（不得仅匹配任意六位小数百分比），并含“简单赚币90天收益=180.00 USDT”；(b) R2 成对：0.0199999999 与 0.0200000001 两次输出均含“资金费持有收益率=2.000000%”“90天累计资金费率阈值=2.000000%”“相对简单赚币增量=0.00 USDT”“资金费率净收益=180.00 USDT”，但分别只出现“建议=优先简单赚币”（不含首次实盘上限）与“建议=仅小额验证智能套利”加“首次实盘上限=5000.00 USDT”；(c) 证据不足（缺退出/滑点成本）：输出含“90天累计资金费率阈值=无法精确计算”且不打印阈值数值；(d) 既有四项测试断言全部保留不回归，六位小数展示断言只存在于本 CLI 测试。",
      "operation" : "MODIFY"
    }, {
      "path" : "docs/15-Funding-Rate-Break-Even-Threshold.md",
      "responsibility" : "简体中文使用说明：定义与公式（阈值 =(对照收益+完整已知成本)/对冲名义，是整个 90 天累计费率、非 APR、不按结算间隔换算）；AC-2 样例与 0.019/0.020/0.021 边界表；精度表述按 R1 修正为“按 DECIMAL128（34 位有效数字）计算、未按展示精度进一步舍入的值，CLI 展示层才做 ×100 后 setScale(6,HALF_UP)”；加入 R2 例子说明 0.0199999999/0.0200000001 展示相同但建议不同、不得用舍入后的 CLI 数字重新决定建议；可用与不可用条件、历史情景限制（非预测、非建议、区间完整性未证明），并指向 docs/09 测试手册。",
      "operation" : "CREATE"
    } ]
  },
  "stage_outcome" : "READY",
  "stage_outcome_source" : "declared_status",
  "evidence_state" : {
    "blocking" : false,
    "evidence_count" : 6,
    "missing_evidence_count" : 0,
    "must_fix_count" : 0,
    "acceptance_note_count" : 0,
    "open_risk_count" : 2
  },
  "authored_context" : {
    "sha256" : "ad018819314f97c39aa94398900858656529b75f32fe0972fb3511ea33a02eea",
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/prompts/design-claude.md.manifest.json"
  }
}


## Active obligations

[ ]
