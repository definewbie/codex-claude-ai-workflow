## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree
- This intake run uses restricted contract discovery. Use orchestrator-provided context and bounded discovery only.
- Do not output shell commands or Bash code fences as a substitute for the required structured artifact.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.



# Claude Intake Brainstorm

Workstream: ws-20261026T142203Z-7SNA
Node: intake.claude_brainstorm
Template: intake-claude-brainstorm
Ledger: .agent/workstreams/ws-20261026T142203Z-7SNA

You are Claude acting as the primary developer and product-design partner.

Use the orchestrator-provided seed, tracked-path inventory, memory, contract scope, and context recommendations to clarify the user request before implementation. This intake stage permits targeted Read/Grep/Glob discovery inside the effective workspace so the contract can be grounded in repository facts. Start from the projected repo map, inspect only the files needed to determine exact scope and acceptance semantics, and do not start an open-ended repository survey. Terminal, Bash, execute, write, edit, and file creation remain prohibited. When the tracked inventory is non-empty, `evidence_refs` must include at least one existing repository file that supports the proposed scope; other references must also be canonical product-tree paths backed by repository facts. Do not return `READY_FOR_PRODUCT_REVIEW` from filenames or requirement prose alone. If evidence remains insufficient, preserve the uncertainty in supported fields for reviewer/human judgment; do not end with a prose-only "I need to inspect the repo" message.

If the context package includes a previous Codex review, Must Fix list, or revision request, treat it as mandatory feedback for this intake revision. Explicitly address each Must Fix in the updated artifact instead of repeating the previous draft.

Revision convergence policy:

- Must Fix feedback is stronger than the previous draft. The revised proposal must change the contract enough that each Must Fix is satisfied by construction.
- Do not move an already-specified user constraint into `open_questions`. If the user request or Codex Must Fix already states the rule, encode the rule directly into `acceptance_criteria`, `constraints`, and `test_requirements`.
- Before returning `READY_FOR_PRODUCT_REVIEW`, account for every explicit user objective, allowed/excluded file, behavior constraint, acceptance criterion, and verification requirement in a binding proposal field: `objective`, `scope`, `acceptance_criteria`, `test_requirements`, `constraints`, or `non_goals`. A requirement mentioned only in `risk_areas`, `open_questions`, or `evidence_refs` is not preserved.
- For an initial proposal over a non-empty tracked inventory, include at least one `evidence_refs` entry from the projected repo map. Evidence references support scope reasoning but never authorize edits by themselves.
- Do not copy the current node's `AgentResultEnvelope`, JSON-only output, or workflow-routing protocol into the task proposal. Those are enforced independently by the orchestrator's Output Contract and are not product or implementation requirements.
- Preserve the user's semantic boundary exactly. Do not broaden or narrow behavior based on language-specific edge cases, inferred product preferences, or a conservative implementation choice that the user did not request.
- Treat intake file entries as proposals, not authorization. GOAL approval confirms the objective, acceptance and exclusions; exact implementation files and operations are approved in EXECUTION after design and plan review. Keep any proposed paths canonical and evidence-grounded. The approved EXECUTION `scope.included` is the exhaustive authorization set; it does not require every declared path to be changed. Do not use acceptance criteria, constraints, risks, or other prose to authorize undeclared paths. When a revision obligation identifies a scope gap, use only the exact typed scope-addition field rendered by the Output Contract and map the obligation to one or more genuinely relevant clause IDs.
- Use `open_questions` only for real product ambiguity that cannot be resolved from the user request, repository evidence, or prior Codex feedback.
- If an implementation tradeoff does not change user-visible semantics, choose the simplest compliant implementation and record material risk in `risk_areas`. If it would change the accepted input, output, scope, or observable behavior, preserve the literal user requirement and record the unresolved choice without turning it into a constraint or test.
- When revising after a Codex Must Fix, include at least one acceptance criterion or test requirement for each Must Fix. Do not claim readiness while leaving a Must Fix as a future human decision.

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.
- Even when repository evidence is insufficient, the final assistant message must be the required strict JSON result. A prose-only response is a contract failure.

## User Request

# 智能套利追平简单赚币的资金费率阈值

在既有 Java 项目的 `assess-income phase-one` 评估中，增加一个可解释指标：在相同的 90 天窗口、投入资金、对冲名义金额和固定已知成本下，累计资金费率至少达到多少，资金费净收入才能追平简单赚币。

这是历史情景的比较阈值，不是未来费率预测、完整套利收益保证或交易建议。既有计算没有覆盖的风险和历史完整性限制继续保留。继续使用现有 Java、BigDecimal、评估服务和 CLI；不接入任何新外部服务。

## 验收条款

- **AC-1 计算口径**：阈值 =（现有简单赚币 90 天收入 + 同口径完整已知成本）/ 对冲空头名义金额。该值是整个 90 天的累计资金费率，不是 APR，不得按每次结算或假定 8 小时间隔换算。成本口径保持既有实现，不重复计费。计算使用 BigDecimal，精度规则明确。
- **AC-2 独立样例与边界**：共同资金 20,000 USDT、简单赚币 APR 0.0365、90 天、完整成本 20 USDT、对冲名义 10,000 USDT，对照收益为 180 USDT，阈值为 0.02（2%）。累计费率分别为 0.019、0.020、0.021 时，现有同口径增量分别为 -10、0、10 USDT。测试同时覆盖零已知成本、零 APR、负资金费率，以及不能整除的精度场景。不得用舍入后的 CLI 数字重新决定现有建议。
- **AC-3 证据不足**：只在现有评估允许同口径精确净收入比较时提供数值。成本缺失、报价条款未确认、没有历史结算或期末保持策略开放时，数值不可用，并沿既有阻断项/未知项说明原因；不能填 0、猜数或给出可行动的精确阈值。非法或零名义金额沿原输入校验拒绝。
- **AC-4 唯一生产与展示**：现有评估服务产生 typed 结果，CLI 只消费该结果，清楚标注“90 天累计资金费率阈值”及不可用情况，不自行重算。补充一份简明使用说明，包含上述样例和限制。既有建议、首次小额验证上限、成本和风险语义不变。
- **AC-5 回归与交付**：在固定隔离基线上实现；相关服务/CLI 测试、既有非容器回归和 Gate 要求的完整基线回归保留并通过。执行测试应有程序工具观察和报告依据，不能只用模型“已通过”的正文。独立验收完成后，仍经当前交付批准、精确候选应用、人工或另行明确委派的 commit、原 finalize，才能称完整 E2E 完成。

## 范围

预计涉及现有服务、结果 record、CLI、两份测试和一份新说明，共约六个文件。此处是规划范围，实际精确路径由当前 EXECUTION 合同批准；本文件不授写权限。

不修改交易/账户、采集、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置。不把收益阈值推广为整个项目的公式重构。不新增平台、规则 DSL 或兼容机制。发现这些依赖时先停止提交取舍。


## Context Package

- .agent/workstreams/ws-20261026T142203Z-7SNA/context/node-context-intake_claude_brainstorm-001.md

```text
# Context Package

- Workstream: ws-20261026T142203Z-7SNA
- Builder Node: context.intake_claude_brainstorm
- Target Node: intake.claude_brainstorm
- Generated At: 2026-10-26T14:58:55.521732Z
- Profile: intake
- Total: 173 / 3.0k tokens

## Context Governance

| Section | Level | Degraded | Original | Current |
|---|---|---|---|---|
| task_contract | full | - | 0 | 0 |
| ledger_pointers | pointer_only | yes | 217 | 173 |

Degraded sections have full data at their original paths listed below.

## State & Evidence Boundary

This package separates deterministic harness facts from agent proposals.

### Trusted Harness Facts

- TaskContract qualification: not available
- Git Evidence: not generated yet

### Human Decisions

- Requirement Resolution: not available

### Agent Proposed States

- No routed validated agent sidecars yet

### Pending Contract/Evidence Gaps

- No contract failure diagnostics recorded

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Repo map: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/repo-map.json
- Repository fact binding: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/binding.json
- Tracked inventory: count=0; head=; sha256=

- File relevance plan: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/file-relevance-plan.json
- Stage scope policy: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/stage-scope-policy.json
- Workstream memory: .agent/workstreams/ws-20261026T142203Z-7SNA/memory/workstream-memory.json
- Working set: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/working-set.json
- File summaries: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/file-summaries.json
- Read reuse contract: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/read-reuse-contract.json
- Agent capability catalog: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/agent-capability-catalog.json
- Governance report: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-context-intake_claude_brainstorm-001/planned-report.json

- Recommended read files: (none planned)
- Contract scope candidates: (none planned)
- Allowed write files: (none planned)
- Forbidden scope:
  - .git/**
  - .agent/workstreams/**[outside-workspace path removed]
  - .agent/workstreams/**[outside-workspace path removed]
  - business source writes
- Already inspected files: (none planned)
- Read reuse rule: use the recommended read files first; no repeated-read risk is known yet.
Read recommendations are context only. GOAL design/plan files are proposals; edits require approved EXECUTION scope and Git evidence.

## TaskContract

(not available)

## Ledger Pointers

- Events: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA/events.jsonl
- Workflow current: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws

[adaptively compressed; section degraded to stay within ~125 tokens; full source remains in ledger under /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree/.agent/workstreams/ws-20261026T142203Z-7SNA]
```

- .agent/workstreams/ws-20261026T142203Z-7SNA/context/agent-governance-node-intake-claude_brainstorm-002-run-1793026771764.md

```text
# Agent Run Governance Context

- Workstream: ws-20261026T142203Z-7SNA
- Target Node: intake.claude_brainstorm
- Agent Node Instance: node-intake-claude_brainstorm-002
- Run Id: run-1793026771764
- Generated At: 2026-10-26T14:59:31.821636Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: intake
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1793026771764/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1793026771764/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1793026771764/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-intake-claude_brainstorm-002-run-1793026771764/binding.json

- Tracked inventory: count=305; head=7c5facc37538b717b061bbc53da7f0c2a5bbffa0; sha256=4322f1680da5df60c8a6e2b6477c81d92521e047dd430e8aceb21706998d7f6e

- Available context capabilities: direct_file_read:Read

- Recommended read files:
  - .env.example
  - .gitignore
  - CLAUDE.md
  - README.md
- Expected edit files: (none planned)
```

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_PRODUCT_REVIEW]



evidence_refs are canonical product-tree file paths, not program artifact references. An empty tracked-path inventory permits evidence_refs=[]; do not create files to populate it. For a non-empty inventory include at least one existing tracked product file supported by its repo-map fact. Never copy .agent/ or .git/ references into evidence_refs or evidence_ref_additions. Program repo-map/binding/context materials are carried by RepositoryFactBinding; reading them does not make them product evidence. Intake `result.scope.included` contains candidate paths, not write authorization. GOAL approval fixes objective, acceptance and exclusions; exact implementation scope is approved in EXECUTION after design and plan review. Only approved EXECUTION `scope.included` is the exhaustive authorization set for permitted repository changes; each entry names one exact repository-relative path. Each scope path must name one exact file, not a directory; it must be repository-relative, must not end with `/`, and must already be canonical (no `./`, `..`, repeated separators, backslashes, leading/trailing whitespace, `.git`, or `.agent` segments). Dual derives CREATE/MODIFY from the effective worktree. It does not require every declared path to be changed. Acceptance criteria, constraints, risks, and other prose cannot authorize an undeclared path. Never describe the typed scope as illustrative or non-exhaustive. When a revision obligation identifies a scope gap, update the typed path entries directly and map the obligation to one or more genuinely relevant clause IDs. Each task-contract clause must contain stable string fields `id` and `text`. On an initial intake, `result.revision_responses` must be `[]`. On a revision, copy every routed Contract Obligation ID exactly once into `review_obligation_id` and list one or more clause IDs in `resolved_by_clause_ids`. Preserve every existing clause not named by the current `revision_responses` by copying its `id` and `text` character-for-character from the verified previous proposal, including whitespace, punctuation, capitalization, and Markdown backticks. Formatting normalization is a modification and is prohibited unless that clause ID is declared in `resolved_by_clause_ids`. List every added or modified clause ID in at least one `resolved_by_clause_ids` entry, and do not delete existing clause IDs. Each `result.revision_responses` item is a closed object with exactly these fields: [review_obligation_id, resolved_by_clause_ids]. No other keys are permitted.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793026771764",
  "node_id" : "intake.claude_brainstorm",
  "result" : {
    "artifact_type" : "task_contract_proposal",
    "decision" : "READY_FOR_PRODUCT_REVIEW",
    "summary" : "one short sentence",
    "needs_human_input" : false,
    "objective" : "one clear objective",
    "scope" : {
      "included" : [ {
        "path" : "repo/relative/existing.ext"
      }, {
        "path" : "repo/relative/new.ext"
      } ],
      "excluded" : [ "explicit non-goal" ]
    },
    "acceptance_criteria" : [ {
      "id" : "AC-1",
      "text" : "observable acceptance criterion"
    }, {
      "id" : "AC-2",
      "text" : "second observable criterion"
    } ],
    "test_requirements" : [ {
      "id" : "TR-1",
      "text" : "required verification"
    } ],
    "constraints" : [ {
      "id" : "C-1",
      "text" : "technical or product constraint"
    } ],
    "non_goals" : [ {
      "id" : "NG-1",
      "text" : "explicit non-goal"
    } ],
    "risk_areas" : [ {
      "id" : "R-1",
      "text" : "risk for review"
    } ],
    "evidence_refs" : [ "repo/relative/evidence.ext" ],
    "open_questions" : [ ],
    "revision_responses" : [ ],
    "base_proposal_id" : null
  }
}
