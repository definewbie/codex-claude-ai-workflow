## Execution Workspace Guard

- Effective workspace: /Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree
- Run all shell commands from the effective workspace above.
- Modify files only inside the effective workspace.
- Ignore absolute paths outside the effective workspace even if they appear in quoted prior outputs.
- Do not run commands with `git -C` pointing outside the effective workspace.

## Response Language Policy

- Use Simplified Chinese for human-readable string values inside the final JSON result.
- Keep JSON keys, enum values, file paths, and code identifiers exactly as specified.
- Do not wrap the final JSON in Markdown.

## Structured Artifact Field Semantics

- `must_fix`, `missing_evidence`, `open_risks`, and `failure.reason` mean unresolved blockers for the current decision.
- If the decision is positive, ready, or accepted, keep blocking fields empty: `blocking=false`, `must_fix=[]`, `missing_evidence=[]`, and `failure.reason=""`.
- Do not use `must_fix` to list review comments that you already resolved. Put resolved review comments in `checks`, `evidence`, or `acceptance_notes` instead.

# Claude Implementation Plan

Workstream: ws-20261026T142203Z-7SNA
Node: plan.claude_plan
Template: plan-claude
Ledger: .agent/workstreams/ws-20261026T142203Z-7SNA

Ledger write policy:

- Do not create, edit, or delete files under .agent/.
- Only the orchestrator writes run ledger artifacts.
- Return your artifact in stdout using the contract below.

You are Claude acting as the primary developer. Convert the independently reviewed design into a concrete implementation plan.

Do not implement code in this stage. Keep the plan small enough to execute and verify. Do not expand scope.

Under GOAL, planned files are proposals, not authorization: derive canonical paths from the reviewed design while respecting the approved objective and exclusions. Exact EXECUTION scope approval follows design and plan review. Under EXECUTION, the plan must remain within approved paths and operations; a change outside them requires new approval before implementation.

Planning-stage boundary:

- Do not execute the plan.
- Do not run build, typecheck, pytest, npm, npx, install, or other validation commands.
- Do not create, edit, or delete project files.
- You may inspect context and repository files using read/search tools only.
- Put commands that should be run later under `Validation Plan`; the self-test node owns execution and evidence collection.
- If a previous review asks for verification evidence, plan how the self-test node will produce it; do not produce the evidence here.

## User Request

# 智能套利追平简单赚币的资金费率阈值

在既有 Java 项目的 `assess-income phase-one` 评估中，增加一个可解释指标：在相同的 90 天窗口、投入资金、对冲名义金额和固定已知成本下，累计资金费率至少达到多少，资金费净收入才能追平简单赚币。

这是历史情景的比较阈值，不是未来费率预测、完整套利收益保证或交易建议。既有计算没有覆盖的风险和历史完整性限制继续保留。继续使用现有 Java、BigDecimal、评估服务和 CLI；不接入任何新外部服务。

## 验收条款

- **AC-1 计算口径**：阈值 =（现有简单赚币 90 天收入 + 同口径完整已知成本）/ 对冲空头名义金额。该值是整个 90 天的累计资金费率，不是 APR，不得按每次结算或假定 8 小时间隔换算。成本口径保持既有实现，不重复计费。计算使用 BigDecimal，精度规则明确。
- **AC-2 独立样例与边界**：共同资金 20,000 USDT、简单赚币 APR 0.0365、90 天、完整成本 20 USDT、对冲名义 10,000 USDT，对照收益为 180 USDT，阈值为 0.02（2%）。累计费率分别为 0.019、0.020、0.021 时，现有同口径增量分别为 -10、0、10 USDT。测试同时覆盖零已知成本、零 APR、负资金费率，以及不能整除的精度场景。不得用舍入后的 CLI 数字重新决定现有建议。
- **AC-3 证据不足**：只在现有评估允许同口径精确净收入比较时提供数值。成本缺失、报价条款未确认、没有历史结算或期末保持策略开放时，数值不可用，并沿既有阻断项/未知项说明原因；不能填 0、猜数或给出可行动的精确阈值。非法或零名义金额沿原输入校验拒绝。
- **AC-4 唯一生产与展示**：现有评估服务产生 typed 结果，CLI 只消费该结果，清楚标注“90 天累计资金费率阈值”及不可用情况，不自行重算。补充一份简明使用说明，包含上述样例和限制。既有建议、首次小额验证上限、成本和风险语义不变。
- **AC-5 回归与交付**：在固定隔离基线上实现；相关服务/CLI 测试、既有非容器回归和 Gate 要求的完整基线回归保留并通过。执行测试应有程序工具观察和报告依据，不能只用模型“已通过”的正文。独立验收完成后，仍经当前交付批准、精确候选应用、人工或另行明确委派的 commit、原 finalize，才能称完整 E2E 完成。

## 范围

预计涉及现有服务、结果 record、CLI、两份测试和一份新说明，共约六个文件。此处是规划范围，实际精确路径由当前 EXECUTION 合同批准；本文件不授写权限。

不修改交易/账户、采集、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置。不把收益阈值推广为整个项目的公式重构。不新增平台、规则 DSL 或兼容机制。发现这些依赖时先停止提交取舍。


## Context Package

### Direct Input Artifacts

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.stderr.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.transcript.log
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.json

```json
{
  "workstreamId" : "ws-20261026T142203Z-7SNA",
  "runId" : "run-1793030916946",
  "nodeId" : "plan.codex_plan_review",
  "nodeInstanceId" : "node-plan-codex_plan_review-019",
  "stageOutcome" : "READY",
  "lifecycleStatus" : "READY",
  "decision" : "READY_TO_IMPLEMENT",
  "summary" : "六文件计划与已复审设计一致，实施步骤、测试断言及验证责任明确，可进入精确 EXECUTION 范围审批。",
  "sourceArtifactType" : "agent_output_contract",
  "sourceOutputRef" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.json",
  "blocking" : false,
  "checks" : [ "已先审阅 Review Evidence Brief，再核对完整 plan_artifact；未将压缩摘要作为完整计划，也未仅检查上一轮修订项。", "文件与范围一致：edit_files、files、file_level_changes 和实施步骤均对应已评审的五项 MODIFY 与一项 CREATE；未引入排除范围内的修改。", "实施顺序可执行：先核对固定隔离基线，再修改结果类型、服务及构造点、CLI、测试和说明，最后检查改动范围并交接程序化验证。", "AC-1 至 AC-4 均有实施落点：复用既有收入和成本，显式使用 DECIMAL128；仅在充分证据分支产生阈值；CLI 消费 typed 字段；保留建议、首次验证上限及历史限制。", "R1、R2 完整承接：服务测试直接断言独立精度字面量；成对测试验证展示相同但原始增量异号时建议及上限不同；CLI 固定断言 2.000000%。", "测试覆盖完整：独立样例、零成本、零 APR、负费率、除不尽、四类不可用条件及非法名义金额均有明确断言，非法输入还要求证明事实查询未发生。", "边界审查：PASS（计划层面）。权威结果由 PhaseOneAssessmentService 产生、PhaseOneAssessment 承载、CLI 展示；证据不足通过 Optional.empty 和既有原因阻止精确阈值输出。未新增持久状态或外部写入，无需增加并发、恢复或补偿机制。", "验证计划明确绑定 TR-1 至 TR-4、执行责任节点、实际退出码和 Surefire 报告；完整 mvn test 包含既有非容器及容器回归，Docker 不可用时不得以跳过替代通过。", "计划保留代码检查以确认 CLI 不重算，并明确测试通过不替代独立验收及后续交付门；未把计划中的防绕过测试描述为已经执行的证明。" ],
  "evidence" : [ ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030521008/outputs/plan-claude.contract.json：完整实施步骤、六文件操作、verification_bindings、validation_plan、回滚说明与人工审查清单。", ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/outputs/design-claude.contract.json：计划对应的完整设计及 R1、R2 修订。", ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/outputs/design-codex-review.json：设计复审通过，并明确设计验收与实现证明的区别。", ".agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.md：此前已核验的验收条款、测试要求、固定基线与范围约束。" ],
  "mustFix" : [ ],
  "contractObligations" : [ ],
  "missingEvidence" : [ ],
  "acceptanceNotes" : [ "READY_TO_IMPLEMENT 表示计划充分，不授予写入权限；实际修改仍以随后批准的 EXECUTION 精确路径和操作为准。", "environment_refs 为空，本轮没有环境就绪证明。设计及评审的 prompt manifest 仅可作为上下文来源，不能替代执行授权、JDK/Maven/Docker 就绪证据或测试结果。", "执行时应按工作区规则使用 rtk 前缀，并将实际命令、退出码及本次候选对应的 Surefire 报告关联保存；核对要求的测试确实执行，不能仅看退出码或旧报告。", "回滚说明适用于计划声明的干净隔离基线及本次候选改动；实际恢复时需明确基线和文件范围，保留其他工作。", "独立验收、交付批准、精确候选应用、人工或明确委派的 commit 和原 finalize 仍须完成，才能声明完整 E2E 完成。" ],
  "openRisks" : [ ],
  "changedFiles" : [ ],
  "verificationSummary" : "已基于完整 typed 计划、已复审设计及此前核验的合同事实完成只读审查；未修改文件、未运行构建或测试，未确认执行环境就绪。",
  "completedWork" : [ ],
  "importantDecisions" : [ ],
  "recommendedNextStage" : "",
  "suggestedNextPrompt" : "",
  "control" : {
    "decision" : "READY_TO_IMPLEMENT",
    "summary" : "六文件计划与已复审设计一致，实施步骤、测试断言及验证责任明确，可进入精确 EXECUTION 范围审批。"
  },
  "failure" : {
    "categoryHint" : "",
    "verificationRemediation" : "NONE",
    "contractGaps" : [ ],
    "outOfScopeFiles" : [ ],
    "missingTests" : [ ],
    "contextGaps" : [ ],
    "reason" : ""
  },
  "rereadReasons" : [ ],
  "reviewSubject" : null,
  "taskContractProposal" : null,
  "repositoryFactBinding" : null,
  "proposalDerivation" : null,
  "planArtifact" : null,
  "design" : null,
  "authoredRevisionResponses" : null,
  "authoredContext" : {
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/prompts/plan-codex-review.md.manifest.json",
    "sha256" : "7b8a17d34424906c1c509b8e017731cbe3321bcd30699729e3119832566066ce"
  },
  "verificationChecks" : [ ]
}
```

- .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-codex_plan_review-019-run-1793030916946/binding.json
  (content omitted; no typed context projection)

- .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.contract.json
  (validated typed evidence already projected)

- .agent/workstreams/ws-20261026T142203Z-7SNA/context/agent-governance-node-plan-claude_plan-022-run-1793048679201.md

```text
# Agent Run Governance Context

- Workstream: ws-20261026T142203Z-7SNA
- Target Node: plan.claude_plan
- Agent Node Instance: node-plan-claude_plan-022
- Run Id: run-1793048679201
- Generated At: 2026-10-26T21:04:39.360966Z

## Repo Scope Guidance

This section is a passive harness guardrail. It guides repository exploration but does not replace task contract, artifact validation, or human approval.

- Stage: plan
- Governance refs: capabilityCatalog=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-claude_plan-022-run-1793048679201/agent-capability-catalog.json; readReuseContract=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-claude_plan-022-run-1793048679201/read-reuse-contract.json; repoMap=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-claude_plan-022-run-1793048679201/repo-map.json; repositoryFactBinding=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-claude_plan-022-run-1793048679201/binding.json

- Tracked inventory: count=0; head=; sha256=

- Available context capabilities: direct_file_read:Read

- Recommended read files: (none planned)
- Expected edit files: (none planned)
## Verification readiness declarations

These are operator declarations of prerequisites, not execution results, successful tests or grants. Bind exact refs only where criterion, method, executor and environment match. If prerequisites are missing, describe the missing items without inventing references.

[ {
  "detail" : "",
  "reference" : {
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/verification-readiness/okx-ac-availability-20261027-01.json",
    "sha256" : "1212daf7ab19146a19336a41ac32668c60a31d76f48a6bf0292d361006129d08"
  },
  "declaration" : {
    "request" : {
      "schema" : 1,
      "requestId" : "okx-ac-availability-20261027-01",
      "subject" : "node-gate-human_plan_approval-021",
      "goal" : {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.json",
        "sha256" : "41f643f07f822573dfa2a13e8f5ede75aa2efd83fdca3efa20130ca0ae2bf04f"
      },
      "epoch" : 1,
      "criterionIds" : [ "AC-1", "AC-2", "AC-3", "AC-4", "AC-5" ],
      "method" : "在本隔离工作树使用 JDK 25 与现有 Maven 执行 mvn -o clean test，依据本次源码对应的 Surefire XML/日志及程序工具观察核验服务、CLI 和全部 MySQL/Testcontainers 回归；按 AC-1..AC-5 分别关联独立样例、DECIMAL128 原值、显示舍入不改变建议、不可用情形、既有行为与中文说明的断言。通过程序工具读取实际变更和说明进行逐条语义检查。既有宿主166项基线仅作环境材料，不代替本次源码测试；原生状态、reported exit 和 actual exit 如实区分，任何未经原生程序观察提供的实际退出码不由模型或声明补造。",
      "executor" : "AGENT",
      "evidenceKind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
      "environment" : {
        "workspace" : "/Users/kriswang/work/projects/ai/codex-claude-ai-workflow/dual-orchestrator/output/w09-okx-next-e2e-gate-20261026/fixture/case/worktree",
        "identity" : "6812930430b5d9f79961ff96be00a671aa7c1e8d429384ec8f724fb86ea661a1",
        "owner" : "Gate operator under user-approved preparation scope",
        "dependencies" : [ {
          "path" : "[outside-workspace path removed]",
          "sha256" : "f9381d0cb98abaaf9592dae421eddc497e84ed9bfb723b84c111d1350863c3a2",
          "absent" : false
        }, {
          "path" : "[outside-workspace path removed]",
          "sha256" : "35c0e7afcaeb977100d0b90725cc52ee73123c9286cdf3b423fe53d7f0ea0491",
          "absent" : false
        }, {
          "path" : "[outside-workspace path removed]",
          "sha256" : "dce9d077a812a466c45a2e2e50763739fdc222c7823bb2ceb84c7ca5a3d0dc7e",
          "absent" : false
        } ]
      },
      "statement" : "已只读核对宿主 JDK/Maven、Docker 服务及缓存 MySQL/ryuk 镜像。此为实际前提可用性的 operator 声明候选，不证明原生客户端已执行测试、提供实际退出码或实现已通过；GOAL 未统一要求 actual_exit。当前计划的TR编号/空environment_refs/提示词feasibility_refs及额外actual_exit要求尚待按原计划门返修，本声明不替其批准或消除这些限制。",
      "detailOwner" : "implement.claude_self_test_report",
      "lifetime" : "AUTHORIZATION_EPOCH",
      "expiresAt" : null,
      "action" : "RECORD",
      "supersedes" : null
    },
    "receivedAt" : 1793031230.207763000,
    "source" : "OPERATOR_ATTESTED",
    "rule" : "verification-readiness-v1"
  },
  "state" : "CURRENT_OPERATOR_DECLARATION"
} ]
```

Context use rule:

- If the package contains `Working Memory`, use it before reading repository files.
- Re-read files only when the memory is missing, stale, or insufficient for planning.
- If the Context Package contains a Read Reuse Contract, follow that contract exactly. Do not invent read-reuse fields when the contract does not declare them.

## External Research Discipline

- Use repository facts and supplied context first.
- WebSearch is not auto-approved; request human approval if necessary for this occurrence. Use it only for public package, version, or documentation facts.
- Never use WebFetch or arbitrary URL retrieval. Do not place secrets, source contents, credentials, or private identifiers in a search query.
- If the needed public fact cannot be obtained under the active permission policy, state the evidence gap instead of bypassing the policy.

## Output Contract

Return exactly one JSON object as the final assistant message.
Do not use Markdown fences, XML tags, headings, commentary, or text before/after the JSON.
Preserve the exact key names and JSON primitive types shown below. Replace example values with factual values.
Every JSON object is closed. Do not add keys that are not declared for that object.
Allowed `result.decision` values: [READY_FOR_PLAN_REVIEW]
Allowed `result.failure.verification_remediation` values for this node: [NONE]

For this node, `result.failure.verification_remediation` must remain `NONE`.

`result.revision_responses` is required: return [] when there are no active authored obligations. Otherwise cover every active obligation_id from Required Authored Context exactly once; do not add unknown IDs or omit unresolved obligations. Each entry has exactly obligation_id, disposition (ADDRESSED or NOT_ADDRESSED), and non-empty evidence. Use NOT_ADDRESSED when unresolved; ADDRESSED is a claim for review, not an approval or closure. Preserve all previously required behavior and the approved contract while making this revision.
edit_files must contain unique canonical proposed paths respecting the approved GOAL exclusions. Exact file operations require later EXECUTION approval. Each scope path must name one exact file, not a directory; it must be repository-relative, must not end with `/`, and must already be canonical (no `./`, `..`, repeated separators, backslashes, leading/trailing whitespace, `.git`, or `.agent` segments). A subset is allowed; reference_files do not authorize edits. Each `result.revision_responses` item is a closed object with exactly these fields: [obligation_id, disposition, evidence]. No other keys are permitted.
Each verification_binding must explicitly set actual_exit_required (boolean) and expected_exit_code (integer or null). Derive these from the approved acceptance requirements before execution; never weaken a required exit check. expected_exit_code requires actual_exit_required=true. Operator declarations cannot supply measured process exits.

{
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793048679201",
  "node_id" : "plan.claude_plan",
  "result" : {
    "artifact_type" : "plan_result",
    "decision" : "READY_FOR_PLAN_REVIEW",
    "summary" : "one short sentence",
    "lifecycle_status" : "READY",
    "blocking" : false,
    "checks" : [ "read approved design and review context" ],
    "evidence" : [ "plan is scoped to the approved contract" ],
    "missing_evidence" : [ ],
    "must_fix" : [ ],
    "acceptance_notes" : [ ],
    "open_risks" : [ ],
    "changed_files" : [ ],
    "verification_summary" : "Planning only; implementation and verification happen later.",
    "failure" : {
      "category_hint" : "",
      "verification_remediation" : "NONE",
      "contract_gaps" : [ ],
      "out_of_scope_files" : [ ],
      "missing_tests" : [ ],
      "context_gaps" : [ ],
      "reason" : ""
    },
    "plan" : {
      "implementation_steps" : [ "ordered implementation step" ],
      "edit_files" : [ "path/to/file.ext" ],
      "reference_files" : [ ],
      "file_level_changes" : [ "path/to/file.ext: intended change" ],
      "validation_plan" : [ "verification command or check" ],
      "rollback_notes" : "rollback approach",
      "known_risks" : [ "None identified." ],
      "human_review_checklist" : [ "review item" ],
      "files" : [ {
        "path" : "path/to/file.ext",
        "operation" : "MODIFY"
      } ],
      "verification_bindings" : [ {
        "criterion_id" : "approved-criterion-id",
        "method" : "observable assertion and execution method",
        "executor" : "AGENT",
        "environment_refs" : [ {
          "ref" : "replace/with/actual-environment-ref",
          "sha256" : "0000000000000000000000000000000000000000000000000000000000000000"
        } ],
        "authority_refs" : [ ],
        "evidence_kind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
        "feasibility_refs" : [ {
          "ref" : "replace/with/actual-feasibility-ref",
          "sha256" : "0000000000000000000000000000000000000000000000000000000000000000"
        } ],
        "detail_owner" : "implement.claude_self_test_report",
        "actual_exit_required" : false,
        "expected_exit_code" : null
      } ],
      "authority_refs" : [ ]
    },
    "revision_responses" : [ ]
  }
}


# Required Authored Context

The following verified inputs are mandatory. Respond to every active obligation; ADDRESSED does not close it. Use NOT_ADDRESSED honestly. Initial authors return [].

## Reviewed design

.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/outputs/design-claude.contract.json

{
  "artifact_type" : "agent_output_contract",
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793029979831",
  "node_id" : "design.claude_design",
  "node_instance_id" : "node-design-claude_design-012",
  "handler_type" : "acpx.agent_run",
  "decision" : "READY_FOR_ARCH_REVIEW",
  "summary" : "替换版完整设计：沿用已获认可的六文件骨架，服务测试改为直接断言 DECIMAL128 原值，并新增展示舍入不改变建议的防绕过成对测试。",
  "required_keys" : [ "decision", "summary" ],
  "allowed_decisions" : [ "READY_FOR_ARCH_REVIEW" ],
  "source_output_ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/outputs/design-claude.json",
  "source_artifact_type" : "design_result",
  "generated_at" : "2026-10-26T15:59:37.574450Z",
  "control" : {
    "decision" : "READY_FOR_ARCH_REVIEW",
    "summary" : "替换版完整设计：沿用已获认可的六文件骨架，服务测试改为直接断言 DECIMAL128 原值，并新增展示舍入不改变建议的防绕过成对测试。"
  },
  "control_source" : {
    "kind" : "strict_agent_result_envelope"
  },
  "revision_responses" : [ {
    "evidence" : "替换设计中 PhaseOneAssessmentServiceTest 的除不尽场景（分子 200、名义 3000）改为直接断言 record 返回的 BigDecimal 原值：isEqualByComparingTo 测试内独立写定的 34 位有效数字字面量 0.06666666666666666666666666666666667，并加 precision()==34 断言；断言前禁止 setScale，期望值不得用服务公式重算，服务端提前舍入为 0.066667 的实现必然失败。setScale(6) 类六位展示断言只保留在 AssessIncomeCliRunnerTest；record javadoc 与 docs/15 的表述统一修正为“按 DECIMAL128 计算、未按展示精度进一步舍入的值”。",
    "disposition" : "ADDRESSED",
    "obligation_id" : "sha256:56fb3fc98b780b0a29e6ae48ad6a260eed9f54d9082e4f82f673e6a25781fe37#must_fix:0"
  }, {
    "evidence" : "两份已声明测试文件新增成对场景：AC-2 参数下累计费率 0.0199999999 与 0.0200000001 的 CLI 展示完全相同（持有收益率与阈值均为 2.000000%、增量均为 0.00 USDT、净收益均为 180.00 USDT），服务测试断言原始增量分别为 -0.000001/+0.000001 且建议分别为 PREFER_SIMPLE_EARN（maximumFirstLiveCapital 为空）与 MICRO_VALIDATE_ARBITRAGE（含 5000），CLI 测试断言两次输出分别含对应建议与首次实盘上限文案，证明展示舍入不能改变建议与首次验证上限语义；AC-2 独立样例的 CLI 断言固定为 contains(\"90天累计资金费率阈值=2.000000%\")。同时修正 lifecycle 声明：防绕过边界适用，由 R1 原值断言、R2 成对断言与既有 runnerDependsOnApplicationServiceNotInfrastructureMapper 测试共同覆盖，不再声明不适用。",
    "disposition" : "ADDRESSED",
    "obligation_id" : "sha256:56fb3fc98b780b0a29e6ae48ad6a260eed9f54d9082e4f82f673e6a25781fe37#must_fix:1"
  } ],
  "lifecycle_status" : "READY",
  "checks" : [ "本次为 NEEDS_REVISION 后的完整替换设计而非增量补丁：重读经人工门批准的 Task Contract 与 Codex 评审（run-1793029770286），以 R1/R2 两项 mustFix 为最小修复集重构验证设计；计算口径、职责划分与六文件范围沿用已获认可骨架，未新增平台、机制或文件。", "公式与精度（AC-1）：阈值 =(simpleEarnIncome + knownTotal)/hedgedShortNotional，分子复用既有 DECIMAL128 口径，除法用同一 CALCULATION_CONTEXT（MathContext.DECIMAL128，34 位有效数字）；结果是与 fundingHistory.holdingReturn 同单位的整个 90 天累计费率，任何位置不做 APR 化、不按结算次数或假定 8 小时间隔换算；成本即既有 knownTotal，不重复计费。", "R1 已落实：除不尽场景（分子 200、名义 3000）测试直接断言 record 原值 isEqualByComparingTo 独立写定的 34 位有效数字字面量并加 precision()==34 断言，断言前禁止 setScale，期望值不得用服务公式重算，服务端提前舍入为 0.066667 的实现必然失败；setScale(6) 类六位展示断言仅保留在 CLI 测试；record 注释与文档统一表述为“按 DECIMAL128 计算、未按展示精度进一步舍入的值”。", "R2 已落实：新增服务级与 CLI 级成对测试——AC-2 参数下累计费率 0.0199999999 与 0.0200000001 的百分比均显示 2.000000%、增量均显示 0.00 USDT、净收益均显示 180.00 USDT，但原始增量 -0.000001/+0.000001 必须分别保持 PREFER_SIMPLE_EARN（首次实盘上限为空）与 MICRO_VALIDATE_ARBITRAGE（上限 5000）语义；AC-2 独立样例的 CLI 断言固定为“90天累计资金费率阈值=2.000000%”，不再仅匹配任意六位小数百分比。", "可用性语义（AC-3）：阈值与 estimatedFundingOnlyNetIncome/incrementalIncomeVsSimpleEarn 同条件，仅在 blockers 与 unknowns 均为空的既有 else 分支计算，其余分支 Optional.empty 并沿既有阻断项/未知项文案说明原因，不填 0、不猜数；零或非法名义金额复用 PhaseOneAssessmentRequest 既有 signum()<=0 校验在读取事实前拒绝，不新增校验路径。", "生命周期边界（修订）：本设计只新增一次 assess() 调用内的纯派生不可变值，评估保持只读、不创建 analysis_run，无共享可变状态、索引、锁、事务、队列、缓存、外部副作用或补偿，故并发、超时/提供方失败、中断/崩溃、重启/恢复、回滚/冲突均不适用且不因本变更改变；防绕过边界适用且已由测试覆盖——R1 原值断言阻断服务端提前舍入，R2 成对断言阻断用展示值重新决定建议，既有 runnerDependsOnApplicationServiceNotInfrastructureMapper 测试钉住 CLI 仅依赖服务，CLI 对阈值只做 percent() 格式化、绝不重算。", "构造点与消费点核查：全仓库仅 PhaseOneAssessmentService.java:112 构造 PhaseOneAssessment record，CLI 与 DecisionWorkbenchController 只经服务评估并按访问器只读消费，新增组件对 Web 只读路径零影响、无需修改。", "回归边界（AC-4/AC-5）：建议判定仍用完整精度 delta.signum()、首次小额验证上限 5000、成本与未知项语义、退出码与限制提示全部不变；CLI 既有断言基于 contains，追加新行与新子句不破坏现有测试；实现、程序化测试执行、独立验收与交付流程属后续节点，本设计阶段不运行测试。" ],
  "evidence" : [ "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java:23（CALCULATION_CONTEXT=DECIMAL128）、:42-50（simpleEarnIncome/knownCost 既有口径）、:79-101（blockers/unknowns/充分证据三分支，阈值落在 :87-91 的 else 分支与 netIncome/incremental 同时置值）、:92（建议仍由完整精度 delta.signum() 决定）、:112-117（唯一 record 构造点，新增参数只改此处）。", "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java:12-13：新组件 Optional<BigDecimal> breakEvenCumulativeFundingRate 拟插入 incrementalIncomeVsSimpleEarn 之后、evidenceStatus 之前；src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java:38-40 既有 hedgedShortNotional>0 校验。", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java:160-163（净收益/增量“无法精确计算”展示惯例，阈值行沿用同款式置于增量行后）、:183（限制行）、:301-303 money()=setScale(2,HALF_UP)、:305-307 percent()=×100 后 setScale(6,HALF_UP)——±0.000001 增量均显示 0.00 USDT、179.999999 与 180.000001 均显示 180.00 USDT、0.0199999999 与 0.0200000001 的持有收益率均显示 2.000000%，这是 R2 成对测试的展示事实基础。", "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java:130-158 现有 service()/request()/completeCosts()/point() fixture 可扩展出 AC-2 参数构造器（capital 20000、APR 0.0365、名义 10000/3000、成本合计 20）；src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java:77-110 invoke()/completeArguments() 可加可参数化费率的私有重载，均不改生产代码。", "独立验算（测试锚点，均不经服务代码重复计算）：20000×0.0365×90/365=180；(180+20)/10000=0.02 精确终止小数；累计费率 0.019/0.020/0.021 对应资金费收入 190/200/210、净收入 170/180/190、既有增量 -10/0/+10；零已知成本阈值 180/10000=0.018、零 APR 阈值 20/10000=0.002；除不尽场景 200/3000 按 DECIMAL128 为 0.06666666666666666666666666666666667（34 位有效数字、precision=34，末位由后继 6 进位）。", "docs/README.md 现有编号 01–14，新说明沿用惯例为 docs/15-Funding-Rate-Break-Even-Threshold.md；合同依据 .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.md 与 run-1793029770286 的 design-codex-review.json 两项 mustFix。" ],
  "missing_evidence" : [ ],
  "must_fix" : [ ],
  "open_risks" : [ "CLI 边界测试断言“相对简单赚币增量=0.00 USDT”等展示字符串，钉住的是现有 money()/percent() 格式化行为；若未来展示格式调整需同步该断言，语义断言全部在服务测试的原值断言中，不受展示层影响。", "TR-4 完整基线回归含 Testcontainers MySQL，执行阶段需 Docker 可用，并以 Maven Surefire 报告作为程序化通过依据；该验证属后续执行节点，本设计阶段未实现、未运行测试。" ],
  "verification_summary" : "仅设计修订：完成合同、评审意见与代码核对及样例手工验算，未实现代码、未运行测试；两项 mustFix 均已在此替换设计内闭环。",
  "design" : {
    "planned_files" : [ {
      "path" : "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java",
      "responsibility" : "在 incrementalIncomeVsSimpleEarn 之后新增组件 Optional<BigDecimal> breakEvenCumulativeFundingRate，javadoc 明确其为“按 DECIMAL128 计算、未按展示精度进一步舍入的 90 天累计资金费率追平阈值”；仅承载 typed 结果，不引入新校验或逻辑。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java",
      "responsibility" : "在既有无阻断且无未知项的充分证据 else 分支计算 simpleEarnIncome.add(knownCost).divide(request.hedgedShortNotional(), CALCULATION_CONTEXT) 置入新字段，其余分支保持 Optional.empty；建议判定、首次实盘上限、blockers/unknowns 语义完全不变。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java",
      "responsibility" : "在“相对简单赚币增量”行后新增只读展示行“90天累计资金费率阈值=<percent(值)> 或 无法精确计算”，并在限制行追加“阈值是同口径历史追平点，非年化、非预测”子句；只消费 typed 结果不重算，不影响建议与退出码。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java",
      "responsibility" : "TR-1/TR-2 全量测试设计：新增 AC-2 参数 fixture（capital 20000、APR 0.0365、成本合计 20、名义可变）。(a) 独立样例：对照收益 180、阈值原值 isEqualByComparingTo(\"0.02\")，累计费率 0.019/0.020/0.021 断言原值增量 -10/0/+10 与建议 PREFER/PREFER/MICRO_VALIDATE；(b) R1 除不尽：名义 3000，直接断言 record 原值 isEqualByComparingTo 独立写定字面量 0.06666666666666666666666666666666667 且 precision()==34，断言前禁止 setScale、期望值不得用服务公式重算；(c) R2 防绕过：0.0199999999 与 0.0200000001 两评估阈值原值均为 0.02，原始增量分别为 -0.000001/+0.000001，建议分别为 PREFER_SIMPLE_EARN 且 maximumFirstLiveCapital 为空、MICRO_VALIDATE_ARBITRAGE 且含 5000；(d) 零已知成本阈值 0.018、零 APR 阈值 0.002、负资金费率（单点 -0.005）阈值仍可用且建议 PREFER_SIMPLE_EARN；(e) 成本缺失、条款未确认、无历史结算、期末保持开放时阈值为空且沿既有 blockers/unknowns 文案；(f) 零与负名义金额经既有校验在读取事实前抛 IllegalArgumentException。",
      "operation" : "MODIFY"
    }, {
      "path" : "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java",
      "responsibility" : "TR-3 加 R2 展示验证：新增可参数化费率的私有 invoke 重载与 AC-2 参数 completeArguments 变体（capital 20000、APR 0.0365、成本合计 20、名义 10000）。(a) 完整证据单点 0.02：输出固定断言 contains(\"90天累计资金费率阈值=2.000000%\")（不得仅匹配任意六位小数百分比），并含“简单赚币90天收益=180.00 USDT”；(b) R2 成对：0.0199999999 与 0.0200000001 两次输出均含“资金费持有收益率=2.000000%”“90天累计资金费率阈值=2.000000%”“相对简单赚币增量=0.00 USDT”“资金费率净收益=180.00 USDT”，但分别只出现“建议=优先简单赚币”（不含首次实盘上限）与“建议=仅小额验证智能套利”加“首次实盘上限=5000.00 USDT”；(c) 证据不足（缺退出/滑点成本）：输出含“90天累计资金费率阈值=无法精确计算”且不打印阈值数值；(d) 既有四项测试断言全部保留不回归，六位小数展示断言只存在于本 CLI 测试。",
      "operation" : "MODIFY"
    }, {
      "path" : "docs/15-Funding-Rate-Break-Even-Threshold.md",
      "responsibility" : "简体中文使用说明：定义与公式（阈值 =(对照收益+完整已知成本)/对冲名义，是整个 90 天累计费率、非 APR、不按结算间隔换算）；AC-2 样例与 0.019/0.020/0.021 边界表；精度表述按 R1 修正为“按 DECIMAL128（34 位有效数字）计算、未按展示精度进一步舍入的值，CLI 展示层才做 ×100 后 setScale(6,HALF_UP)”；加入 R2 例子说明 0.0199999999/0.0200000001 展示相同但建议不同、不得用舍入后的 CLI 数字重新决定建议；可用与不可用条件、历史情景限制（非预测、非建议、区间完整性未证明），并指向 docs/09 测试手册。",
      "operation" : "CREATE"
    } ]
  },
  "stage_outcome" : "READY",
  "stage_outcome_source" : "declared_status",
  "evidence_state" : {
    "blocking" : false,
    "evidence_count" : 6,
    "missing_evidence_count" : 0,
    "must_fix_count" : 0,
    "acceptance_note_count" : 0,
    "open_risk_count" : 2
  },
  "authored_context" : {
    "sha256" : "ad018819314f97c39aa94398900858656529b75f32fe0972fb3511ea33a02eea",
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/prompts/design-claude.md.manifest.json"
  }
}


## Revision parent

.agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030521008/outputs/plan-claude.contract.json

{
  "artifact_type" : "agent_output_contract",
  "schema_version" : 1,
  "workstream_id" : "ws-20261026T142203Z-7SNA",
  "run_id" : "run-1793030521008",
  "node_id" : "plan.claude_plan",
  "node_instance_id" : "node-plan-claude_plan-017",
  "handler_type" : "acpx.agent_run",
  "decision" : "READY_FOR_PLAN_REVIEW",
  "summary" : "已将复审通过的设计转为六文件实现计划：服务计算追平阈值、record 承载、CLI 只读展示、两份测试与一份中文说明，程序化验证交由自测节点执行。",
  "required_keys" : [ "decision", "summary" ],
  "allowed_decisions" : [ "READY_FOR_PLAN_REVIEW" ],
  "source_output_ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030521008/outputs/plan-claude.json",
  "source_artifact_type" : "plan_result",
  "generated_at" : "2026-10-26T16:07:19.878309Z",
  "control" : {
    "decision" : "READY_FOR_PLAN_REVIEW",
    "summary" : "已将复审通过的设计转为六文件实现计划：服务计算追平阈值、record 承载、CLI 只读展示、两份测试与一份中文说明，程序化验证交由自测节点执行。"
  },
  "control_source" : {
    "kind" : "strict_agent_result_envelope"
  },
  "revision_responses" : [ ],
  "lifecycle_status" : "READY",
  "blocking" : false,
  "checks" : [ "已读取经评审通过的设计（run-1793029979831 design-claude.contract.json，decision=READY_FOR_ARCH_REVIEW）与 Codex 复审（run-1793030419328，mustFix 为空），R1/R2 修订均已纳入计划。", "已核对任务合同 node-contract-compile-007 的 AC-1 至 AC-5、TR-1 至 TR-4、范围排除与约束，计划未超出批准目标与排除清单。", "已复核生产代码事实：PhaseOneAssessmentService.java:23（CALCULATION_CONTEXT=DECIMAL128）、:42-50（simpleEarnIncome/knownCost 既有分子口径）、:79-101（blockers/unknowns/充分证据三分支，阈值落在 else 分支与 netIncome/incremental 同条件）、:92（建议仍由 delta.signum() 决定）、:112-117（record 构造点）；grep 全仓库 new PhaseOneAssessment( 仅 :112 一处，CLI 与 DecisionWorkbenchController 均按访问器只读消费。", "已核对 PhaseOneAssessment.java:7-21 组件顺序（新字段插入 incrementalIncomeVsSimpleEarn 与 evidenceStatus 之间）与 PhaseOneAssessmentRequest.java:38-40 既有 hedgedShortNotional>0 校验。", "已核对 CLI 事实：AssessIncomeCliRunner.java:160-163（净收益/增量与“无法精确计算”展示惯例）、:183（限制行）、:301-307（money()=setScale(2,HALF_UP)、percent()=×100 后 setScale(6,HALF_UP)），支撑 R2 成对展示断言。", "已核对两份测试既有 fixture 与断言（PhaseOneAssessmentServiceTest.java:130-158、AssessIncomeCliRunnerTest.java:77-110），新增场景可在不改其他生产代码的前提下扩展。", "已核对 docs/README.md 现有文档编号 01 至 14，新说明沿用编号 15，不改 README 本身。", "手工独立验算锚点（不经服务代码重复计算）：20000×0.0365×90÷365=180；(180+20)÷10000=0.02；累计费率 0.019/0.020/0.021 对应增量 -10/0/+10；零已知成本阈值 0.018、零 APR 阈值 0.002；200÷3000 按 DECIMAL128 为 34 位有效数字 0.06666666666666666666666666666666667。" ],
  "evidence" : [ ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/outputs/design-claude.contract.json：design.planned_files 六文件与 R1/R2 修订为本计划直接输入。", ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/outputs/design-codex-review.json：stageOutcome=READY、mustFix=[]，设计已获复审通过。", ".agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.md：AC-1 至 AC-5、TR-1 至 TR-4 与范围约束。", "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java:23,42-50,79-101,112-117", "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java:7-21", "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java:38-40", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java:145-184,301-307", "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java:29-158", "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java:20-110", "docs/README.md:36-51（文档编号 01–14 清单）" ],
  "missing_evidence" : [ ],
  "must_fix" : [ ],
  "acceptance_notes" : [ "本产物仅是规划：未实现代码、未创建或修改任何项目文件、未运行任何构建或测试命令；六文件清单为提案，精确写操作仍需 EXECUTION 合同批准。", "record 新增组件会改变构造签名；已 grep 确认全仓库唯一构造点为 PhaseOneAssessmentService.java:112，其余消费方均为访问器只读，执行阶段仍以 mvn test 全量编译验证无遗漏。", "AC-5 的交付门（独立验收、交付批准、精确候选应用、人工或另行明确委派的 commit、原 finalize）不属于本计划与自测节点，测试通过不等于完整 E2E 完成。" ],
  "open_risks" : [ "TR-4 完整基线回归依赖 Docker 可用（Testcontainers 启动 MySQL 8.4）；执行环境缺失时须补齐后重跑，不得降级为跳过或部分回归。", "CLI 成对测试断言钉住现有 money()/percent() 展示字符串，未来展示格式调整需同步维护该断言；阈值语义断言集中在服务测试原值断言，不受展示层影响。" ],
  "changed_files" : [ ],
  "verification_summary" : "规划阶段仅完成设计、合同与源码事实核对及计划编排；实现与验证（mvn 测试、Surefire 报告收集）由后续执行与自测节点程序化完成。",
  "failure" : {
    "category_hint" : "",
    "verification_remediation" : "NONE",
    "contract_gaps" : [ ],
    "out_of_scope_files" : [ ],
    "missing_tests" : [ ],
    "context_gaps" : [ ],
    "reason" : ""
  },
  "checks_run" : [ ],
  "checks_skipped" : [ ],
  "plan_artifact" : {
    "artifact_type" : "plan_artifact",
    "schema_version" : 2,
    "implementation_steps" : [ "确认工作区位于固定隔离基线 codex/w09-okx-break-even-20261026 @ 7c5facc 且状态干净；发现需改动范围外文件（迁移、采集、Web、组合策略、Dual 等）立即停止并上报，不扩大实现。", "修改 PhaseOneAssessment record：在 incrementalIncomeVsSimpleEarn 之后、evidenceStatus 之前新增组件 Optional<BigDecimal> breakEvenCumulativeFundingRate，javadoc 说明其为“按 DECIMAL128 计算且未按展示精度进一步舍入的 90 天累计资金费率追平阈值”；仅承载 typed 结果，不新增校验或逻辑。", "修改 PhaseOneAssessmentService：在既有无阻断且无未知项的充分证据 else 分支，用 simpleEarnIncome.add(knownCost).divide(request.hedgedShortNotional(), CALCULATION_CONTEXT) 计算阈值并置入新字段，其余分支保持 Optional.empty；在唯一构造点 :112-117 传入新参数；建议判定 delta.signum()、MAXIMUM_FIRST_LIVE_CAPITAL=5000、blockers/unknowns/reasons/checklist 语义完全不变。", "修改 AssessIncomeCliRunner：在“相对简单赚币增量”行后新增只读展示行“90天累计资金费率阈值=<percent 格式化值> 或 无法精确计算”，形态与既有净收益/增量的 map(...).orElse(“无法精确计算”) 惯例一致，只消费 typed 结果不重算；限制行追加“阈值是同口径历史追平点，非年化、非预测”子句；不影响建议与退出码。", "扩展 PhaseOneAssessmentServiceTest：新增 AC-2 参数 fixture（capital 20000、APR 0.0365、期限 90 天、成本合计 20、名义可变）并添加测试：(a) 独立样例对照收益 180、阈值原值 isEqualByComparingTo 0.02，累计费率 0.019/0.020/0.021 对应原值增量 -10/0/+10 与建议 PREFER_SIMPLE_EARN/PREFER_SIMPLE_EARN/MICRO_VALIDATE_ARBITRAGE；(b) 除不尽场景（分子 200、名义 3000）直接断言独立写定字面量 0.06666666666666666666666666666666667 且 precision()==34，断言前禁止 setScale、期望值不得用服务公式重算；(c) 成对防绕过：0.0199999999 与 0.0200000001 阈值均为 0.02，原始增量分别为 -0.000001/+0.000001，建议分别为 PREFER_SIMPLE_EARN 且 maximumFirstLiveCapital 为空、MICRO_VALIDATE_ARBITRAGE 且含 5000；(d) 零已知成本阈值 0.018、零 APR 阈值 0.002、负资金费率单点 -0.005 阈值可用且建议 PREFER_SIMPLE_EARN；(e) 成本缺失、条款未确认、无历史结算、期末保持开放时阈值为空且沿既有 blockers/unknowns 文案；(f) 零与负名义金额沿 PhaseOneAssessmentRequest 既有校验在读取事实前抛 IllegalArgumentException（事实查询以 AssertionError 证明未被读取）。", "扩展 AssessIncomeCliRunnerTest：新增可参数化累计费率的私有 invoke 重载与 AC-2 参数 completeArguments 变体（capital 20000、APR 0.0365、成本合计 20、名义 10000）：(a) 完整证据单点 0.02 固定断言 contains 90天累计资金费率阈值=2.000000% 且含 简单赚币90天收益=180.00 USDT；(b) 成对 0.0199999999/0.0200000001 两次输出均含 资金费持有收益率=2.000000%、90天累计资金费率阈值=2.000000%、相对简单赚币增量=0.00 USDT、资金费率净收益=180.00 USDT，且分别只出现 建议=优先简单赚币（不含首次实盘上限）与 建议=仅小额验证智能套利 加 首次实盘上限=5000.00 USDT；(c) 证据不足（缺退出与滑点成本）时输出含 90天累计资金费率阈值=无法精确计算 且不打印阈值数值；(d) 既有四项测试断言原样保留。", "创建 docs/15-Funding-Rate-Break-Even-Threshold.md（简体中文）：定义与公式（阈值=(对照收益+完整已知成本)/对冲名义，是整个 90 天累计费率、非 APR、不按结算次数或假定 8 小时间隔换算）；AC-2 样例与 0.019/0.020/0.021 边界表；精度表述按 R1 为“按 DECIMAL128（34 位有效数字）计算、未按展示精度进一步舍入，CLI 展示层才 ×100 后 setScale(6,HALF_UP)”；加入 0.0199999999/0.0200000001 展示相同但建议不同的例子并说明不得用舍入后的 CLI 数字重新决定建议；可用与不可用条件、历史情景限制（非预测、非建议、区间完整性未证明），并指向 docs/09 测试手册。", "自查 git diff 严格限于六文件后停止编码，交由自测节点按 validation_plan 程序化执行并收集 Surefire 报告证据；任何测试失败按既有修复-重跑流程处理，不在本计划外扩文件。" ],
    "edit_files" : [ "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java", "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java", "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java", "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java", "docs/15-Funding-Rate-Break-Even-Threshold.md" ],
    "files" : [ {
      "path" : "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java",
      "operation" : "MODIFY"
    }, {
      "path" : "docs/15-Funding-Rate-Break-Even-Threshold.md",
      "operation" : "CREATE"
    } ],
    "verification_bindings" : [ {
      "criterion_id" : "TR-1",
      "method" : "在固定隔离基线 codex/w09-okx-break-even-20261026 @ 7c5facc（JDK 25 + Maven 3.9）运行 mvn test -Dtest=PhaseOneAssessmentServiceTest，退出码必须为 0；以 target/surefire-reports 的 XML/txt 报告为程序依据，核对新阈值单元测试通过：AC-2 样例对照收益 180、阈值原值 isEqualByComparingTo 0.02；累计费率 0.019/0.020/0.021 对应原值增量 -10/0/+10 与建议 PREFER_SIMPLE_EARN/PREFER_SIMPLE_EARN/MICRO_VALIDATE_ARBITRAGE；除不尽场景（分子 200、名义 3000）直接断言独立写定字面量 0.06666666666666666666666666666666667 且 precision()==34，断言前无 setScale；零已知成本阈值 0.018、零 APR 阈值 0.002、负资金费率场景（证明 AC-1/AC-2）。",
      "executor" : "AGENT",
      "environment_refs" : [ ],
      "authority_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
        "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
      } ],
      "evidence_kind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
      "feasibility_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/prompts/design-claude.md.manifest.json",
        "sha256" : "ad018819314f97c39aa94398900858656529b75f32fe0972fb3511ea33a02eea"
      } ],
      "detail_owner" : "implement.claude_self_test_report",
      "actual_exit_required" : true,
      "expected_exit_code" : 0
    }, {
      "criterion_id" : "TR-2",
      "method" : "同一命令 mvn test -Dtest=PhaseOneAssessmentServiceTest，退出码必须为 0；核对不可用与校验测试通过：成本缺失（退出/滑点未知）、简单赚币条款未确认、窗口内无历史结算、期末保持策略开放四种情况下 breakEvenCumulativeFundingRate 为空且原因沿既有 blockers/unknowns 输出；零与负 hedgedShortNotional 在读取事实前被既有 PhaseOneAssessmentRequest 校验抛出 IllegalArgumentException（事实查询以 AssertionError 证明未读取）（证明 AC-3）。",
      "executor" : "AGENT",
      "environment_refs" : [ ],
      "authority_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
        "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
      } ],
      "evidence_kind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
      "feasibility_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/prompts/design-claude.md.manifest.json",
        "sha256" : "ad018819314f97c39aa94398900858656529b75f32fe0972fb3511ea33a02eea"
      } ],
      "detail_owner" : "implement.claude_self_test_report",
      "actual_exit_required" : true,
      "expected_exit_code" : 0
    }, {
      "criterion_id" : "TR-3",
      "method" : "运行 mvn test -Dtest=AssessIncomeCliRunnerTest，退出码必须为 0；以 target/surefire-reports 报告为程序依据，核对展示测试通过：完整证据单点 0.02 时输出固定包含 90天累计资金费率阈值=2.000000% 与 简单赚币90天收益=180.00 USDT；成对 0.0199999999/0.0200000001 两次输出的持有收益率、阈值、增量、净收益展示完全相同，但分别只出现 建议=优先简单赚币（不含首次实盘上限）与 建议=仅小额验证智能套利 加 首次实盘上限=5000.00 USDT；证据不足时输出 90天累计资金费率阈值=无法精确计算 且不打印阈值数值；既有四项测试断言不回归（证明 AC-2 防绕过与 AC-4 展示）。",
      "executor" : "AGENT",
      "environment_refs" : [ ],
      "authority_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
        "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
      } ],
      "evidence_kind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
      "feasibility_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/prompts/design-claude.md.manifest.json",
        "sha256" : "ad018819314f97c39aa94398900858656529b75f32fe0972fb3511ea33a02eea"
      } ],
      "detail_owner" : "implement.claude_self_test_report",
      "actual_exit_required" : true,
      "expected_exit_code" : 0
    }, {
      "criterion_id" : "TR-4",
      "method" : "在 Docker 可用（Testcontainers MySQL 8.4）环境下运行 mvn test 完整基线回归，退出码必须为 0；以 target/surefire-reports 完整报告作为 Gate 要求的完整基线通过事实保留，证明新增改动未破坏既有非容器回归与容器回归（AC-5 回归部分）；交付门后续步骤（独立验收、交付批准、精确候选应用、人工或明确委派 commit、原 finalize）不因测试通过而视为完成。",
      "executor" : "AGENT",
      "environment_refs" : [ ],
      "authority_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
        "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
      } ],
      "evidence_kind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
      "feasibility_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/prompts/design-claude.md.manifest.json",
        "sha256" : "ad018819314f97c39aa94398900858656529b75f32fe0972fb3511ea33a02eea"
      } ],
      "detail_owner" : "implement.claude_self_test_report",
      "actual_exit_required" : true,
      "expected_exit_code" : 0
    } ],
    "authority_refs" : [ {
      "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
      "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
    } ],
    "reference_files" : [ "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java", "src/main/java/app/cryptoincome/assessment/domain/SmartArbitrageCosts.java", "docs/09-Phase-1-Test-Runbook.md", "docs/README.md", "pom.xml" ],
    "file_level_changes" : [ "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java: 新增组件 Optional<BigDecimal> breakEvenCumulativeFundingRate（置于 incrementalIncomeVsSimpleEarn 与 evidenceStatus 之间）及 javadoc，其余组件与紧凑构造器不变。", "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java: 充分证据 else 分支新增 (simpleEarnIncome+knownCost)÷hedgedShortNotional 的 DECIMAL128 除法并置入新字段，其余分支 Optional.empty；唯一构造点 :112-117 同步传参。", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java: 增量行后新增阈值只读展示行（percent() 格式化或无法精确计算），限制行追加非年化/非预测子句；不重算、不改建议与退出码。", "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java: 新增 AC-2 参数 fixture 与 (a)–(f) 阈值测试（原值与 precision 断言、成对防绕过、零成本/零 APR/负费率、四类不可用、非法名义校验）。", "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java: 新增可参数化费率 invoke 重载与 AC-2 参数变体，覆盖固定阈值行断言、成对展示相同但建议不同、不可用展示；既有四项测试保留。", "docs/15-Funding-Rate-Break-Even-Threshold.md: 新建简体中文使用说明（定义公式、样例与边界表、精度口径、防误用例子、可用条件与限制、指向 docs/09）。" ],
    "validation_plan" : [ "mvn test -Dtest=PhaseOneAssessmentServiceTest —— 覆盖 TR-1/TR-2（含 AC-1/AC-2/AC-3 数值与不可用断言），退出码必须为 0。", "mvn test -Dtest=AssessIncomeCliRunnerTest —— 覆盖 TR-3（含 AC-4 展示断言），退出码必须为 0。", "mvn test —— 完整基线回归（含 Testcontainers MySQL，需 Docker 可用），覆盖 TR-4 与 AC-5 的回归要求，退出码必须为 0。", "以 target/surefire-reports 下 XML/txt 报告为程序化通过依据，核对新增测试方法全部执行且失败数为 0；不得仅以模型“已通过”正文作数。", "git status/diff 自查改动严格限于六文件，无范围外路径；确认未修改 README、迁移、采集、Web 与组合策略。" ],
    "rollback_notes" : "全部改动位于固定隔离基线 codex/w09-okx-break-even-20261026（commit 7c5facc）之上的六文件内：回滚时对五个修改文件执行 git restore 恢复到基线版本并删除新建的 docs/15-Funding-Rate-Break-Even-Threshold.md 即可；无数据库迁移、无运行状态、无外部副作用需要补偿。",
    "known_risks" : [ "TR-4 完整基线回归需要 Docker 可用（Testcontainers 启动 MySQL 8.4）；环境不可用时须补齐后重跑，不得降级为部分回归或以跳过作数。", "CLI 成对测试断言钉住现有 money()/percent() 展示字符串，未来展示格式调整需同步维护；阈值语义断言集中在服务测试原值断言，不受展示层影响。", "record 构造签名变化：已 grep 确认唯一构造点 PhaseOneAssessmentService.java:112，执行阶段仍以 mvn test 全量编译验证无遗漏调用点。" ],
    "human_review_checklist" : [ "阈值仅由 PhaseOneAssessmentService 计算、PhaseOneAssessment 承载、CLI 只读消费，CLI 无任何重算逻辑。", "分子=simpleEarnIncome+knownCost（knownTotal 既有口径，不重复计费），分母=hedgedShortNotional，除法显式使用 CALCULATION_CONTEXT（DECIMAL128）。", "结果保持整个 90 天累计资金费率口径，无 APR 化、无按结算次数或假定 8 小时间隔换算。", "四类证据不足场景阈值为 Optional.empty 且沿既有 blockers/unknowns 原因；零/负名义金额走既有请求校验，不新增校验路径。", "既有建议判定（delta.signum()）、首次实盘上限 5000 USDT、退出码、成本与限制语义不变。", "服务测试含独立字面量原值断言（0.02、0.06666666666666666666666666666666667、precision()==34）与成对防绕过测试；CLI 测试固定断言 2.000000% 且六位小数展示断言只存在于 CLI 测试。", "改动严格限于六文件；docs/15 为简体中文并包含样例与限制说明。", "测试通过必须以 Surefire 报告等程序工具依据为准。" ]
  },
  "stage_outcome" : "READY",
  "stage_outcome_source" : "declared_status",
  "evidence_state" : {
    "blocking" : false,
    "evidence_count" : 10,
    "missing_evidence_count" : 0,
    "must_fix_count" : 0,
    "acceptance_note_count" : 3,
    "open_risk_count" : 2
  },
  "authored_context" : {
    "sha256" : "5fbd748059a097370196207c4248ecf8302b7777991408c9f074569d2a4be80a",
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030521008/prompts/plan-claude.md.manifest.json"
  }
}


## Active obligations

[ {
  "id" : "sha256:002e3dfc1f4d8f57f86babd52ae3d9aa609ab4def6224c54b257a57dc470703a#human-note:0",
  "source" : {
    "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/gates/gate-node-gate-human_plan_approval-021.json",
    "sha256" : "002e3dfc1f4d8f57f86babd52ae3d9aa609ab4def6224c54b257a57dc470703a"
  },
  "text" : "用户已批准本次计划返修。保持已通过复评的六文件设计/范围、全部GOAL验收、DECIMAL128独立原值和展示不影响建议的成对测试，不改GOAL、不写实现代码。\n当前计划未能进入EXECUTION的三个具体接线缺项必须修正：\n1. verification_bindings 应对GOAL acceptance_criteria AC-1、AC-2、AC-3、AC-4、AC-5逐项且全量绑定；TR-1..TR-4是测试要求，不能代替AC编号。\n2. 原operator已用review record-readiness正式登记材料：ref=.agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/verification-readiness/okx-ac-availability-20261027-01.json；sha256=1212daf7ab19146a19336a41ac32668c60a31d76f48a6bf0292d361006129d08。将此真实ref/SHA用于environment_refs和feasibility_refs，精确消费下列声明method、executor、evidence_kind、detail_owner。提示词manifest不能作为环境/可行性事实。不得伪造别的引用。\nmethod=在本隔离工作树使用 JDK 25 与现有 Maven 执行 mvn -o clean test，依据本次源码对应的 Surefire XML/日志及程序工具观察核验服务、CLI 和全部 MySQL/Testcontainers 回归；按 AC-1..AC-5 分别关联独立样例、DECIMAL128 原值、显示舍入不改变建议、不可用情形、既有行为与中文说明的断言。通过程序工具读取实际变更和说明进行逐条语义检查。既有宿主166项基线仅作环境材料，不代替本次源码测试；原生状态、reported exit 和 actual exit 如实区分，任何未经原生程序观察提供的实际退出码不由模型或声明补造。\nexecutor=AGENT\nevidence_kind=PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS\ndetail_owner=implement.claude_self_test_report\n3. GOAL要求真实程序工具观察+本次源码对应的Surefire报告，不统一强制底层actual_exit字段。现有计划四条actual_exit_required=true/expected_exit_code=0超出了已获批标准，且本案当前未证明该接口路径提供actual exit。按GOAL消除这一统一附加要求，保持具体测试确实通过与产品CLI退出语义不回归；actual/reported/status如实区分，不造process exit。若确有明确实际退出码要求必须保持并具名证明来源，不能靠声明替代测量。\n你正在修订计划；修正材料应再经原另一客户端独立复评，不自批EXECUTION。\n"
} ]
