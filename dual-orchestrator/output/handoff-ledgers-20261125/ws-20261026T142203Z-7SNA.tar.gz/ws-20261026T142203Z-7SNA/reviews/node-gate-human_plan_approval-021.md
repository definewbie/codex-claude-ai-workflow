# Human Review Packet

- Workstream: ws-20261026T142203Z-7SNA
- Gate: gate.human_plan_approval
- Gate Instance: node-gate-human_plan_approval-021
- Stage: stage-gate
- Iteration: iter-002
- Source Outcome: VERIFICATION_READINESS_REQUIRED
- Allowed Actions: approve, revise

## Operator Guidance

- Recommended Action: approve
- Reason: The latest agent decision is positive. Approve only after checking the packet evidence.
- Suggested Checks:
  - Confirm the TaskContract objective, scope, non-goals, and acceptance criteria still match the task.
  - Check whether the design or plan stays inside scope and avoids unnecessary implementation detail.

## Review Focus

- Read the complete referenced design and review sidecars before approving; the packet summary is not a substitute.
- Use `approve` only when the current gate is good enough to continue.
- Use `revise` when the agent should address concrete feedback first.

## Review Summary

- Objective: 在既有 Java 项目 assess-income phase-one 的 90 天历史情景评估中新增可解释指标：在相同 90 天窗口、投入资金、对冲空头名义金额和固定已知成本口径下，资金费净收入追平简单赚币所需的整个 90 天累计资金费率阈值，由 PhaseOneAssessmentService 计算、PhaseOneAssessment record 承载、CLI 只读展示，并保留证据不足时的不可用语义。
- Stage Outcome: READY
- Latest Decision: READY_TO_IMPLEMENT
- Latest Summary: 六文件计划与已复审设计一致，实施步骤、测试断言及验证责任明确，可进入精确 EXECUTION 范围审批。
- Blocking: false

## Task Contract

- Objective: 在既有 Java 项目 assess-income phase-one 的 90 天历史情景评估中新增可解释指标：在相同 90 天窗口、投入资金、对冲空头名义金额和固定已知成本口径下，资金费净收入追平简单赚币所需的整个 90 天累计资金费率阈值，由 PhaseOneAssessmentService 计算、PhaseOneAssessment record 承载、CLI 只读展示，并保留证据不足时的不可用语义。
- Status: READY_FOR_REVIEW
- Excluded Scope:
  - 不修改交易/账户、采集（sync-market/sync-product）、数据库迁移、持仓、调度、组合策略、Web 页面、Dual 生产代码或客户端配置
  - 不接入任何新外部服务，不做未来费率预测或交易建议
  - 不做整个项目的公式重构，不新增平台、规则 DSL 或兼容机制
- Acceptance Criteria:
  - Clause[id=AC-1, text=计算口径：阈值 =（既有简单赚币 90 天收入 + 同口径完整已知成本）/ 对冲空头名义金额；该值是整个 90 天窗口的累计资金费率，不是 APR，不得按每次结算或假定 8 小时间隔换算；成本沿用 SmartArbitrageCosts.knownTotal() 既有口径，不重复计费；计算使用 BigDecimal 且精度规则明确（与既有服务的 DECIMAL128 计算上下文一致，除法精度显式声明）。]
  - Clause[id=AC-2, text=独立样例与边界：共同资金 20,000 USDT、简单赚币 APR 0.0365、90 天、完整成本 20 USDT、对冲名义 10,000 USDT 时，对照收益为 180 USDT、阈值为 0.02（2%）；累计费率分别为 0.019、0.020、0.021 时，现有同口径增量分别为 -10、0、10 USDT；测试同时覆盖零已知成本、零 APR、负资金费率以及不能整除的精度场景；不得用舍入后的 CLI 数字重新决定现有建议。]
  - Clause[id=AC-3, text=证据不足：只在现有评估允许同口径精确净收入比较时提供数值；成本缺失、简单赚币条款未确认、窗口内无历史结算或期末保持策略开放时数值不可用，并沿既有阻断项/未知项说明原因，不得填 0、猜数或给出可行动的精确阈值；非法或零名义金额沿 PhaseOneAssessmentRequest 既有输入校验拒绝（hedgedShortNotional 必须大于 0）。]
  - Clause[id=AC-4, text=唯一生产与展示：现有评估服务产生 typed 结果（阈值作为 PhaseOneAssessment 的字段），CLI 只消费该结果，清楚标注“90 天累计资金费率阈值”及不可用情况，不自行重算；补充一份简明中文使用说明，包含上述样例和限制；既有建议、首次小额验证上限（5,000 USDT）、成本和风险语义不变。]
  - Clause[id=AC-5, text=回归与交付：在固定隔离基线（当前分支 codex/w09-okx-break-even-20261026 @ 7c5facc）上实现；相关服务/CLI 测试、既有非容器回归和 Gate 要求的完整基线回归保留并通过，执行测试有程序工具观察和报告依据（如 Maven Surefire 报告），不能只以模型“已通过”正文作数；独立验收完成后，仍需当前交付批准、精确候选应用、人工或另行明确委派的 commit、原 finalize，才能称完整 E2E 完成。]
- Test Requirements:
  - Clause[id=TR-1, text=PhaseOneAssessmentServiceTest 增加阈值单元测试：验证 AC-2 样例（对照收益 180 USDT、阈值 0.02）与累计费率 0.019/0.020/0.021 对应既有同口径增量 -10/0/+10 USDT，并覆盖零已知成本、零 APR、负资金费率和除不尽的精度场景；断言基于 BigDecimal 原值而非 CLI 舍入输出。]
  - Clause[id=TR-2, text=PhaseOneAssessmentServiceTest 增加不可用与校验测试：成本缺失、条款未确认、无历史结算、期末保持策略开放时阈值为空且原因沿既有 blockers/unknowns 输出；非法或零对冲名义金额在读取事实前被既有请求校验拒绝。]
  - Clause[id=TR-3, text=AssessIncomeCliRunnerTest 增加展示测试：完整证据时输出含“90 天累计资金费率阈值”标签及数值，证据不足时输出不可用说明且不打印数值；既有建议文案、首次实盘上限、退出码与限制提示不回归。]
  - Clause[id=TR-4, text=在固定隔离基线上运行既有非容器回归和 Gate 要求的完整基线回归（mvn 测试），以 Maven/Surefire 等程序工具生成的报告作为通过依据，并保留完整基线通过事实。]
- Constraints:
  - 继续使用现有 Java、BigDecimal、PhaseOneAssessmentService 评估服务和 assess-income CLI，不接入任何新外部服务或数据源。
  - 阈值是整个 90 天窗口的累计资金费率，禁止换算成 APR 或按每次结算/假定 8 小时间隔折算；资金费间隔遵循实际 fundingTime。
  - 成本口径沿用 SmartArbitrageCosts.knownTotal() 既有实现，不重复计费、不改变未知成本按 UNKNOWN 处理的语义；阈值的可用条件与既有增量比较的可用条件一致。
  - 单一生产来源：阈值只在 PhaseOneAssessmentService 内计算并作为 typed 字段返回；CLI 是薄适配层，只打印该结果，不重算、不用舍入值影响建议。
  - 资金费事实表、数据库迁移、同步/回补、组合策略与 Web 输出保持不动（只读）；新增说明文档为中文，沿用 docs 目录编号惯例。
  - 精度规则显式：服务层计算与既有 CALCULATION_CONTEXT（MathContext.DECIMAL128）一致且除法上下文明确，展示层沿用 CLI 既有格式化惯例并标注为累计费率而非年化。
- Nonessential Operation Declarations:
  - None

## Requirement Resolution

- Decision: APPROVE
- Approved By: human_gate
- Gate Ref: .agent/workstreams/ws-20261026T142203Z-7SNA/gates/gate-node-gate-human_requirement_review-006.json
- Assumptions:
  - Human approved the requirement review gate before canonical contract generation.

## Latest Agent Decision

- Node: plan.codex_plan_review
- Stage Outcome: READY
- Decision: READY_TO_IMPLEMENT
- Summary: 六文件计划与已复审设计一致，实施步骤、测试断言及验证责任明确，可进入精确 EXECUTION 范围审批。
- Blocking: false
- Verification: 已基于完整 typed 计划、已复审设计及此前核验的合同事实完成只读审查；未修改文件、未运行构建或测试，未确认执行环境就绪。
- Evidence State: {blocking=false, evidence_count=4, missing_evidence_count=0, must_fix_count=0, acceptance_note_count=5, open_risk_count=0}
- Contract Sidecar: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.contract.json

## Authored Candidate And Revision History

Historical obligations remain active until approval. Responses are claims, not verified closure. New must-fix items were raised after this candidate and enter its next revision.

```json
{
  "candidate" : {
    "sidecar" : {
      "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030521008/outputs/plan-claude.contract.json",
      "sha256" : "517db5e9c27a95ff65e8d55ef666e4659b4de6c10f706abaa53aa1c1c4b5e46f"
    },
    "nodeInstanceId" : "node-plan-claude_plan-017",
    "nodeId" : "plan.claude_plan",
    "runId" : "run-1793030521008",
    "artifactType" : "plan_result"
  },
  "contract" : {
    "compileNodeInstanceId" : "node-contract-compile-007",
    "approvalGateRef" : ".agent/workstreams/ws-20261026T142203Z-7SNA/gates/gate-node-gate-human_requirement_review-006.json",
    "approvalEventId" : "evt-000007",
    "contract" : {
      "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/task-contract.json",
      "sha256" : "41f643f07f822573dfa2a13e8f5ede75aa2efd83fdca3efa20130ca0ae2bf04f"
    },
    "resolution" : {
      "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/contracts/node-contract-compile-007/contract-resolution.json",
      "sha256" : "4ea85c7039fe75749f8a59f300b60930ec86a3419024e8257f03fe14255fd482"
    }
  },
  "reviewedDesign" : {
    "decision" : {
      "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/nodes/node-design-decision-016.json",
      "sha256" : "d73b265eb1005708fef4525685eae21a04b86194dccce023df99a47427eb08db"
    },
    "eventId" : "evt-000017",
    "candidate" : {
      "sidecar" : {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/outputs/design-claude.contract.json",
        "sha256" : "2c20a9e9f7c590f0fc105dff400b165756d369728b58ffeee4d02c9ffecaa3b8"
      },
      "nodeInstanceId" : "node-design-claude_design-012",
      "nodeId" : "design.claude_design",
      "runId" : "run-1793029979831",
      "artifactType" : "design_result"
    }
  },
  "activeObligations" : [ ],
  "revisionResponses" : [ ],
  "plannedFiles" : null,
  "plan" : {
    "artifact_type" : "plan_artifact",
    "schema_version" : 2,
    "implementation_steps" : [ "确认工作区位于固定隔离基线 codex/w09-okx-break-even-20261026 @ 7c5facc 且状态干净；发现需改动范围外文件（迁移、采集、Web、组合策略、Dual 等）立即停止并上报，不扩大实现。", "修改 PhaseOneAssessment record：在 incrementalIncomeVsSimpleEarn 之后、evidenceStatus 之前新增组件 Optional<BigDecimal> breakEvenCumulativeFundingRate，javadoc 说明其为“按 DECIMAL128 计算且未按展示精度进一步舍入的 90 天累计资金费率追平阈值”；仅承载 typed 结果，不新增校验或逻辑。", "修改 PhaseOneAssessmentService：在既有无阻断且无未知项的充分证据 else 分支，用 simpleEarnIncome.add(knownCost).divide(request.hedgedShortNotional(), CALCULATION_CONTEXT) 计算阈值并置入新字段，其余分支保持 Optional.empty；在唯一构造点 :112-117 传入新参数；建议判定 delta.signum()、MAXIMUM_FIRST_LIVE_CAPITAL=5000、blockers/unknowns/reasons/checklist 语义完全不变。", "修改 AssessIncomeCliRunner：在“相对简单赚币增量”行后新增只读展示行“90天累计资金费率阈值=<percent 格式化值> 或 无法精确计算”，形态与既有净收益/增量的 map(...).orElse(“无法精确计算”) 惯例一致，只消费 typed 结果不重算；限制行追加“阈值是同口径历史追平点，非年化、非预测”子句；不影响建议与退出码。", "扩展 PhaseOneAssessmentServiceTest：新增 AC-2 参数 fixture（capital 20000、APR 0.0365、期限 90 天、成本合计 20、名义可变）并添加测试：(a) 独立样例对照收益 180、阈值原值 isEqualByComparingTo 0.02，累计费率 0.019/0.020/0.021 对应原值增量 -10/0/+10 与建议 PREFER_SIMPLE_EARN/PREFER_SIMPLE_EARN/MICRO_VALIDATE_ARBITRAGE；(b) 除不尽场景（分子 200、名义 3000）直接断言独立写定字面量 0.06666666666666666666666666666666667 且 precision()==34，断言前禁止 setScale、期望值不得用服务公式重算；(c) 成对防绕过：0.0199999999 与 0.0200000001 阈值均为 0.02，原始增量分别为 -0.000001/+0.000001，建议分别为 PREFER_SIMPLE_EARN 且 maximumFirstLiveCapital 为空、MICRO_VALIDATE_ARBITRAGE 且含 5000；(d) 零已知成本阈值 0.018、零 APR 阈值 0.002、负资金费率单点 -0.005 阈值可用且建议 PREFER_SIMPLE_EARN；(e) 成本缺失、条款未确认、无历史结算、期末保持开放时阈值为空且沿既有 blockers/unknowns 文案；(f) 零与负名义金额沿 PhaseOneAssessmentRequest 既有校验在读取事实前抛 IllegalArgumentException（事实查询以 AssertionError 证明未被读取）。", "扩展 AssessIncomeCliRunnerTest：新增可参数化累计费率的私有 invoke 重载与 AC-2 参数 completeArguments 变体（capital 20000、APR 0.0365、成本合计 20、名义 10000）：(a) 完整证据单点 0.02 固定断言 contains 90天累计资金费率阈值=2.000000% 且含 简单赚币90天收益=180.00 USDT；(b) 成对 0.0199999999/0.0200000001 两次输出均含 资金费持有收益率=2.000000%、90天累计资金费率阈值=2.000000%、相对简单赚币增量=0.00 USDT、资金费率净收益=180.00 USDT，且分别只出现 建议=优先简单赚币（不含首次实盘上限）与 建议=仅小额验证智能套利 加 首次实盘上限=5000.00 USDT；(c) 证据不足（缺退出与滑点成本）时输出含 90天累计资金费率阈值=无法精确计算 且不打印阈值数值；(d) 既有四项测试断言原样保留。", "创建 docs/15-Funding-Rate-Break-Even-Threshold.md（简体中文）：定义与公式（阈值=(对照收益+完整已知成本)/对冲名义，是整个 90 天累计费率、非 APR、不按结算次数或假定 8 小时间隔换算）；AC-2 样例与 0.019/0.020/0.021 边界表；精度表述按 R1 为“按 DECIMAL128（34 位有效数字）计算、未按展示精度进一步舍入，CLI 展示层才 ×100 后 setScale(6,HALF_UP)”；加入 0.0199999999/0.0200000001 展示相同但建议不同的例子并说明不得用舍入后的 CLI 数字重新决定建议；可用与不可用条件、历史情景限制（非预测、非建议、区间完整性未证明），并指向 docs/09 测试手册。", "自查 git diff 严格限于六文件后停止编码，交由自测节点按 validation_plan 程序化执行并收集 Surefire 报告证据；任何测试失败按既有修复-重跑流程处理，不在本计划外扩文件。" ],
    "edit_files" : [ "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java", "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java", "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java", "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java", "docs/15-Funding-Rate-Break-Even-Threshold.md" ],
    "files" : [ {
      "path" : "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java",
      "operation" : "MODIFY"
    }, {
      "path" : "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java",
      "operation" : "MODIFY"
    }, {
      "path" : "docs/15-Funding-Rate-Break-Even-Threshold.md",
      "operation" : "CREATE"
    } ],
    "verification_bindings" : [ {
      "criterion_id" : "TR-1",
      "method" : "在固定隔离基线 codex/w09-okx-break-even-20261026 @ 7c5facc（JDK 25 + Maven 3.9）运行 mvn test -Dtest=PhaseOneAssessmentServiceTest，退出码必须为 0；以 target/surefire-reports 的 XML/txt 报告为程序依据，核对新阈值单元测试通过：AC-2 样例对照收益 180、阈值原值 isEqualByComparingTo 0.02；累计费率 0.019/0.020/0.021 对应原值增量 -10/0/+10 与建议 PREFER_SIMPLE_EARN/PREFER_SIMPLE_EARN/MICRO_VALIDATE_ARBITRAGE；除不尽场景（分子 200、名义 3000）直接断言独立写定字面量 0.06666666666666666666666666666666667 且 precision()==34，断言前无 setScale；零已知成本阈值 0.018、零 APR 阈值 0.002、负资金费率场景（证明 AC-1/AC-2）。",
      "executor" : "AGENT",
      "environment_refs" : [ ],
      "authority_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
        "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
      } ],
      "evidence_kind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
      "feasibility_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/prompts/design-claude.md.manifest.json",
        "sha256" : "ad018819314f97c39aa94398900858656529b75f32fe0972fb3511ea33a02eea"
      } ],
      "detail_owner" : "implement.claude_self_test_report",
      "actual_exit_required" : true,
      "expected_exit_code" : 0
    }, {
      "criterion_id" : "TR-2",
      "method" : "同一命令 mvn test -Dtest=PhaseOneAssessmentServiceTest，退出码必须为 0；核对不可用与校验测试通过：成本缺失（退出/滑点未知）、简单赚币条款未确认、窗口内无历史结算、期末保持策略开放四种情况下 breakEvenCumulativeFundingRate 为空且原因沿既有 blockers/unknowns 输出；零与负 hedgedShortNotional 在读取事实前被既有 PhaseOneAssessmentRequest 校验抛出 IllegalArgumentException（事实查询以 AssertionError 证明未读取）（证明 AC-3）。",
      "executor" : "AGENT",
      "environment_refs" : [ ],
      "authority_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
        "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
      } ],
      "evidence_kind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
      "feasibility_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/prompts/design-claude.md.manifest.json",
        "sha256" : "ad018819314f97c39aa94398900858656529b75f32fe0972fb3511ea33a02eea"
      } ],
      "detail_owner" : "implement.claude_self_test_report",
      "actual_exit_required" : true,
      "expected_exit_code" : 0
    }, {
      "criterion_id" : "TR-3",
      "method" : "运行 mvn test -Dtest=AssessIncomeCliRunnerTest，退出码必须为 0；以 target/surefire-reports 报告为程序依据，核对展示测试通过：完整证据单点 0.02 时输出固定包含 90天累计资金费率阈值=2.000000% 与 简单赚币90天收益=180.00 USDT；成对 0.0199999999/0.0200000001 两次输出的持有收益率、阈值、增量、净收益展示完全相同，但分别只出现 建议=优先简单赚币（不含首次实盘上限）与 建议=仅小额验证智能套利 加 首次实盘上限=5000.00 USDT；证据不足时输出 90天累计资金费率阈值=无法精确计算 且不打印阈值数值；既有四项测试断言不回归（证明 AC-2 防绕过与 AC-4 展示）。",
      "executor" : "AGENT",
      "environment_refs" : [ ],
      "authority_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
        "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
      } ],
      "evidence_kind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
      "feasibility_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/prompts/design-claude.md.manifest.json",
        "sha256" : "ad018819314f97c39aa94398900858656529b75f32fe0972fb3511ea33a02eea"
      } ],
      "detail_owner" : "implement.claude_self_test_report",
      "actual_exit_required" : true,
      "expected_exit_code" : 0
    }, {
      "criterion_id" : "TR-4",
      "method" : "在 Docker 可用（Testcontainers MySQL 8.4）环境下运行 mvn test 完整基线回归，退出码必须为 0；以 target/surefire-reports 完整报告作为 Gate 要求的完整基线通过事实保留，证明新增改动未破坏既有非容器回归与容器回归（AC-5 回归部分）；交付门后续步骤（独立验收、交付批准、精确候选应用、人工或明确委派 commit、原 finalize）不因测试通过而视为完成。",
      "executor" : "AGENT",
      "environment_refs" : [ ],
      "authority_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
        "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
      } ],
      "evidence_kind" : "PROGRAM_TOOL_EXECUTION_AND_ASSERTIONS",
      "feasibility_refs" : [ {
        "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793029979831/prompts/design-claude.md.manifest.json",
        "sha256" : "ad018819314f97c39aa94398900858656529b75f32fe0972fb3511ea33a02eea"
      } ],
      "detail_owner" : "implement.claude_self_test_report",
      "actual_exit_required" : true,
      "expected_exit_code" : 0
    } ],
    "authority_refs" : [ {
      "ref" : ".agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030419328/prompts/design-codex-review.md.manifest.json",
      "sha256" : "c4c949b00fc9cea90f35e95c4db145d42bad90193aabd721ce1eba7b0d8ac292"
    } ],
    "reference_files" : [ "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java", "src/main/java/app/cryptoincome/assessment/domain/SmartArbitrageCosts.java", "docs/09-Phase-1-Test-Runbook.md", "docs/README.md", "pom.xml" ],
    "file_level_changes" : [ "src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java: 新增组件 Optional<BigDecimal> breakEvenCumulativeFundingRate（置于 incrementalIncomeVsSimpleEarn 与 evidenceStatus 之间）及 javadoc，其余组件与紧凑构造器不变。", "src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java: 充分证据 else 分支新增 (simpleEarnIncome+knownCost)÷hedgedShortNotional 的 DECIMAL128 除法并置入新字段，其余分支 Optional.empty；唯一构造点 :112-117 同步传参。", "src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java: 增量行后新增阈值只读展示行（percent() 格式化或无法精确计算），限制行追加非年化/非预测子句；不重算、不改建议与退出码。", "src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java: 新增 AC-2 参数 fixture 与 (a)–(f) 阈值测试（原值与 precision 断言、成对防绕过、零成本/零 APR/负费率、四类不可用、非法名义校验）。", "src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java: 新增可参数化费率 invoke 重载与 AC-2 参数变体，覆盖固定阈值行断言、成对展示相同但建议不同、不可用展示；既有四项测试保留。", "docs/15-Funding-Rate-Break-Even-Threshold.md: 新建简体中文使用说明（定义公式、样例与边界表、精度口径、防误用例子、可用条件与限制、指向 docs/09）。" ],
    "validation_plan" : [ "mvn test -Dtest=PhaseOneAssessmentServiceTest —— 覆盖 TR-1/TR-2（含 AC-1/AC-2/AC-3 数值与不可用断言），退出码必须为 0。", "mvn test -Dtest=AssessIncomeCliRunnerTest —— 覆盖 TR-3（含 AC-4 展示断言），退出码必须为 0。", "mvn test —— 完整基线回归（含 Testcontainers MySQL，需 Docker 可用），覆盖 TR-4 与 AC-5 的回归要求，退出码必须为 0。", "以 target/surefire-reports 下 XML/txt 报告为程序化通过依据，核对新增测试方法全部执行且失败数为 0；不得仅以模型“已通过”正文作数。", "git status/diff 自查改动严格限于六文件，无范围外路径；确认未修改 README、迁移、采集、Web 与组合策略。" ],
    "rollback_notes" : "全部改动位于固定隔离基线 codex/w09-okx-break-even-20261026（commit 7c5facc）之上的六文件内：回滚时对五个修改文件执行 git restore 恢复到基线版本并删除新建的 docs/15-Funding-Rate-Break-Even-Threshold.md 即可；无数据库迁移、无运行状态、无外部副作用需要补偿。",
    "known_risks" : [ "TR-4 完整基线回归需要 Docker 可用（Testcontainers 启动 MySQL 8.4）；环境不可用时须补齐后重跑，不得降级为部分回归或以跳过作数。", "CLI 成对测试断言钉住现有 money()/percent() 展示字符串，未来展示格式调整需同步维护；阈值语义断言集中在服务测试原值断言，不受展示层影响。", "record 构造签名变化：已 grep 确认唯一构造点 PhaseOneAssessmentService.java:112，执行阶段仍以 mvn test 全量编译验证无遗漏调用点。" ],
    "human_review_checklist" : [ "阈值仅由 PhaseOneAssessmentService 计算、PhaseOneAssessment 承载、CLI 只读消费，CLI 无任何重算逻辑。", "分子=simpleEarnIncome+knownCost（knownTotal 既有口径，不重复计费），分母=hedgedShortNotional，除法显式使用 CALCULATION_CONTEXT（DECIMAL128）。", "结果保持整个 90 天累计资金费率口径，无 APR 化、无按结算次数或假定 8 小时间隔换算。", "四类证据不足场景阈值为 Optional.empty 且沿既有 blockers/unknowns 原因；零/负名义金额走既有请求校验，不新增校验路径。", "既有建议判定（delta.signum()）、首次实盘上限 5000 USDT、退出码、成本与限制语义不变。", "服务测试含独立字面量原值断言（0.02、0.06666666666666666666666666666666667、precision()==34）与成对防绕过测试；CLI 测试固定断言 2.000000% 且六位小数展示断言只存在于 CLI 测试。", "改动严格限于六文件；docs/15 为简体中文并包含样例与限制说明。", "测试通过必须以 Surefire 报告等程序工具依据为准。" ]
  },
  "newMustFix" : [ ]
}
```

## Input Artifacts

Raw agent logs are not embedded here by default. Use the paths below when deeper debugging is needed.

### .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.stderr.log

- Status: available
- Kind: stderr_log
- Raw Artifact: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.stderr.log

### .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.transcript.log

- Status: available
- Kind: file
- Raw Artifact: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.transcript.log

### .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.json

- Status: available
- Kind: json
- Sidecar: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.contract.json
- Decision: READY_TO_IMPLEMENT
- Summary: 六文件计划与已复审设计一致，实施步骤、测试断言及验证责任明确，可进入精确 EXECUTION 范围审批。
- Raw Artifact: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.json

### .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-codex_plan_review-019-run-1793030916946/binding.json

- Status: available
- Kind: json
- Raw Artifact: .agent/workstreams/ws-20261026T142203Z-7SNA/artifacts/context-governance/occurrences/node-plan-codex_plan_review-019-run-1793030916946/binding.json

### .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.contract.json

- Status: available
- Kind: contract_sidecar
- Sidecar: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.contract.json
- Decision: READY_TO_IMPLEMENT
- Summary: 六文件计划与已复审设计一致，实施步骤、测试断言及验证责任明确，可进入精确 EXECUTION 范围审批。
- Raw Artifact: .agent/workstreams/ws-20261026T142203Z-7SNA/runs/run-1793030916946/outputs/plan-codex-review.contract.json

