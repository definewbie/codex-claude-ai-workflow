# Workstream Metrics

- Workstream: ws-20261026T142203Z-7SNA
- Workflow: agent-lifecycle-terminal-delivery@5
- Status: RUNNING
- Generated At: 2026-10-26T21:09:17.978623Z

## Counts

- Nodes: 23
- Agent Runs: 10
- Gates: 2
- Decisions: 4
- Iterations: 3
- Revisions: 2
- Total Node Duration(ms): 1933251

## Longest Nodes

| Node | Status | Iteration | Duration(ms) |
| --- | --- | --- | --- |
| design.claude_design | COMPLETED | iter-002 | 397823 |
| design.claude_design | COMPLETED | iter-001 | 377078 |
| plan.claude_plan | COMPLETED | iter-002 | 318946 |
| plan.claude_plan | COMPLETED | iter-003 | 258904 |
| intake.claude_brainstorm | COMPLETED | iter-001 | 188645 |

## Provider Metrics

| Provider | Runs | Completed | Failed | Recoverable | Total Duration(ms) | Average Duration(ms) |
| --- | --- | --- | --- | --- | --- | --- |
| claude | 5 | 5 | 0 | 0 | 1523495 | 304699 |
| codex | 4 | 4 | 0 | 0 | 373191 | 93297 |
| outcomeStatusCounts | null | null | null | null | null | null |
| executionConsistencyCounts | null | null | null | null | null | null |

## Token Metrics

- Measured Runs: 9 / 9
- Session Snapshots: 0
- Estimated Runs: 0
- Input Tokens: 337507
- Output Tokens: 90832
- Cached Read Tokens: 1606464
- Cached Write Tokens: 0
- Total Tokens: 2034803
- Estimated Tokens (fallback, not in total): 0

### Token Usage By Step

| Node | Agent | Status | Outcome | Source | Input | Output | Transcript | Context | Prompt Overhead | Adapter Overhead | Total |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| intake.claude_brainstorm | claude | completed | SUCCESS | acpx_stream | 44010 | 8992 | 9508 | 1006 | 3832 | 39172 | 217930 |
| intake.codex_product_review | codex | completed | SUCCESS | acpx_current_transcript | 2477 | 1195 | 114408 | 3175 | 4125 | 0 | 35160 |
| design.claude_design | claude | completed | SUCCESS | acpx_current_transcript | 71476 | 13752 | 865589 | 0 | 3062 | 68414 | 733740 |
| design.codex_arch_review | codex | completed | SUCCESS | acpx_current_transcript | 7006 | 2061 | 182063 | 9158 | 3962 | 0 | 47339 |
| design.claude_design | claude | completed | SUCCESS | acpx_current_transcript | 56157 | 19465 | 1194377 | 0 | 7611 | 48546 | 236710 |
| design.codex_arch_review | codex | completed | SUCCESS | acpx_current_transcript | 29076 | 1621 | 127368 | 9158 | 10900 | 9018 | 77801 |
| plan.claude_plan | claude | completed | SUCCESS | acpx_current_transcript | 32931 | 18481 | 1159544 | 0 | 8707 | 24224 | 269204 |
| plan.codex_plan_review | codex | completed | SUCCESS | acpx_current_transcript | 31672 | 1617 | 120734 | 18198 | 8460 | 5014 | 110857 |
| plan.claude_plan | claude | completed | SUCCESS | acpx_current_transcript | 62702 | 23648 | 1441948 | 0 | 15810 | 46892 | 306062 |

### Top Context Sections

| Target Node | Profile | Section | Rendered | Original | Degraded | Dropped |
| --- | --- | --- | --- | --- | --- | --- |
| plan.codex_plan_review | plan_review | input_artifacts | 995 | 2262 | true | false |
| plan.codex_plan_review | plan_review | recent_agent_outputs | 743 | 2106 | true | false |
| plan.codex_plan_review | plan_review | iteration_history | 466 | 466 | false | false |
| intake.codex_product_review | product_review | input_artifacts | 445 | 445 | false | false |
| design.codex_arch_review | architecture_review | input_artifacts | 433 | 433 | false | false |
| plan.codex_plan_review | plan_review | human_feedback | 393 | 393 | false | false |
| design.codex_arch_review | architecture_review | recent_agent_outputs | 274 | 274 | false | false |
| intake.codex_product_review | product_review | recent_agent_outputs | 225 | 225 | false | false |
| intake.codex_product_review | product_review | review_evidence | 215 | 215 | false | false |
| design.codex_arch_review | architecture_review | review_evidence | 203 | 203 | false | false |

## Tool Metrics

- Tool Calls: 257
- Reads: 257
- Writes: 0
- Bash Commands: 0
- Evidence Files: 0

### Repeated Read Files

| File | Reads | Agents | Nodes | Evidence Known | Reread Reason |
| --- | --- | --- | --- | --- | --- |
| src/main/java/app/cryptoincome/assessment/application/PhaseOneAssessmentService.java | 5 | claude | intake.claude_brainstorm, design.claude_design, plan.claude_plan | false | not_required |
| src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessment.java | 5 | claude | intake.claude_brainstorm, design.claude_design, plan.claude_plan | false | not_required |
| src/main/java/app/cryptoincome/cli/AssessIncomeCliRunner.java | 5 | claude | intake.claude_brainstorm, design.claude_design, plan.claude_plan | false | not_required |
| src/test/java/app/cryptoincome/assessment/PhaseOneAssessmentServiceTest.java | 5 | claude | intake.claude_brainstorm, design.claude_design, plan.claude_plan | false | not_required |
| src/test/java/app/cryptoincome/cli/AssessIncomeCliRunnerTest.java | 5 | claude | intake.claude_brainstorm, design.claude_design, plan.claude_plan | false | not_required |
| src/main/java/app/cryptoincome/assessment/domain/PhaseOneAssessmentRequest.java | 4 | claude | intake.claude_brainstorm, design.claude_design, plan.claude_plan | false | not_required |
| docs/README.md | 3 | claude | design.claude_design, plan.claude_plan | false | not_required |
| src/main/java/app/cryptoincome/assessment/domain/SmartArbitrageCosts.java | 3 | claude | intake.claude_brainstorm, design.claude_design | false | not_required |
| CLAUDE.md | 2 | claude | intake.claude_brainstorm, design.claude_design | false | not_required |
| src | 2 | claude | design.claude_design, plan.claude_plan | false | not_required |
