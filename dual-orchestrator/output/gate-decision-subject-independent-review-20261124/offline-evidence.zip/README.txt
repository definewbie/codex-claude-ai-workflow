离线复核。使用 2026-11-24 本次评审源码的独立副本。仅在副本应用 isolated-test-additions.patch，测试只写 JUnit 临时 workstream。
在 dual-orchestrator 目录执行下列命令。需要 JDK 21、Maven 的本地依赖缓存、Git、Node。将 EVIDENCE_DIR 设为解包后的绝对目录。
git apply "$EVIDENCE_DIR/isolated-test-additions.patch"
node "$EVIDENCE_DIR/view-switch.cjs" dual-server/src/main/resources/static/console.js
mvn -o -pl dual-server,dual-cli -am -Dtest=GateDecisionSubjectBindingTest,ReviewGateActionsSubjectBindingTest,ContractQualificationSequenceTest,ReviewDecideCommandTest,AutoRunCommandTest,WorkstreamApiControllerTest,PhasedContractContinuationTest,EvidenceCollectionSequenceTest -Dsurefire.failIfNoSpecifiedTests=false test
测试中以反例存在作为断言。修复后，三条 independentReview 场景须改为拒绝错发且零写入，或验证页面已禁止错发。前端试验使用生产函数，控制请求完成顺序，替换了 DOM 和传输。Java Web 测试调用实际 controller 和实际文件账本，run=false。
LegacySourceCaller.java 的同一份旧调用，使用改动前后的 ledger-file/core 等模块 classpath 分别执行 javac -proc:none，结果为旧版成功，新版重载歧义。snapshot-delta.json 列出生产与测试改动相对改前快照的哈希；不含本次新增的临时测试。