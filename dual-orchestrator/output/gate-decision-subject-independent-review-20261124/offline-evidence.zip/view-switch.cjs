const assert = require('node:assert/strict');
const {readFileSync} = require('node:fs');
const vm = require('node:vm');
const source = readFileSync(process.argv[2], 'utf8');
function production(name) {
  const rows = source.split('\n');
  const i = rows.findIndex(s => new RegExp('^(?:async )?function '+name+'\\(').test(s));
  if (i < 0) throw Error(name);
  let j=i+1;
  while (rows[j] !== '}') ++j;
  return rows.slice(i,j+1).join('\n');
}
(async function () {
const calls = [], taskButtons = [], actions = [];
const wait = () => { let resolve; const promise=new Promise(r=>resolve=r); return {promise,resolve}; };
const snapshots=wait(), reviewB=wait();
const state={workdir:'workspace',selectedId:'A',taskPage:1,workstreams:[{workstreamId:'A'},{workstreamId:'B'}],
  review:{gateNodeInstanceId:'node-review-gate-002',packet:{allowedActions:['approve']}},overview:{}};
const ctx={state,console,document:{createElement(){return {addEventListener(type,fn){this.click=fn}}}},
  els:{revisionFeedback:{value:'view of A'},taskList:{appendChild(b){taskButtons.push(b)}},primaryActions:{appendChild(b){actions.push(b)}}},
  localStorage:{setItem(){}},selectedWorkdirParam:()=>state.workdir, escapeHtml:String, statusKind:String,statusLabel:String,timeLabel:String,shortId:String,asList:x=>x,
  request(path){return path.includes('review/current')?reviewB.promise:snapshots.promise},postAction(path,body){calls.push({path,body})},
  renderAll(){},connectProgressStream(){},renderFailure(msg,m){throw Error(msg+' '+m)}};
vm.createContext(ctx);
vm.runInContext(['renderTaskList','renderPrimaryActions','allowedActions','approveAndRun','loadSelected','loadCurrentReview','loadCurrentRecovery'].map(production).join('\n'),ctx);
ctx.renderTaskList();ctx.renderPrimaryActions('WAITING_FOR_HUMAN');
const approveDisplayedA=actions[0].click;
const switchToB=taskButtons[1].click();
approveDisplayedA();
assert.ok(calls[0].path.includes('/B/')); assert.equal(calls[0].body.gateNodeInstanceId,'node-review-gate-002');
snapshots.resolve({workflow:{status:'WAITING_FOR_HUMAN'}});
await new Promise(setImmediate);
approveDisplayedA();
assert.ok(calls[1].path.includes('/B/')); assert.equal(calls[1].body.gateNodeInstanceId,null);
console.log(JSON.stringify(calls));
reviewB.resolve({gateNodeInstanceId:'node-review-gate-002'}); await switchToB;
})().catch(e=>{console.error(e);process.exitCode=1});
