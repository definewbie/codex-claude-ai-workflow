import dev.dual.ledger.file.*;
import dev.dual.core.workflow.WorkflowDefinition;
class LegacySourceCaller {
  void review(WorkflowFileLedger ledger, WorkstreamPaths paths, WorkflowDefinition definition) throws Exception {
    ledger.resolveOpenGate(paths, definition, "approve", "missing qualification", null);
  }
}
